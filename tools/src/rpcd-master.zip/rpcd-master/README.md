# rpcd
This is a simple rpc server.


##Dependency
* [libgzf](https://github.com/gozfree/libraries/tree/master/libgzf)
* [liblog](https://github.com/gozfree/libraries/tree/master/liblog)
* [libgevent](https://github.com/gozfree/libraries/tree/master/libgevent)
* [libskt](https://github.com/gozfree/libraries/tree/master/libskt)
* [libdict](https://github.com/gozfree/libraries/tree/master/libdict)
* [libworkq](https://github.com/gozfree/libraries/tree/master/libworkq)
* [librpc](https://github.com/gozfree/libraries/tree/master/librpc)
* [libosal](https://github.com/gozfree/libraries/tree/master/libosal)
* [libthread](https://github.com/gozfree/libraries/tree/master/libthread)


