/*****************************************************************************
 * Copyright (C) 2014-2015
 * file:    rpcd_common.h
 * author:  gozfree <gozfree@163.com>
 * created: 2015-08-02 00:30
 * updated: 2015-08-02 00:30
 *****************************************************************************/
#ifndef _RPCD_COMMON_H_
#define _RPCD_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif


int rpcd_group_register();


#ifdef __cplusplus
}
#endif
#endif
