/**@file net_3g_app.c
 * @note HangZhou Hikvision Digital Technology Co., Ltd. All Right Reserved.
 * @brief  3G/4G���ų���
 * 
 * @author   xusen
 * @date     2014-2-25
 * @version  V1.0.0
 * 
 * @note ///Description here 
 * @note History:        
 * @note     <author>   <time>    <version >   <desc>
 * @note  
 * @warning  
 */

#include <time.h>
#include "diald_process.h"
#include "diald_log.h"
#include <net/route.h>

#define ROUTE_FILE		"/proc/net/route"
#define CONVERT_WDAY(x)			((x) == 0) ? 6 : ((x) - 1)	///< ����ת��  ����һ��ͷת��Ϊ���տ�ͷ���ڶ�ʱ������ʹ�ã���ֵ��ӦΪ:0--monday, 6--sunday
PPP_PARAM ppp_param;

static unsigned char fomer_DialMethold = DIAL_MANUAL;

/* �ⲿ���ñ��� */
extern DIAL_CFG* pDevDialParam;
extern SHM_PARAM *shareMemParam;
extern UINT32 bTastExitStatus;
extern pthread_mutex_t rilSem;


/* �ڲ����� */
static int pr_exit(void);
static void sig_chld(int signo);
static int modem_open_ppp(void);
static void modem_startPPP(void);
static int get_mobile_dial_status(MOBILE_STATUS * mobile_status);
static int mobile_empty_dial_status(MOBILE_STATUS * mobile_status);
static int get_gateway_param(char *interface_name, char *gateway_ip, int gateway_len); 

inline MODEM_DIAL_STAT mobile_get_modem_stat(void);
inline void 		   mobile_set_modem_stat(MODEM_DIAL_STAT currdialStat); 

/*�ⲿ����������*/
extern INT32 get_dns(INT8* p_dns1, INT8* p_dns2, INT32 len);
extern INT32 get_netmask(INT8 *p_interface_name, INT8 *p_netmask, INT32 len);
extern INT32 get_gateway(INT8 *p_interface_name, INT8 *p_gateway, INT32 len);
extern int   get_ipaddr(char * interface_name,char * ip,int len);
extern INT32 set_gateway(char *active_interface_name, char *gateway);
extern BOOL  is_mobile_online(void);
extern unsigned int sys_device_uptime(void);
extern  int check_file_exist(char* filename);

static int ppp_param_init (void)
{
	memset(&ppp_param, 0, sizeof(PPP_PARAM));

	modem_ppp_pid = -1;
	modem_ppp_failed = TRUE;

	return OK;
}


/**@brief         �������ʱ���Ų�������
 * @param[in]     ��ǰ������ʽ
 * @param[out]    none
 * @return        OK ERROR
 */
int set_ppp_param(MODEM_MODE mode_name)
{

	LTE4G_DEBUG(DEBUG_INFO,"mode_name = %d  ###################\n\n",mode_name);
	if((strlen((char *)(pDevDialParam->dialParam.szDialNum)) != 0)		// ���ź���
		&& (strlen((char *)(pDevDialParam->dialParam.szUsername)) != 0)	// �����û���
		&& (strlen((char *)(pDevDialParam->dialParam.szPassword)) != 0))	// ��������
	{
		LTE4G_DEBUG(DEBUG_INFO,"initDial: Parameters have been configured\n");
		memcpy(modem_ppp_telephone, pDevDialParam->dialParam.szDialNum, 
			MIN(strlen((char*)pDevDialParam->dialParam.szDialNum), sizeof(pDevDialParam->dialParam.szDialNum)));
		memcpy(modem_ppp_name, pDevDialParam->dialParam.szUsername, 
			MIN(strlen((char*)pDevDialParam->dialParam.szUsername), sizeof(pDevDialParam->dialParam.szUsername)));
		memcpy(modem_ppp_pwd, pDevDialParam->dialParam.szPassword, 
			MIN(strlen((char*)pDevDialParam->dialParam.szPassword), sizeof(pDevDialParam->dialParam.szPassword))); 
	}
	else if (MODE_EVDO == mode_name || MODE_CDMA1X == mode_name)		//����3G
	{
		memcpy(modem_ppp_telephone, EVDO_DFT_DIALNUM, MIN(strlen(EVDO_DFT_DIALNUM), sizeof(EVDO_DFT_DIALNUM))); 
		memcpy(modem_ppp_name,EVDO_DFT_NAME, MIN(strlen(EVDO_DFT_NAME), sizeof(EVDO_DFT_NAME))); 
		memcpy(modem_ppp_pwd, EVDO_DFT_PASSWD, MIN(strlen(EVDO_DFT_PASSWD), sizeof(EVDO_DFT_PASSWD)));  
	}
	else if (MODE_WCDMA == mode_name)	//��ͨ3G
	{
		memcpy(modem_ppp_telephone, WCDMA_DFT_DIALNUM, MIN(strlen(WCDMA_DFT_DIALNUM), sizeof(WCDMA_DFT_DIALNUM))); 
		memcpy(modem_ppp_name,WCDMA_DFT_NAME, MIN(strlen(WCDMA_DFT_NAME), sizeof(WCDMA_DFT_NAME))); 
		memcpy(modem_ppp_pwd, WCDMA_DFT_PASSWD, MIN(strlen(WCDMA_DFT_PASSWD), sizeof(WCDMA_DFT_PASSWD)));   
	}
	else if((MODE_TDSCDMA == mode_name) 
		|| (MODE_TDLTE == mode_name))	//�ƶ�3G/4G
	{
		memcpy(modem_ppp_telephone, TDSCDMA_DFT_DIALNUM, MIN(strlen(TDSCDMA_DFT_DIALNUM), sizeof(TDSCDMA_DFT_DIALNUM))); 
		memcpy(modem_ppp_name,TDSCDMA_DFT_NAME, MIN(strlen(TDSCDMA_DFT_NAME), sizeof(TDSCDMA_DFT_NAME))); 
		memcpy(modem_ppp_pwd, TDSCDMA_DFT_PASSWD, MIN(strlen(TDSCDMA_DFT_PASSWD), sizeof(TDSCDMA_DFT_PASSWD)));   
	}
	else if(MODE_FDDLTE == mode_name)
	{
		//FDD��Ϊ���ź���ͨ
		if(OPERATOR_CHINA_TELECOM == pDevDialParam->mobile_operator)
		{
			memcpy(modem_ppp_telephone, FDDLTE_TELECOM_DEF_DIALNUM, MIN(strlen(FDDLTE_TELECOM_DEF_DIALNUM), sizeof(FDDLTE_TELECOM_DEF_DIALNUM))); 
			memcpy(modem_ppp_name,FDDLTE_TELECOM_DFT_NAME, MIN(strlen(FDDLTE_TELECOM_DFT_NAME), sizeof(FDDLTE_TELECOM_DFT_NAME))); 
			memcpy(modem_ppp_pwd, FDDLTE_TELECOM_DFT_PASSWD, MIN(strlen(FDDLTE_TELECOM_DFT_PASSWD), sizeof(FDDLTE_TELECOM_DFT_PASSWD)));  
		}
		else
		{
			memcpy(modem_ppp_telephone, FDDLTE_UNICOM_DEF_DIALNUM, MIN(strlen(FDDLTE_UNICOM_DEF_DIALNUM), sizeof(FDDLTE_UNICOM_DEF_DIALNUM))); 
			memcpy(modem_ppp_name,FDDLTE_UNICOM_DFT_NAME, MIN(strlen(FDDLTE_UNICOM_DFT_NAME), sizeof(FDDLTE_UNICOM_DFT_NAME))); 
			memcpy(modem_ppp_pwd, FDDLTE_UNICOM_DFT_PASSWD, MIN(strlen(FDDLTE_UNICOM_DFT_PASSWD), sizeof(FDDLTE_UNICOM_DFT_PASSWD)));   
		}
	}
	else
	{
		LTE4G_DEBUG(RT_ERROR, "modemMode ERROR, mode = %d\n",mode_name);
		return ERROR;
	}

	return OK;
}


/**@brief         4G�����������߳�
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
void initDial(void)
{
	LTE4G_DEBUG(DEBUG_INFO, "<initDial>: enter\n");
	
	/*�����߳����ƣ�����Ŀǰdiald���ǵ������룬�����޷��û���
	  *�����߳̽ӿ��������߳�����
	  *setPthreadName("ipc_supplicant");*/
	(void)prctl(15, (unsigned long)"dial thread");
	
	
	(void)setpgid(0, 0);

	if(ppp_param_init() != OK)
	{
		LTE4G_DEBUG(RT_ERROR,"input error\n");
		return;
	}
	
	//�ȴ�AT�����ʼ�����
	while (FALSE == shareMemParam->initFinish)
	{
		pthread_testcancel();
		sleep(1);
	}

	if(SIG_ERR == signal(SIGCHLD,sig_chld))
	{
		LTE4G_DEBUG(RT_ERROR, "signal (SIGCHLD) error\n");
		return;
	}
	
	LTE4G_DEBUG(DEBUG_INFO, "<modem_startPPP>: begin ...\n\n");

	modem_startPPP();

	while(1)
	{
		(void)pause();
	}
}


/**@brief         ����4G��������
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
void resumeDial(void)
{
	if(NULL != shareMemParam)
	{
		shareMemParam->online = TRUE;
		shareMemParam->manualPause = FALSE;
	}
}

/**@brief         �ر�4G��������
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
void pauseDial(void)
{
	if(NULL != shareMemParam)
	{
		shareMemParam->online = FALSE;
	}
}

/**@brief         ��ȡ4G��������
 * @param[in]     none
 * @param[out]    none
 * @return        0:�������������磬1:������������
 */
BOOL getDialStatus(void)
{	
	if(NULL != shareMemParam)
	{
		return shareMemParam->online;
	}
	return FALSE;
}

 /**@brief        ֱ��ɱ���������,����SIGTERM�ź�
 * @param[in]     none
 * @param[out]    none
 * @return        OK:0,ERROR:-1
 */
int modem_finiPPP()
{
	if(modem_ppp_pid > 0)
	{
		/*������ʾ��Ҫ�ս�PPPD����*/
		LTE4G_DEBUG(RT_ERROR, "kill pppd process\n"); 
		(void)kill(modem_ppp_pid, SIGTERM);
	}
	else
	{
		LTE4G_DEBUG(RT_ERROR, "ppp not running\n");
		return ERROR;
	}

	return OK;
}

/**@brief        ���Ž�����ֹʱ����Դ�ͷ�
 * @param[in]    none
 * @param[out]   none
 * @return       OK:0,ERROR:-1
 */
static int pr_exit(void)
{
	int status,pid;
	int exitNo = 0;
	
	/*��ʱֹͣĿǰ���̵�ִ��,ֱ�����ź��������ӽ���*/
	LTE4G_DEBUG(RT_ERROR, "pr_exit:  modem_ppp_pid= %d\n", modem_ppp_pid);
	pid = waitpid(modem_ppp_pid, &status, 0);
	if(pid != -1)
	{
		LTE4G_DEBUG(RT_ERROR, "process %d exit\n",pid);
	}

	if(WIFEXITED(status))
	{
		exitNo = WEXITSTATUS(status);
		LTE4G_DEBUG(RT_ERROR, "Normal termination ,exit status =%d\n",exitNo);
	}

	(void)mobile_empty_dial_status(&shareMemParam->realMobileStat);

	pthread_mutex_lock(&rilSem);
	bTastExitStatus &= ~(1 << 2);
	pthread_mutex_unlock(&rilSem);

	if (exitNo == EXIT_OPEN_FAILED)
	{
		dial_error_occur(EXIT_DIAL_ABNORMAL);
	}

	if (exitNo != EXIT_CONNECT_FAILED)
	{
		failedTimes = 0;
	}
	if ((exitNo == EXIT_CONNECT_FAILED) && (++failedTimes >= 3))		
	{ 
		/* �з�����źŵ�����£����ܲ��ųɹ����������� */
		if (((SRV_VALID_SERVICE == mobile_srvStat) && (MODE_TDSCDMA == mobile_mode) && (mobile_signal >= 110))		/* td-scdma  */
			|| ((SRV_VALID_SERVICE == mobile_srvStat) && (MODE_GPRS == mobile_mode) && (mobile_signal  >= 7))	/* edge */
			|| ((SRV_VALID_SERVICE == mobile_srvStat) && (MODE_WCDMA == mobile_mode) && (mobile_signal  >= 10))	/* wcdma */
			|| ((SRV_VALID_SERVICE == mobile_srvStat) && (MODE_TDLTE == mobile_mode) && (mobile_signal  >= 10))	//TDLTE
			|| ((SRV_VALID_SERVICE == mobile_srvStat) && (MODE_FDDLTE == mobile_mode) && (mobile_signal  >= 10)))	//FDDLTE, signal����Ҫ����ʵ��ȷ��
		{
			LTE4G_DEBUG(RT_ERROR, "pr_exit: EXIT_DIAL_ABNORMAL\n");
			dial_error_occur(EXIT_DIAL_ABNORMAL);
		}
		failedTimes = 0;
	}

	/* ���̲��Ǳ���Ϊɱ���������źŲ��õ��ߣ��ۼƸ�ʧ�ܴ�����100525 */
	if (exitNo != EXIT_USER_REQUEST && (++totalfailedTimes > 20))  
	{
		LTE4G_DEBUG(RT_ERROR, "pr_exit: totalfailedTimes > 20\n");
		//dial_error_occur(EXIT_DIAL_ABNORMAL);
		
	}

	sleep(3);
	modem_ppp_pid = -1;
	modem_ppp_failed = TRUE;
	
	return OK;
}
/**@brief       ��ȡ��������ʧ�ܵĴ��� 
 * @param[in]   none
 * @param[out]  none
 * @return      OK:0,ERROR:-1
 */
int get_continuous_dial_failed_times(void)
{
	return totalfailedTimes;
} 

/**@brief       SIGTERM�źŴ�������
 * @param[in]   none
 * @param[out]  none
 * @return      OK:0,ERROR:-1
 */
static void sig_chld(int signo)
{
	(void)pr_exit();
	return;
}

/**@brief         ��ȡlte4G���ź�Ĳ�����������
 * @param[in]     none
 * @param[out]    mobile_status:��ȡ�Ĳ���
 * @return        OK:0;ERROR:-1
 */
static int mobile_get_dial_status(MOBILE_STATUS * mobile_status)
{
	char ipAddr[16];
	char gateway[16];
	char netMask[16];
	char dns1[16];
	char dns2[16];

	memset(ipAddr, 0, sizeof(ipAddr));
	memset(gateway, 0, sizeof(gateway));
	memset(netMask, 0, sizeof(netMask));
	memset(dns1, 0, sizeof(dns1));
	memset(dns2, 0, sizeof(dns2));

	if (mobile_status == NULL)
	{
		return ERROR;
	}
	
	if (OK == get_ipaddr(PPP_INTERFACE, ipAddr, sizeof(ipAddr)))
	{
		mobile_log_write("mode = %d, diald ip = %s\n", mobile_mode, ipAddr);
		(void)inet_aton(ipAddr, &mobile_status->ipAddr.v4);

		if (get_gateway(PPP_INTERFACE, gateway, sizeof(gateway)) != ERROR)
		{
			(void)inet_aton(gateway, &mobile_status->gateway.v4);
		}
		if (get_netmask(PPP_INTERFACE, netMask, sizeof(netMask)) != ERROR)
		{
			(void)inet_aton(netMask, &mobile_status->netMask.v4);
		}
		if (get_dns(dns1, dns2, sizeof(dns1)) != ERROR)
		{
			(void)inet_aton(dns1, &mobile_status->dns1.v4);
			(void)inet_aton(dns2, &mobile_status->dns2.v4);
		}
	}

	//mobile_status->is_update = TRUE;

	return OK;
}


/**@brief         ���lte4G���ź�Ĳ���
 * @param[in]     none
 * @param[out]    mobile_status:��ȡ�Ĳ���
 * @return        OK:0;ERROR:-1
 */ 
int mobile_empty_dial_status(MOBILE_STATUS * mobile_status)
{
	if (NULL == mobile_status)
	{
		return ERROR;
	}
	
	//�ؼ���Ϣ��ʱ������ʾ
	mobile_set_modem_stat(DIAL_FINI_INIT);
	memset(&mobile_status->ipAddr, 0, sizeof(IPADDR_PARAM_T));
	memset(&mobile_status->netMask, 0, sizeof(IPADDR_PARAM_T));
	memset(&mobile_status->gateway, 0, sizeof(IPADDR_PARAM_T));
	memset(&mobile_status->dns1, 0, sizeof(IPADDR_PARAM_T));
	memset(&mobile_status->dns2, 0, sizeof(IPADDR_PARAM_T));

	return OK;
}

/**@brief       ��䲦�Žű���������pppd���Ž���
 * @param[in]   none
 * @param[out]  none
 * @return      OK:0,ERROR:-1
 */
static int modem_open_ppp(void)
{
	int pid = -1;
	int i = 0;
	char szMtu[8] = {0};
	char* argv[56];
	char modem_chat_script[512] = {0};
	char modem_chat_disconnect[512] = {0};
	
	memset(modem_chat_script,0,sizeof(modem_chat_script));

	// Every start ppp, we must set parameters firstly.
	if(set_ppp_param(mobile_mode) != OK)
	{
		LTE4G_DEBUG(RT_ERROR, "set_ppp_param, ERROR\n");
		pr_exit();
		return ERROR;
	}
	
	sprintf(modem_chat_script,
		"/home/chat -v  TIMEOUT 15 ABORT BUSY  ABORT 'NO ANSWER' '' ATH0 OK AT 'OK-+++\\c-OK' ATDT%s CONNECT ",
		modem_ppp_telephone);

   	sprintf(modem_chat_disconnect,
		"/home/chat -v ABORT 'BUSY' ABORT 'ERROR' ABORT 'NO DIALTONE' '' '\\K' '' '+++ATH' SAY '\nPDP context detached\n'");

	argv[i++] = "pppd";
	argv[i++] = "modem";	
	argv[i++] = "crtscts";	
	argv[i++] = "debug";	
	argv[i++] = "nodetach";	
	
	if (EP_TTYUSB == shareMemParam->realMobileStat.epName)	
	{		
		if(strncmp(shareMemParam->id_product, "9607", strlen("9607")) == 0)		
		{			
			argv[i++] = "/dev/ttyUSB4";		// 9607ģ��Ĳ��Žڵ��� ttyUSB4		
		}		
		else if(strncmp(shareMemParam->id_product, "9603", strlen("9603")) == 0)		
		{			
			argv[i++] = "/dev/ttyUSB2";		// 9603ģ��Ĳ��Žڵ��� ttyUSB2		
		}		
		else if(strncmp(shareMemParam->id_product, "9e00", strlen("9e00")) == 0)		
		{			
			argv[i++] = "/dev/ttyUSB0";		// 9e00ģ��Ĳ��Žڵ��� ttyUSB0		
		}
		else if(strncmp(shareMemParam->id_product, "9b05",strlen("9b05")) == 0
			|| strncmp(shareMemParam->id_product, "9b3c",strlen("9b3c")) == 0)
		{
			argv[i++] = "/dev/ttyUSB3";		// U8300ģ��Ĳ��Žڵ��� ttyUSB3		
		}
		else if(strncmp(shareMemParam->id_product, "1c25",strlen("1c25")) == 0
			|| strncmp(shareMemParam->id_product, "15c1",strlen("15c1")) == 0)//909s-821��909s-120 productid ��ͬ
		{
			argv[i++] = "/dev/ttyUSB2";		// HUAWEIģ��Ĳ��Žڵ��� ttyUSB2		
		}
		else		
		{			
			LTE4G_DEBUG(RT_ERROR, "Error, there is no this id_product!\n");			
			return ERROR;		
		}	
	}	
	else if (EP_TTYACM == shareMemParam->realMobileStat.epName)	
	{		
		argv[i++] = "/dev/ttyACM0";	
	}	
	
		
	argv[i++] = "115200";	
	argv[i++] = "connect";	
	argv[i++] = modem_chat_script;	
	//argv[i++] = "debug";	
	argv[i++] = "noipdefault";	
	argv[i++] = "default-asyncmap";		
	argv[i++] = "lcp-max-configure";	
	argv[i++] = "30";	
	argv[i++] = "defaultroute";	
	argv[i++] = "hide-password";
	//argv[i++] = "nodetach";	
	argv[i++] = "nodeflate";	
	argv[i++] = "nopcomp";	
	argv[i++] = "novj";	
	argv[i++] = "novjccomp";

	if (pDevDialParam->dialParam.nMtuSize >= 500 && pDevDialParam->dialParam.nMtuSize <= 1500)	
	{		
		sprintf(szMtu, "%d", pDevDialParam->dialParam.nMtuSize);		
		argv[i++] = "mtu";		
		argv[i++] = szMtu;	
	}
	
	if (CHAP_PROTOCAL == pDevDialParam->dialParam.byVerifyProto)   /* CHAP authentication */	
	{		
		argv[i++] = "refuse-pap";		
		argv[i++] = "refuse-eap";		
		argv[i++] = "auth";		
		argv[i++] = "require-chap";		
		argv[i++] = "user";		
		argv[i++] =  modem_ppp_name;		
		argv[i++] = "password";		
		argv[i++] =  modem_ppp_pwd;		
		argv[i++] = "noauth";	
	}	
	else if (PAP_PROTOCOL == pDevDialParam->dialParam.byVerifyProto)  /* PAP authentication */	
	{		
		argv[i++] = "refuse-chap";		
		argv[i++] = "refuse-eap";		
		argv[i++] = "auth";		
		argv[i++] = "require-pap";		
		argv[i++] = "user";		
		argv[i++] =  modem_ppp_name;		
		argv[i++] = "password";		
		argv[i++] =  modem_ppp_pwd;		
		argv[i++] = "noauth";	
	}	
	else                /*auto authentication */	
	{		
		argv[i++] = "noauth";	
		argv[i++] = "user";		
		argv[i++] =  modem_ppp_name;		
		argv[i++] = "password";		
		argv[i++] =  modem_ppp_pwd;	
	}	
	
	LTE4G_DEBUG(RT_ERROR, "<open_ppp>: modem_ppp_telephone = <%s> ,modem_ppp_name = <%s> ,modem_ppp_pwd = <%s>, VerifyProto = %d, mtu = %d\n",
		modem_ppp_telephone, modem_ppp_name, modem_ppp_pwd, pDevDialParam->dialParam.byVerifyProto, pDevDialParam->dialParam.nMtuSize);
	
	argv[i++] = "usepeerdns";	
	argv[i++] = "lcp-echo-interval";	
	argv[i++] = "60";	
	argv[i++] = "lcp-echo-failure";	
	argv[i++] = "3";	
	argv[i++] = "maxfail";	
	argv[i++] = "0";	
	argv[i++] = "disconnect";	
	argv[i++] = modem_chat_disconnect;	
	argv[i++] = (char *)0;

	/*��һ���µĽ��������ڲ��Ž���*/
	if((pid = vfork()) < 0) 
	{
		LTE4G_DEBUG(RT_ERROR, "Can not fork, exit now\n");
		return -1;
	}
	
	pthread_mutex_lock(&rilSem);
	bTastExitStatus |= 1 << 2;
	pthread_mutex_unlock(&rilSem);
	if( pid == 0)
	{
		(void)execvp("pppd",argv);
	}
	else
	{
		return pid; /* pid pppd*/
	}

	return pid; /* pppd child pid: 0*/
}


/**@brief       ��⵱ǰ�Ƿ���Ҫ���żƻ�����
 * @param[in]   none
 * @param[out]  none
 * @return      TRUE,FALSE
 */
static BOOL check_auto_dial_schdule(void)
{
	time_t cur_time;
	struct tm cur_tm;
	time_t stopTime = 0;
	time_t cur_hm = 0;
	int cur_wday = 0;
	BOOL bFindTimeSeg = FALSE;
	int i = 0;
	DIAL_SCHED *dial_sched;

	memset(&cur_tm, 0, sizeof(cur_tm));
	memset(&cur_time, 0, sizeof(cur_time));
	cur_time = time(NULL);
	(void)gmtime_r(&cur_time, &cur_tm);
	cur_hm = (cur_tm.tm_hour<<16) | cur_tm.tm_min;	/* current hour|min, format same as parm. config */
	cur_wday = CONVERT_WDAY(cur_tm.tm_wday);		/* current week day */
	
	if(pDevDialParam->byEnableMobile)
	{
		for (i = 0; i < MAX_TIMESEGMENT; i++)
		{
			dial_sched = &(pDevDialParam->dial_schedule.time_range[cur_wday][i]);
			if((dial_sched->dialTimeSeg.stopTime > dial_sched->dialTimeSeg.startTime)     /* ��Ч��ʱ��� */
				&& (cur_hm >= dial_sched->dialTimeSeg.startTime) 
				&& (cur_hm < dial_sched->dialTimeSeg.stopTime))
			{
				bFindTimeSeg = TRUE;
				break;
			}
		}
	}
	
	return bFindTimeSeg;
}


/**@brief       ��⵱ǰ�Ƿ���Ҫ����
 * @param[in]   none
 * @param[out]  none
 * @return      TRUE,FALSE
 */
static BOOL check_is_need_start_dial(void)
{
	//������Զ����ţ��ȴ��ֶ�ʹ���˲��š�

	LTE4G_DEBUG(DEBUG_INFO, "DialMethold = %s, manualDialStatus = %s \n", 
	(DIAL_MANUAL == pDevDialParam->byDialMethod) ? "DIAL_MANUAL" : "DIAL_AUTO", 
	(START_DIAL == pDevDialParam->manualDialStatus) ? "START_DIAL" : "STOP_DIAL");
	fomer_DialMethold = pDevDialParam->byDialMethod;
	if(DIAL_MANUAL == pDevDialParam->byDialMethod)
	{
		if(START_DIAL == pDevDialParam->manualDialStatus)
		{
			return TRUE;
		}			
	}
	else
	{
		if(TRUE == check_auto_dial_schdule())
		{
			return TRUE;
		}
	}

	return FALSE;
}


/**@brief       ��⵱ǰ�Ƿ���Ҫֹͣ����
 * @param[in]   none
 * @param[out]  none
 * @return      TRUE,FALSE
 */
static BOOL check_is_need_stop_dial(void)
{ 	
	return !check_auto_dial_schdule();
}

/**@brief        ����3G������룬����������ر�3G�������
 * @param[in]    none
 * @param[out]   none
 * @return       none
 */
static void modem_startPPP(void)
{
	int i = 0;
	unsigned int lastDialTime = 0;	
	unsigned int dialCyle = 10; 
	unsigned int last_offline_dial_time = 0;
	BOOL online_time_over = TRUE;
	static int fial_time = 0;
	char interface_name[32];
	char gateway_ip[32];
	
FOREVER {
restart:

		memset(interface_name, 0, sizeof(interface_name));
		memset(gateway_ip, 0, sizeof(gateway_ip));
		
		// Ensuring pppd process has ended!
		while(modem_ppp_pid != -1)
		{
			pthread_testcancel();
			sleep(1);
		}
		
		modem_ppp_failed = FALSE;

		LTE4G_DEBUG(DEBUG_INFO, "shareMemParam->initFinish = %s \n",(shareMemParam->initFinish == TRUE)? "TRUE" : "FALSE");
		//��ǰat�����Ƿ��Ѿ���ʼ�����
		while(shareMemParam->initFinish != TRUE)
		{
			pthread_testcancel();
			sleep(1);
		}
		
		LTE4G_DEBUG(DEBUG_INFO, "#######check_is_need_start_dial \n");
		while(( FALSE == check_is_need_start_dial())
				||(MODE_NONE == mobile_mode))  //δ���Ż�δʶ��ͨ��ģʽʱ,�������в���
		{
			pthread_testcancel();
			sleep(1);
		}
		// Dial-Status: 7-ENTER_DIAL 
		mobile_set_modem_stat(DIAL_ENTER_DIAL);

		// ���Ӳ����ȶ��ԣ���δע�������磬�򲻲���(TD & WCDMA)EVDO��ͨ����1X�����EVDO�����CSQ�ź���ģ���ֵ
		while (mobile_reg2gInfo != CREG_STAT_REGISTED_LOCALNET 
			&& mobile_reg2gInfo != CREG_STAT_REGISTED_ROAMNET
			&& mobile_reg3gInfo != CREG_STAT_REGISTED_LOCALNET 
			&& mobile_reg3gInfo != CREG_STAT_REGISTED_ROAMNET
			&& mobile_reg4gInfo != CREG_STAT_REGISTED_LOCALNET 
			&& mobile_reg4gInfo != CREG_STAT_REGISTED_ROAMNET)  ///���ֻ��3G����??
		{
			pthread_testcancel();
			usleep(2000);
		}	

		LTE4G_DEBUG(DEBUG_INFO, "<modem_startPPP>: del_gateway  finish!\n");

		// Dial-Status: 8-START_DIAL  
		mobile_set_modem_stat(DIAL_START_DIAL);
		modem_ppp_pid = modem_open_ppp();

		// ������Ž��е�ID��
		LTE4G_DEBUG(DEBUG_INFO, "<modem_startPPP>: modem_ppp_pid = <%d> \n", modem_ppp_pid);
		LTE4G_DEBUG(DEBUG_INFO, "<modem_startPPP>: wait pppd ... \n");

		/*�ȴ����ųɹ�*/
		while (!is_mobile_online()  && (FALSE == modem_ppp_failed))
		{
			pthread_testcancel();
			sleep(1);
		}

		
		LTE4G_DEBUG(DEBUG_INFO, "<modem_startPPP>: wait pppd finish! \n");

		if (FALSE == modem_ppp_failed) 
		{	
			// dial success
			LTE4G_DEBUG(DEBUG_INFO, "<modem_startPPP>: dial seccussful!\n");

			// If you turn on the automatic logoff time, we will record the time of dial success
			if(DIAL_MANUAL == pDevDialParam->byDialMethod)
			{
				if(pDevDialParam->nOffLineTime > 0 && online_time_over)
				{
					last_offline_dial_time = sys_device_uptime();
					online_time_over = FALSE;
				}
			}

			//��ȡ���ųɹ���Ĳ������Ա��ں������õ�ʱ��ʹ��
			(void)mobile_get_dial_status(&shareMemParam->realMobileStat);
			// Dial-Status: 9-KEEP_ONLINE 
			mobile_set_modem_stat(DIAL_KEEP_ONLINE);
 
			totalfailedTimes = 0;
			failedTimes = 0;

			FOREVER		// check the status of 4G network
			{
				sleep(1);	

				// check DEV_4G_USB whether is exist
				if(!is_mobile_online())
				{
					if(ERROR == check_file_exist(DEV_4G_USB))
					{
						LTE4G_DEBUG(RT_ERROR, "%s error happened\n",DEV_4G_USB);
						dial_error_occur(EXIT_DIAL_ABNORMAL);
					}
				}

				// check whether the dial method is changed.
				if(fomer_DialMethold != pDevDialParam->byDialMethod)
				{
					mobile_set_modem_stat(DIAL_FINI_INIT);
					LTE4G_DEBUG(DEBUG_INFO,"DialMethold changed\n");
					(void)modem_finiPPP();
					sleep(5);
					goto restart;
				}

				// if the dial is manually dial, we will check the current status of manual dialing.
				if(DIAL_MANUAL == pDevDialParam->byDialMethod)
				{
					if(STOP_DIAL == pDevDialParam->manualDialStatus)
					{
						mobile_set_modem_stat(DIAL_FINI_INIT);
						LTE4G_DEBUG(DEBUG_INFO,"STOP_DIAL\n");
						(void)modem_finiPPP();
						online_time_over = TRUE;
						sleep(5);
						goto restart;
					}
					
					// nOffLineTime > 0 is valid
					if(pDevDialParam->nOffLineTime > 0)
					{
						// Automatic logoff time has elapsed, the current status is set to STOP_DIAL
						if((sys_device_uptime() - last_offline_dial_time) > pDevDialParam->nOffLineTime)
						{
							mobile_set_modem_stat(DIAL_FINI_INIT);
							LTE4G_DEBUG(DEBUG_INFO,"Time to offline\n");
							(void)modem_finiPPP();
							pDevDialParam->manualDialStatus = STOP_DIAL;
							online_time_over = TRUE;
							sleep(5);
							goto restart;
						}
					}
				}
				else		// Detecting whether the current dial plan has expired
				{
					if(TRUE == check_is_need_stop_dial())
					{
						mobile_log_write("diald plan has expired\n");
						LTE4G_DEBUG(DEBUG_INFO,"Dial plan has expired\n");
						mobile_set_modem_stat(DIAL_FINI_INIT); 
						(void)modem_finiPPP();
						sleep(5);
						goto restart;
					}
				}
							
				if(TRUE == modem_ppp_failed)	// dial disconnected
				{
					LTE4G_DEBUG(DEBUG_INFO, "pppConnectionClose modem_ppp_pid = %d\n", modem_ppp_pid);
					mobile_set_modem_stat(DIAL_FINI_INIT); 
					(void)modem_finiPPP();

					// Detect whether there is a dial UBS port? if not, 4G module should be reload drivers
					if(ERROR == check_file_exist(DEV_4G_USB))
					{
						LTE4G_DEBUG(RT_ERROR, "%s error happened\n", DEV_4G_USB);
						dial_error_occur(EXIT_DIAL_ABNORMAL);
					}

					i = 0;
					while(is_mobile_online()
						|| (FALSE == modem_ppp_failed))
					{
						if (i++ > 5)    // ��ֹpppd�˳�ʱ�쳣��ʬ���̣���ʱ�˳� 
						{
							break;
						}
						sleep(3);
					}

					sleep(20);		// try after 20 seconds 
					break;
				}				
			}
		}
		else
		{
			// dial failed
			LTE4G_DEBUG(RT_ERROR, "<modem_startPPP>: diad faild modem_ppp_failed:[%d]!\n", modem_ppp_failed);

			fial_time++;
			
			if(0 == fial_time % 3)
			{
				if(DIAL_MANUAL == pDevDialParam->byDialMethod)
				{
					mobile_set_modem_stat(DIAL_FINI_INIT); 
					pDevDialParam->manualDialStatus = STOP_DIAL;
				}

				//<TODO:�Զ�����ģʽ����ôֹͣ����?������ӱ�־λ����ñ�־λ��Ҫ�ڿؼ����������Ӱ�ť
			}
			
			if(ERROR == check_file_exist(DEV_4G_USB))
			{
				LTE4G_DEBUG(RT_ERROR, "%s error happened\n",DEV_4G_USB);
				dial_error_occur(EXIT_DIAL_ABNORMAL);
			}

			// in order to prevent frequent calls pppd, gradually increase interval of dial
			if (abs(sys_device_uptime() - lastDialTime) <= 300)
			{
				dialCyle += 2;
			}
			else
			{
				dialCyle = 10;
			}

			lastDialTime = sys_device_uptime();
			dialCyle = (dialCyle > 120)? 120 : dialCyle;			// up to 120 seconds
			sleep(dialCyle);							// try after 10 seconds 

			LTE4G_DEBUG(DEBUG_INFO, "<modem_startPPP>: run end, goto restart! \n");
		}
	}

}


/** @fn	INT32 get_gateway_param(char *interface_name, char *gateway_ip, int gateway_len) 
 *  @brief	ͨ�������豸����ȡ���ʮ���Ʊ�ʾ�����أ����ش���p_gateway��	  
 *  @param[in]  p_interface_name �����豸��,����"eth0"
 *  @param[in]  p_gateway ������صĵ�ַ����Χ:��NULL
 *  @param[in]  len �����ַ������ȡ���Χ:ָ��Ŀռ�Ĵ�С
 *  @return	  OK �ɹ�; ERROR ʧ��
 */
static int get_gateway_param(char *interface_name, char *gateway_ip, int gateway_len)
{
	INT8 devname[64];
	//char gateway_ip[32];
	ULONG d = 0;
	ULONG g = 0;
	ULONG m = 0;
	INT32 r = 0;
	INT32 flgs = 0;
	INT32 ref = 0;
	INT32 use = 0;
	INT32 metric = 0;
	INT32 mtu = 0;
	INT32 win = 0;
	INT32 ir = 0;
	struct in_addr gw;
	INT32 ret = -1;
	FILE *fp = NULL;

	if ((NULL == interface_name) || (gateway_len < 16))
	{
		return ERROR;
	}
 
	memset(gateway_ip, 0, gateway_len);
	memset(&gw, 0, sizeof(struct in_addr));

	fp = fopen(ROUTE_FILE, "r");
	if(NULL == fp)
	{
		LTE4G_DEBUG(RT_ERROR, "open file failed %d\n", errno);
		return ERROR;
	}

	if (fscanf(fp, "%*[^\n]\n") < 0)
	{ /* Skip the first line. */
		fclose(fp);
		return ERROR;        /* Empty or missing line, or read error. */
	}
	
	while (1)
	{
		r = fscanf(fp, "%63s%lx%lx%X%d%d%d%lx%d%d%d\n",
				devname, &d, &g, &flgs, &ref, &use, &metric, &m, &mtu, &win, &ir);
		if (r != 11)
		{
			LTE4G_DEBUG(KEY_WARN, "get_gateway fscanf error and r=%d,errno=%d\n", r, errno);
			break;
		}

		if (!(flgs & RTF_UP))
		{ /* Skip interfaces that are down. */
			continue;
		}
		
		gw.s_addr   = g;

		if(flgs & RTF_GATEWAY)
		{
			if ( (0 == d) && (0 == m) && (0 != g))
			{
				/* ԭ��ʹ�� snprintf(p_gateway, len, "%s", inet_ntoa(gw));;
				 * ����inet_ntoa�ķ���ֵ�ǹ���һƬ�ڴ棬���̲߳�������ֵ�и��ʻ���ҵ�
				 * �����inet_ntopȡ��inet_ntoa����
				 */
				inet_ntop(AF_INET, &gw, gateway_ip, gateway_len);
				ret = OK;
				memcpy(interface_name, devname, strlen(devname));
				break;
			}
			
		}
	}

	fclose(fp);

	return ret;
}

BOOL mobile_dial_success(void)
{
	return !modem_ppp_failed;
} 


 

