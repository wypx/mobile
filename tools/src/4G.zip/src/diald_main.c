/**@file net_3g_app.c
 * @note HangZhou Hikvision Digital Technology Co., Ltd. All Right Reserved.
 * @brief  3G/4G���̲�����������ڡ�
 * 
 * @author   xusen
 * @date     2014-2-25
 * @version  V1.0.0
 * 
 * @note ///Description here 
 * @note History:        
 * @note     <author>   <time>    <version >   <desc>
 * @note  
 * @warning  
 */
#include <sys/sysinfo.h>
#include "diald_main.h"
#include "diald_log.h"
#include "ipc_unix.h"
#include <sys/time.h>
#include <sys/socket.h>
#include <linux/netlink.h>


#define DEV_4G_USB1        "/dev/ttyUSB1"   /*longsung 8300*/
#define DEV_4G_USB4        "/dev/ttyUSB4"   /*huawei modem*/

#if defined(R2_PLAT)|| defined(E0_PLAT)
#define IDPRODUCT_PATH	"/sys/bus/usb/devices/1-1.2/idProduct"
#else
#define IDPRODUCT_PATH	"/sys/bus/usb/devices/1-1/idProduct"
#endif

/* various */
DIAL_CFG				*pDevDialParam = NULL;
SMS_PARAM				*pDevSmsParam = NULL;
COMMUNICATION_PARAM		*comm_param = NULL;
SHM_PARAM				*shareMemParam = NULL;
static int 				shmid = 0;
UINT32					bATComRcvd = 0;
pthread_t				tids[4] = {0};   /* tid[0]: dial task; tid[1]: AT write task, tid[2]: AT read task */
int						iErrCode = 0;
INT32 					g_fd_output = -1;	/* ���ض����豸��õ��������� */
INT32 					g_fd_stdout = -1;	/* ���Ʊ�׼�����������õ��������� */

static BOOL 			usb_up = TRUE;	//The default status of USB is up when device is power on.

/* �ⲿ���ñ��� */
//extern volatile int	modem_ppp_pid;		///< ��¼���Ž���ID������ɱ���ý���
extern PPP_PARAM 		ppp_param; 
extern int				atFd;
extern BOOL				bDisconFlag;
//extern BOOL			manualPause; 
extern SEND_SMS			sendSMSBuf[MAX_SENDSMS_ONCE];
extern pthread_mutex_t	rilSem;
extern UINT32			bTastExitStatus;
extern time_t			startWriteTime;

/* �ڲ���̬�ӿ����� */
static int get_shm_lte4g(COMMUNICATION_PARAM **pdata);
static int reset3gModule();
static int wirelessDrvHandler(UINT methold);
static void initShm(void);
static void dialInitShm(void);
static int dialCmdProc(void);
static void moblie_lte4g_init(void);
int check_file_exist(char* filename);
int mobile_check_usb_lost(SHM_PARAM* sm);
static void mobile_detect_usb_down(void);
static void mobile_detect_usb_up(void);
static INT32 mobile_check_usb_device_status(void);

extern int redirection_output(const INT8 *device_name, INT32 *fd_output, INT32 *fd_stdout);
extern int rdirection_output_cancle(INT32 *fd_output, INT32 *fd_stdout);
INT32 mobile_service_task(INT8 *data, UINT32 *data_len, UINT32 load_type);
extern MODEM_DIAL_STAT mobile_get_modem_stat(void);
extern void mobile_set_modem_stat(MODEM_DIAL_STAT currdialStat);
extern int mobile_AT_reset_module(void* AT_data, char* response);


/**@brief         ���ӹ����ڴ�
 * @param[in]     none
 * @param[out]    pdata:�����ڴ��ַ
 * @return        OK:0;ERROR:-1
 */
static int get_shm_lte4g(COMMUNICATION_PARAM **pdata)
{
	/* ȡ�ù����ڴ�key�������û�����ͽ���(IPC_CREAT) */
	if ((shmid = shmget(SHMKEY, sizeof(COMMUNICATION_PARAM), 0600|IFLAGS)) < 0)
	{
		if (errno == EEXIST)
		{
			shmid = shmget(SHMKEY, sizeof(COMMUNICATION_PARAM), 0600|IPC_CREAT);
			if (shmid < 0)
			{
				LTE4G_DEBUG(RT_ERROR, "shmget err1: 0x%x\n", errno);
				return ERROR;
			}
			LTE4G_DEBUG(DEBUG_INFO, "*** shmget ATTACH.\n");
		}
		else
		{
			LTE4G_DEBUG(RT_ERROR, "shmget err2: 0x%x\n", errno);
			return ERROR;
		}
	}
		/* ȡ�ù����ڴ��ָ�� */
	if ((*pdata = (COMMUNICATION_PARAM*)(shmat(shmid, 0, 0))) == NULL)
	{
		LTE4G_DEBUG(RT_ERROR, "shmat err3: 0x%x\n", errno);
		return ERROR;
	}
	
	return OK;
}


/**@brief		  ���ӹ����ڴ�
 * @param[in]	  len:���ݳ���
 * @param[in]	  pBuf:���ݻ���ָ��
 * @param[out]	  ��
 * @return       У���sum
 */
unsigned int check_sum_16(UINT16 *pBuf, int len)
{
	int nLeft = len;
	unsigned short *w = pBuf;
	unsigned int sum = 0;

	if(w == NULL)
	{
		return 0;
	}

	while (nLeft > 1)
	{
		sum += *w++;
		nLeft -= 2;
	}

	if (nLeft == 1)
	{
		sum += *(unsigned char *)w;
	}

	return sum;
}

/**@brief		  3G/4G�������ػ�ж��
 * @param[in]	  methold:������ʽ�����ػ�ж��
 * @param[out]	  ��
 * @return       OK:0,ERROR:-1
 */
static int wirelessDrvHandler(UINT methold)
{
	int sleep_count = 0;
	
	if (methold > RMMOD_WIRELESS_DRV)
	{
		return ERROR;
	}
	
	if (methold == INSMOD_WIRELESS_DRV)
	{
		LTE4G_DEBUG(DEBUG_INFO, "insmod mobile drivers \n");
#if defined (R7_HI3516A)
		(void)hik_insmod("/home/r7_module/hikdrv/usbserial.ko");
		(void)hik_insmod("/home/r7_module/hikdrv/usb_wwan.ko");
		(void)hik_insmod("/home/r7_module/hikdrv/option.ko");
#elif	(defined AM_S2) ||(defined R6_S2LM) || (defined DM8127)|| (defined G1_PLAT)
		(void)system("modprobe usbserial.ko");
		(void)system("modprobe usb_wwan.ko");
		(void)system("modprobe option.ko");
#elif	(defined DM385)
		(void)hik_insmod("/home/usbserial.ko");
		(void)hik_insmod("/home/usb_wwan.ko");
		(void)hik_insmod("/home/option.ko");
#else
		(void)hik_insmod("/dav/usbserial.ko");
		(void)hik_insmod("/dav/usb_wwan.ko");
		(void)hik_insmod("/dav/option.ko");
#endif
		/*����4G������������ļ����ļ���*/
		(void)system("echo 0x1c9e 0x9b05 > /sys/bus/usb-serial/drivers/option1/new_id");  // ������Ըĳ�д���ļ���Ŀǰ������д

		//ģ��ʶ��ʱ�䣬8300Cģ�����ǰLMϵ��ģ������ʱ���10s���ң������޸ĳ�ѭ����⣬����Ӱ������ģ��ʶ���ٶ�
		while(check_file_exist(DEV_4G_USB) != OK
			&& sleep_count++ < 20)
		{
			sleep(1);
		}	
#ifdef DM385
		//385�豸Ӳ���������⣬�������ݣ��豸����֮��4Gģ�����û�м��ء�
		while(check_file_exist(IDPRODUCT_PATH) != OK)
		{
			system("echo f > /proc/driver/musb_hdrc.0");
			sleep(1);
			system("echo F > /proc/driver/musb_hdrc.0");
			sleep(28);	//�ϵ�������ʶ���ʱ���������Ҫ26s���ң�28s�Ƚϰ�ȫ
			while(check_file_exist(DEV_4G_USB) != OK
			&& sleep_count++ < 20)
			{
				sleep(1);
			}
		}	
#endif
	}
	else if (methold == RMMOD_WIRELESS_DRV)
	{
		LTE4G_DEBUG(DEBUG_INFO, "<umount option.ko>\n <umount usb_wwan.ko>\n <umount usbserial.ko>\n");
#if defined (R7_HI3516A)
		(void)hik_rmmod("/home/r7_module/hikdrv/usbserial.ko",RMMOD_MODE_NONE);
		(void)hik_rmmod("/home/r7_module/hikdrv/usb_wwan.ko",RMMOD_MODE_NONE);
		(void)hik_rmmod("/home/r7_module/hikdrv/option.ko",RMMOD_MODE_NONE);
#elif	(defined AM_S2) ||(defined R6_S2LM) || (defined DM8127) || (defined(G1_PLAT))
		(void)system("rmmod usbserial.ko");
		(void)system("rmmod usb_wwan.ko");
		(void)system("rmmod option.ko");
#elif	(defined DM385)
		(void)hik_rmmod("/home/option.ko",RMMOD_MODE_NONE);
		(void)hik_rmmod("/home/usb_wwan.ko",RMMOD_MODE_NONE);
		(void)hik_rmmod("/home/usbserial.ko",RMMOD_MODE_NONE);
#else
		(void)hik_rmmod("/dav/option.ko",RMMOD_MODE_NONE);
		(void)hik_rmmod("/dav/usb_wwan.ko",RMMOD_MODE_NONE);
		(void)hik_rmmod("/dav/usbserial.ko",RMMOD_MODE_NONE);
#endif
	}
	return OK;
}

/**@brief		  �����ڴ����ݳ�ʼ��
 * @param[in]	  ��
 * @param[out]	  ��
 * @return       ��
 */
static void initShm(void)
{
	if(NULL == shareMemParam)
	{
		return;
	}
	
	if (0 == shareMemParam->manualPause)	/* δ���յ�ֹͣ�������� */
	{
		shareMemParam->online = 1;					
	}

	mobile_signal = 0;	
	shareMemParam->pid = -1;
	shareMemParam->initFinish = 0;

	return;
}

/**@brief		  3G/4G������������ʼ��
 * @param[in]	  ��
 * @param[out]	  ��
 * @return       ��
 */
static void dialInitShm(void)
{
	memcpy(shareMemParam->cellNumber, pDevSmsParam->phone,
		(sizeof(PHONE_CFG) * MAX_WHITELIST_NUM));
	
	shareMemParam->smsReadStat = pDevSmsParam->lSmsReadStat;
	
	if (pDevDialParam->byDialMethod == 1)
	{
		shareMemParam->manualPause = 1;
	}

	initShm();

	return;
}

/**@brief		  3G/4G���������
 * @param[in]	  ��
 * @param[out]	  ��
 * @return       OK:0,ERROR:-1,CHECK_ERR:-2
 */
static int dialCmdProc(void)
{
	int i = 0;
	
	for (i = 0; i < MAX_SHM_ATCOM_NUM; i++)
	{
		if (strlen(shareMemParam->ATComBuf[i]) != 0)
		{
			if (strcmp(shareMemParam->ATComBuf[i], "killd") == 0) /* ɱ��diald���̣������� */
			{
				iErrCode = EXIT_DIAL_ABNORMAL;
				memset(shareMemParam->ATComBuf[i], 0, MAX_SHM_ATCOM_LEN);
				return -2;
			}
			else if (strcmp(shareMemParam->ATComBuf[i], "autodial") == 0)
			{
				pDevDialParam->byDialMethod= 0;
			}
			else if (strcmp(shareMemParam->ATComBuf[i], "manualdial") == 0)
			{
				pDevDialParam->byDialMethod = 1;
			}
			else if (strcmp(shareMemParam->ATComBuf[i], "autoswitch") == 0)
			{
				pDevDialParam->bySwitchMethold= SWITCH_METHOLD_AUTO;
			}
			else if (strcmp(shareMemParam->ATComBuf[i], "2gswitch") == 0)
			{
				if (MODE_EVDO == mobile_mode)
				{
					pDevDialParam->bySwitchMethold = SWITCH_METHOLD_2G;
				}
				else if ((MODE_WCDMA == mobile_mode) || ( MODE_TDSCDMA == mobile_mode))
				{
					if (CREG_STAT_REGISTED_LOCALNET == mobile_reg2gInfo)
					{
						pDevDialParam->bySwitchMethold = SWITCH_METHOLD_2G;
					}
					else
					{
						LTE4G_DEBUG(RT_ERROR, "2G networks has not registered\n");
					}
				}
			}
			else if (strcmp(shareMemParam->ATComBuf[i], "3gswitch") == 0)
			{
				if (MODE_EVDO == mobile_mode)
				{
					pDevDialParam->bySwitchMethold = SWITCH_METHOLD_3G;
				}
				else if ((MODE_WCDMA == mobile_mode) || (MODE_TDSCDMA == mobile_mode))
				{
					if (CREG_STAT_REGISTED_LOCALNET == mobile_reg3gInfo)
					{
						pDevDialParam->bySwitchMethold = SWITCH_METHOLD_3G;
					}
					else
					{
						LTE4G_DEBUG(RT_ERROR, "3G networks has not registered\n");
					}
				}
			}
			else if (strcmp(shareMemParam->ATComBuf[i], "discon") == 0)
			{
				iErrCode = EXIT_DIAL_ABNORMAL;
				memset(shareMemParam->ATComBuf[i], 0, MAX_SHM_ATCOM_LEN);
				return -2;
			}
			else if (strcmp(shareMemParam->ATComBuf[i], "exit") == 0)
			{
				LTE4G_DEBUG(RT_ERROR, "shareMemParam exit .\n");
				iErrCode = EXIT_DIAL_FATALERR;
				return -2;
			}
			else if (atFd != ERROR)
			{
				pthread_mutex_lock(&rilSem);				
				bATComRcvd |= 1 << i; 
				pthread_mutex_unlock(&rilSem);
				continue;
			}
			memset(shareMemParam->ATComBuf[i], 0, MAX_SHM_ATCOM_LEN);
		}
	}

	return OK;
}


/**@brief		  ϵͳ����ʱ��
 * @param[in]	  ��
 * @param[out]	  ��
 * @return       ϵͳ��������˶��
 */
unsigned int sys_device_uptime(void)
{
	unsigned int uptime = 0;
	struct sysinfo info;
	(void)sysinfo(&info);
	uptime = info.uptime;
	return uptime;
}


 /** @fn
  *  @brief  ����ļ��Ƿ����	   
  *  @param[in]  char*dbname ���ݿ���
  *  @return  OK �ļ�����
  * 		    ERROR  �ļ�������
  */
 int check_file_exist(char* filename)
 {
	 int ret = ERROR;
	 
	 if(filename != NULL)
	 {
		 ret = access(filename, R_OK|W_OK); 
	 }

	 return (ret >= 0) ? OK : ERROR;
 }
  /** @fn
  *  @brief  usb��������ͷ���Դ�����ϵ�,USB����Ծ�����
  *  @param[in]  SHM_PARAM* sm
  *  @return  OK 	
  * 		  ERROR 
  */
int mobile_check_usb_lost(SHM_PARAM* sm)
{
	int ret = OK; /* modem hasn't been recognised yet, skip check*/
	if(!sm){
		return ERROR;
	}
	if(sm->iModel == M_U8300){
		ret = check_file_exist(DEV_4G_USB1);
		
	}else if(sm->iModel == M_HUAWEI_4G 
		  || sm->iModel == M_HUAWEI_3G){
		ret = check_file_exist(DEV_4G_USB4);
	}
	else{
		/* modem hasn't been recognised yet*/
	}
	if(ERROR == ret){
		iErrCode = EXIT_DIAL_ABNORMAL;
		return ERROR;
	}
	return OK;
}
  
int set_shm_param(COMMUNICATION_PARAM* comm_parammeter)
{
	if(NULL == comm_parammeter)
	{
		LTE4G_DEBUG(RT_ERROR, "set_sh_param enter\n");
		return ERROR;
	}

	shareMemParam = &comm_parammeter->shm_param;
	pDevDialParam = &comm_parammeter->struDialCfg;
	pDevSmsParam = &comm_parammeter->struSmsParam;

	return OK;
}


/**@brief		  4G��ز�����������ʼ��
 * @param[in]	  ��
 * @param[out]	  ��
 * @return       ��
 */
static void moblie_lte4g_init(void)
{
	
	// �򿪻򴴽������ڴ�
	if (ERROR == get_shm_lte4g(&comm_param))
	{
		LTE4G_DEBUG(RT_ERROR, "get_shm_lte4g failed. \n");
		dial_exit(EXIT_DIAL_FATALERR);
	}

	//����ȫ�ֱ���ֵ	
	(void)set_shm_param(comm_param);

	//�ж��Ƿ�����PPPoE
	if(comm_param->enablePPPoE)
	{
		LTE4G_DEBUG(RT_ERROR, "The device is enable pppoe\n");
		dial_exit(EXIT_DIAL_FATALERR);
	}

	//�ж��Ƿ�ʹ��4G
	if(!pDevDialParam->byEnableMobile)
	{
		LTE4G_DEBUG(RT_ERROR, "Disable 3G/4G .\n");
		dial_exit(EXIT_DIAL_FATALERR);
	}
	
	//���õ�ǰ4G�Ĳ���
	memset(&shareMemParam->realMobileStat, 0, sizeof(MOBILE_STATUS));

	//��ʼ�������ڴ����
	dialInitShm();

	// ����4GоƬ����
	(void)wirelessDrvHandler(INSMOD_WIRELESS_DRV);

	return;
}


/**@brief		  3G�����������̽����
 * @param[in]	  ��
 * @param[out]	  ��
 * @return       ��
 */
int main(int argc, char *argv[])
{
	int ret = -1;
	pthread_t check_tid;
	time_t nowTime, lastTime = time(NULL);	

	LTE4G_DEBUG(DEBUG_INFO, "\n\n ###start to 4G diald###\n\n");
	
	//��ʼ��4Gģ���������������
	moblie_lte4g_init();

	shareMemParam->pid = getpid();

	mobile_log_write("diald pid = %d\n", shareMemParam->pid);

	/* ��Ҫ����4G ����δ֪�˳������� */
	//(void)remove("/home/diald");

	ipc_unix_init(IPC_UNIX_MOBILE_NAME, IPC_UNIX_MOBILE_PROCESS, (p_service_task_f)mobile_service_task);

	if ((ret = pthread_create(&check_tid, NULL, (void *)&mobile_check_usb_device_status, NULL)) != OK)
	{
		mobile_log_write("pthread_create check_mobile_usb_status err, ret = %d\n", ret);
		LTE4G_DEBUG(RT_ERROR, "<main>: pthread_create check_mobile_usb_status err, ret = %d\n", ret);
		dial_exit(EXIT_DIAL_FATALERR);
	}

	mobile_log_init();
	
RESTART:
	
	while(!usb_up)
	{
		pthread_testcancel();
		sleep(1);
	}

	/* ����pppd �����߳� */
	if ((ret = pthread_create(&tids[INIT_DIAL_THREAD], NULL, (void *)&initDial, NULL)) != OK)
	{
		mobile_log_write("pthread_create initDial err, ret = %d\n", ret);
		LTE4G_DEBUG(RT_ERROR, "<main>: pthread_create initDial err, ret = %d\n", ret);
		dial_exit(EXIT_DIAL_FATALERR);
	}

	LTE4G_DEBUG(DEBUG_INFO, "creat initDial finsih\n");
	
	/* ����AT����ͨ���߳� */
	if ((ret = pthread_create(&tids[INIT_AT_THREAD], NULL, (void *)&initATChannel, NULL)) != OK)
	{
		mobile_log_write("pthread_create initATChannel err, ret = %d\n", ret);
		LTE4G_DEBUG(RT_ERROR, "<main>: pthread_create initATChannel err, ret = %d\n", ret);
		dial_exit(EXIT_DIAL_FATALERR);
	}	

	LTE4G_DEBUG(DEBUG_INFO, "creat initATChannel finsih, let's goto FOREVER\n");

	FOREVER
	{
		/* check usb stat */
		mobile_check_usb_lost(shareMemParam);
		
		// �ж��Ƿ�Ҫ�ͷ�USB�������Ĳ�����Դ
		if (iErrCode != 0) 		  //��Ҫ�ͷ�
		{
			if (OK == dial_release())
			{
				dial_handle_error(iErrCode);
				LTE4G_DEBUG(DEBUG_INFO, "handle error ok!\n");
				iErrCode = 0;
				//�������Դ�ͷųɹ�֮���ٴν���3G/4G����
				goto RESTART;
			}
			else
			{
				mobile_log_write("release usb resources failed\n");
				LTE4G_DEBUG(RT_ERROR, "release usb resources failed!\n");
				sleep(2);
				continue;
			}
		}

		if(-2 == dialCmdProc())
		{
			continue;
		}		
		
		if (TRUE == shareMemParam->exitDial)
		{
			iErrCode = EXIT_DIAL_MANUAL;
			continue;
		}

		if (TRUE == shareMemParam->stopDial)
		{
			/* Dial-Status: a-STOP_DIAL */ 
			mobile_set_modem_stat(DIAL_STOP_DIAL);
			shareMemParam->stopDial = FALSE;
		}
				
		nowTime = time(NULL);
		if (abs(nowTime - lastTime) > 5)
		{
			/* AT����д��������ʾ�����������⣬������ */
			if (startWriteTime)
			{
				if ((abs(nowTime - startWriteTime) > 20) && (abs(nowTime - startWriteTime) < 30))
				{
					mobile_log_write("write block, reinstall drv\n");
					LTE4G_DEBUG(RT_ERROR, "#### write block for a while, reinstall drv\n");
					iErrCode = EXIT_DIAL_ATBLOCK;
					startWriteTime = 0;
					continue;
				}
			}

			lastTime = nowTime;
		}
		usleep(100*1000);
	}	
	
	return 0;
}

/**@brief         exit the dial process 
 * @param[in]     int iExitCode: exit number
 * @param[out]    none
 * @return        none
 */
void dial_exit(int iExitCode)
{
	if (shareMemParam != NULL)
	{   
		shareMemParam->online = 0;
		mobile_signal = 0;
		mobile_mode = MODE_NONE;
		/* detaches the shared memory segment */
		if (0 != shmdt(shareMemParam))
		{
			LTE4G_DEBUG(RT_ERROR, "shmdt error: 0x%x\n", errno);
		}
	}
	exit(iExitCode);
}

/**@brief         �ͷ����иý�����ռ�õ���Դ
 * @param[in]     ��
 * @param[out]    ��
 * @return        0: ok; -1: failed
 */
int dial_release(void)
{
	void *tret = NULL;
	int status = 0, pid = 0;
	int iRet = 0;
	unsigned int i = 0; 
	
	/* release the pppd */
	(void)modem_finiPPP();

	LTE4G_DEBUG(RT_ERROR, "dial_release start \n");
	
	//�ͷ����еĸý����е��߳�
	for (i = 0; i < (sizeof(tids)/sizeof(pthread_t)); i++)
	{ 
		if (tids[i])
		{
			iRet = pthread_cancel(tids[i]);
			if (iRet != 0 && errno != ESRCH && errno !=  ENOENT && errno !=  ECHILD )
			{ 
				mobile_log_write("[%d]pthread_cancel error: 0x%x\n", i, errno);
				LTE4G_DEBUG(RT_ERROR, "[%d]pthread_cancel error: 0x%x\n", i, errno);
				return ERROR;
			}

			iRet = pthread_join(tids[i], &tret);
			if (iRet != 0 && errno != ESRCH && errno !=  ENOENT && errno !=  ECHILD)
			{
				mobile_log_write("pthread_join error: 0x%x\n", errno);
				LTE4G_DEBUG(RT_ERROR, "pthread_join error: 0x%x\n", errno);
				return ERROR;
			}
			LTE4G_DEBUG(DEBUG_INFO, "number %d task %d exit succeed\n", i, (int)tids[i]);
			tids[i] = 0;
		}
	}

	//ȷ����ǰpppd�����Ѿ����˳�
	if (modem_ppp_pid > 0)
	{
		LTE4G_DEBUG(RT_ERROR, "modem_ppp_pid = %d\n", modem_ppp_pid);
		pid = waitpid(modem_ppp_pid, &status, 0);
		if (pid != -1)
		{
			LTE4G_DEBUG(DEBUG_INFO, "pppd process %d exit\n", pid);
		}
	}

	//��AT����ռ�õ�USB�ڽ����ͷţ�ȷ���ٴν��в��ź�AT�����ʱ���������Դ��ռ��
	releaseATChannel();
	
	LTE4G_DEBUG(DEBUG_INFO, "release all! take a look at ps\n");
	
	return OK;
}

/**@brief         handle the error of wireless modem
 * @param[in]     int iErrCode: error code
 * @param[out]    none
 * @return        none
 */
void dial_handle_error(int ErrCode)
{	
	static int iCountErrorTimes = 0;	/* count the error times of the wireless modem */
	static int iLastErrorTime = 0;		/* last time when the error occured */
	static int iRedialCycle = 10;		/* sleep for a while, then redial again */
	initShm();
	
	/*ֱ�ӽ���������ӡ������*/
	mobile_log_write("dial_handle_error iErrCode = %d\n", ErrCode);
	LTE4G_DEBUG(RT_ERROR, "dial_handle_error iErrCode = %d\n", ErrCode);
	switch(ErrCode)
	{
		case EXIT_DIAL_FATALERR:
			//�˴������ǽ���Ī���˳���ԭ��
			dial_exit(EXIT_DIAL_FATALERR);
			break;
		case EXIT_DIAL_INSTABLE:
		case EXIT_DIAL_MANUAL:
		case EXIT_DIAL_MODEMERR:
		case EXIT_DIAL_USBDOWN:
			break;
		case EXIT_DIAL_ATBLOCK:
		case EXIT_DIAL_ABNORMAL:
			/* Dial-Status: c-REINST_DRIVE */
			mobile_set_modem_stat(DIAL_REINST_DRIVE);
			sleep(2);			// �ȴ��ں��ͷ���Դ

			// ж������
			(void)wirelessDrvHandler(RMMOD_WIRELESS_DRV);
			if (++iCountErrorTimes >= 2)
			{
				while (shareMemParam->bUpgrading || 
				shareMemParam->bFormating || shareMemParam->bBackuping)
				{
					sleep(10); //
				}
				mobile_set_modem_stat(DIAL_CUTOFF_POWER);

				iCountErrorTimes = 0;
			}

			// ��������
			(void)wirelessDrvHandler(INSMOD_WIRELESS_DRV);

			//����ʼ���Ƿ������ΪFALSE
			shareMemParam->initFinish = FALSE;

			if (abs(time(NULL) - iLastErrorTime) <= (iRedialCycle + 80)) /* Ϊ�˷�ֹ�豸Ƶ�����أ����������ؼ�� */
			{
				iRedialCycle += 10;
			}
			else
			{
				iRedialCycle = 10;
			}
			iLastErrorTime = time(NULL);
			iRedialCycle = (iRedialCycle > 120)? 120 : iRedialCycle; /* �120�� */

#if 0
			//����Ӳ������ӿ����ж����������(������Ҫ����֧��4G��ƽ̨,��֧5.4.16 R2 �� 5.4.20 R7�Ѿ�֧��,������ֲ)
			shareMemParam->usb_power_reset = TRUE;//ģ��Ӳ�ϵ�

			//ֱ�������־����λ������main�����ȴ�
			while(shareMemParam->usb_power_reset){
					pthread_testcancel();
					sleep(2);
			}
			while(check_file_exist(DEV_4G_USB) != OK){
				pthread_testcancel();
				sleep(2);	
			}

#endif		
			break;
        case EXIT_DIAL_MODULERESET:
			mobile_AT_reset_module(NULL, NULL);
            /*
             * This command will restart 4G module, we will wait until module starting up. 
             */
			while(mobile_check_usb_lost(shareMemParam) != OK)
				sleep(2);
            break;
		default:
			break;
	}

	if (shareMemParam->exitDial)    /* ֹͣdiald���� */
	{
		LTE4G_DEBUG(DEBUG_INFO, "wait for dial exit...\n");
		while(FALSE == shareMemParam->execDial) /* �ȴ����¿�ʼdiald���� */
		{
			sleep(1);
		}
		LTE4G_DEBUG(DEBUG_INFO, "dial exit!\n");
		shareMemParam->exitDial = FALSE;
		shareMemParam->execDial = FALSE;
	}
	else
	{
		LTE4G_DEBUG(DEBUG_INFO, "sleep %d\n",iRedialCycle);

		/* after sleep some seconds, then re-dial  */
		sleep(iRedialCycle);
		
	}
	return;
}

/**@brief         get the error code
 * @param[in]     none
 * @param[out]    none
 * @return        error code
 */
int mobile_get_dial_error(void)
{
	return iErrCode; 
}

/**@brief         when some error occured, we need to take recovering action. 
                  So we need to release all the resources occupied by wireless modem, 
                  and exit the task;
 * @param[in]     int iCode: error code
 * @param[out]    none
 * @return        none
 */
void dial_error_occur(int iCode)
{
	LTE4G_DEBUG(RT_ERROR, "error occur iCode:[%d]\n", iCode);
	if (iCode)
	{
		iErrCode = iCode;
		while(1)    /* sleep until this task is cancelled by main task */
		{
			pthread_testcancel();
			sleep(1);
		}
	}
	return;
}

INT32 mobile_service_task(INT8 *data, UINT32 *data_len, UINT32 load_type)
{
	int ret = -1;
	switch(load_type)
	{
		case BROADCAST_OUTPUT_OPEN:
			LTE4G_DEBUG(RT_ERROR,"receive REDIRECTION_OUTPUT_OPEN\n");
			ret = redirection_output(data, &g_fd_output, &g_fd_stdout);
			if (ERROR == ret)
			{
				LTE4G_DEBUG(RT_ERROR, "redirection_output failure.\n");
			}
			break;
		case BROADCAST_OUTPUT_CLOSE:
			LTE4G_DEBUG(RT_ERROR,"receive REDIRECTION_OUTPUT_CLOSE\n");
			ret = rdirection_output_cancle(&g_fd_output, &g_fd_stdout);
			if (ERROR == ret)
			{
				LTE4G_DEBUG(RT_ERROR, "rdirection_output_cancle failure.\n");
			}
			break;
		case BROADCAST_SET_DEBUG:
			ret = set_debug_para_withcheck(data, NULL, 0);
			if (ret != OK )
			{
				LTE4G_DEBUG(RT_ERROR, "set netprocess debug info err.\n");
			}
			break;
		default:
			break;
	}
	return  OK;
}


/**@brief         check usb devcice status
 * @param[in]     none
 * @param[out]    0/-1
 * @return        error code
 */
INT32 mobile_check_usb_device_status(void)
{
	int usb_fd = -1;
	struct sockaddr_nl snl;
	char buff[4096];
	size_t buff_size = sizeof(buff);
	char *buff_end = NULL;
	ssize_t read_size = -1;
	char *token_start = NULL;
	char *action_ptr = NULL;
	struct timeval time_stamp;
	char *devname_ptr = NULL;
	
	(void)prctl(15, (unsigned long)"MobileUSBStatus");

	memset(&snl, 0, sizeof(snl));
	memset(buff, 0, sizeof(buff));
	memset(&time_stamp, 0, sizeof(time_stamp));

	snl.nl_family = AF_NETLINK;
	snl.nl_pid = getpid();
	snl.nl_groups = 1;

	if ((usb_fd = socket(PF_NETLINK, SOCK_RAW, NETLINK_KOBJECT_UEVENT)) < 0) 
	{
		perror("socket ERROR");
		return EXIT_FAILURE;
	} 

	if (setsockopt(usb_fd, SOL_SOCKET, SO_RCVBUF, &buff_size, sizeof(buff_size)) != 0) 
	{
		perror("setsockopt ERROR");
		close(usb_fd);
		return EXIT_FAILURE;
	}

	if (bind(usb_fd, (struct sockaddr *)&snl, sizeof(struct sockaddr_nl)) != 0) 
	{
		perror("bind ERROR");
		close(usb_fd);
		return EXIT_FAILURE;
	}

	while (1) 
	{
		memset(buff,0, sizeof(buff));
		if ((read_size = recv(usb_fd, buff, sizeof(buff), 0)) >= 0) 
		{
			(void)gettimeofday(&time_stamp, NULL);
			buff[read_size] = '\0';
			token_start = buff;
			buff_end = buff + read_size;
			do 
			{
				if (0 == strncmp(token_start, "ACTION", strlen("ACTION"))) 
					action_ptr = token_start;
				else if (0 == strncmp(token_start, "DEVNAME", strlen("DEVNAME"))) 
					devname_ptr = token_start;
				else if (0 == strncmp(token_start, "SUBSYSTEM=usb_device", strlen("SUBSYSTEM=usb_device"))) 
				{
					LTE4G_DEBUG(RT_ERROR, "[%ld.%ld] %s, %s, %s\n",
						time_stamp.tv_sec, time_stamp.tv_usec, token_start, action_ptr, devname_ptr);
					action_ptr = token_start;
					if(strstr(action_ptr, "remove"))
						mobile_detect_usb_down();
					else if(strstr(action_ptr, "add"))
						mobile_detect_usb_up();
					else
						;
				}
				token_start = strchr(token_start, '\0');
			} while (token_start++ < buff_end);

			sleep(1);
		} 
		else 
		{
			perror("read ERROR");
			close(usb_fd);
			return EXIT_FAILURE;
		}
	}
	
	close(usb_fd);
	return EXIT_SUCCESS;
}

void mobile_detect_usb_down(void)
{
	LTE4G_DEBUG(RT_ERROR, "mobile detect usb down\n");
	iErrCode = EXIT_DIAL_USBDOWN;
	usb_up = FALSE;
}


void mobile_detect_usb_up(void)
{
	LTE4G_DEBUG(RT_ERROR, "mobile detect usb up\n");
	usb_up = TRUE;
}
