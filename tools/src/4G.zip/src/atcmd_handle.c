/**@file atcmd_handle.c
 * @note HangZhou Hikvision Digital Technology Co., Ltd. All Right Reserved.
 * @brief  3G/4G����֮���AT������߳�
 * 
 * @author   xusen
 * @date     2014-2-25
 * @version  V1.0.0
 * 
 * @note ///Description here 
 * @note History:        
 * @note     <author>   <time>    <version >   <desc>
 * @note  
 * @warning  
 */

#ifdef WIRELESS_MODEM

#include "atcmd_handle.h"
#include "diald_log.h"

#define RESOLV_FILE		"/etc/resolv.conf"
#define ROUTE_FILE		"/proc/net/route"
#define HEAD			node.next		/* first node in list */
#define TAIL			node.previous		/* last node in list */
#define PPP_INTERFACE	"ppp0"

#if 0
#ifdef R2_PLAT
#define IDPRODUCT_PATH	"/sys/bus/usb/devices/1-1.2/idProduct"
#else
#define IDPRODUCT_PATH	"/sys/bus/usb/devices/1-1/idProduct"
#endif
#endif

#define IDPRODUCT_PATH "/proc/bus/usb/devices"
#define MAX_SMS_LEN	140

#define FD_USB_DOWN -2

/* ȫ�ֱ��� */
SMS_FORMAT				smsFormat = -1;		/*���Ÿ�ʽ����text��pdu*/
int						atFd = ERROR;
pthread_mutex_t			rilSem = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t			atFdSem = PTHREAD_MUTEX_INITIALIZER;
AT_Response				atResponse;
static char				s_ATBuffer[MAX_AT_RESPONSE + 8] = {0};        /*���ڽ���ATָ����Ӧ��buffer*/
static char				*s_ATBufferCur = s_ATBuffer;                    /*ȫ��ָ��,ָ��ǰATResponse�Ѷ���λ��*/
char					SMSCenter[20]={0};      /* �������ĺ��� */
//BOOL					manualPause = 0;		/* flag: 1-dial is paused manually; 0-dial is paused automatically */
int						serviceExist = 0;
int						signalExist = 0;
BOOL					bDisconFlag = 0; 
COPS_INFO				copsInfo[COPS_MAX_NETWORKS];
COPS_INFO				curCopsInfo;
UINT32					bTastExitStatus = 0;	/* �ñ�־������ĳһλ��1��ʾĳ���߳�(����)����ִ��: 
							0λ:ATReaderLoop�߳�; 1λ: checkModemStatus�߳�; 2λ:pppd���Ž��� */
SEND_SMS				sendSMSBuf[MAX_SENDSMS_ONCE];
SMS_STATUS				sms_status[MAX_SMSLIST_NUM + 1];
int						smsNum = 0;
time_t 					startWriteTime = 0; 

#ifdef NET3G_SDK
						/* 0-8��1-16��2-32��3-64��4-128��5-256��6-384��7-512��8-1152��9-1536��10-2048 */
UINT16					nQosBitRateIdx[] = {8, 16, 32, 64, 128, 256, 384, 512, 1152, 1536, 2048};
#endif

#ifdef LAST_RESP
LAST_RESP_T				lastRsp;
#endif

MODEM_MODEL strModel[] =
{
	{"U7500",		M_U7500},
	{"C7500",		M_C7500},
	{"U8300",		M_U8300},
	{"LM91XX",		M_LM91XX},
	{"HUAWEI_3G",	M_HUAWEI_3G},
	{"HUAWEI_4G",	M_HUAWEI_4G},
};

/* �ⲿ���ñ��� */ 
extern DIAL_CFG			*pDevDialParam;
extern SHM_PARAM		*shareMemParam;
extern UINT32			bATComRcvd;
extern pthread_t		tids[4];
extern int				iErrCode;

/* �ڲ���̬���� */
static int writeCtrlZ(int fd, const char *s, int len);
static int strStartsWith(const char *line, const char *prefix);
static char * findNextEOL(char *cur);
static const char *readLine();
static int waitATResponse(const char* startString, char* fullString,
				int fullLen, BOOL breakWhileError, int waitTick);
static void releaseATResponse();
static void releaseATResponse();
static int prepareATResponse();
int writeATCommand(int fd, const char *s, const char* startString, char* fullString,
                int fullLen, BOOL breakWhileError, int waitTick);
static void ATReaderLoop(void);
static void atPrintf(const char *stringline);
static int add_atcmd_buff(char * line);
static void initSmParam(SM_PARAM *pDst, const char* phoneNum,const char* message);
static BOOL isCSQRecieve(const char* line);
static BOOL isCertainResponse(const char* line, char* strcomp1, char *strcomp2,
		char *strcomp3);
static BOOL isPhoneNumSame(const char* phone1, const char* phone2);
static int ATReceiveNotes(const char* line1);
static int ATReadSMS(const char* line1, const char* line2, int index,
		int	line2Len, SMS_STATUS * smsStatus, BOOL bNewSms);
static void ATReceiveACall(const char* line);
static void ATReceiveMode(const char* line);
static void ATReceiveFilter(void);
static void ATReceivePSRAT(const char* line);
static void ATReceiveSYSINFO(const char* line);
static void ATReceiveCSQ(const char* line);
static void ATReceiveCFUN(const char*line);
static void ATReceiveCOPS(const char*line);
static void ATReceiveCREG(const char* line);
static void ATRecvOtherResponse(const char *content);
static int getModemName(char * modemName);
static int getPsPart(const char *line );
static int getSysinfo(const char *line );
static int getSCA(const char * line);
const char* getModType(const char * line);
static int getRSSI(const char * line);
static int getSyscfg(const char * line);
static UINT64 getSMSExist(const char * line);
static int getPinInfo_PinAndPuk_times();
static int getPinInfo(const char * line);
static int getPinTimes(const char * line);
static int getPinLockStatus(const char * line);
static int findATChannel(void);
static BOOL check_is_need_receipt(SEND_SMS *send_sms);
static void set_sms_receipt_operation(int whitelist_index, SMS_RECEIPT_OPERATION ceceipt);
static int 	mobile_reregister_network(void);

//�ⲿ����
extern BOOL getDialStatus(void);
extern int  get_continuous_dial_failed_times(void); 
extern int set_ppp_param(MODEM_MODE mode_name);
extern int mobile_AT_get_SMS_center_num(void* AT_data, char *response);
extern int mobile_AT_set_new_pincode(void* AT_data, char *response);
extern int mobile_AT_check_sim_isLock(void* AT_data, char* response);
extern int mobile_AT_get_4G_status(void* AT_data, char* response);
extern int mobile_AT_get_3G_status(void* AT_data, char* response);
extern int mobile_AT_get_2G_status(void* AT_data, char* response);
extern int mobile_AT_list_sim_operator(void* AT_data, char *response);
extern int mobile_AT_list_all_operators(void* AT_data, char *response);
extern int mobile_AT_get_search_network_mode(void* AT_data, char* response);
extern int mobile_AT_get_signal(void* AT_data, char* response);
extern int mobile_AT_list_operator_by_numeric(void* AT_data, char *response);
extern int mobile_AT_get_phone_function(void* AT_data, char* response);
extern int mobile_AT_set_phone_function(void* AT_data, char *response);
extern int mobile_AT_set_search_network_mode(void* AT_data, char* response);
extern int mobile_AT_get_chip_type(void* AT_data, char* response);
extern int mobile_AT_check_sim_isLock(void* AT_data, char* response);
extern int mobile_AT_get_pin_puk_times(void* AT_data, char* response);
extern int mobile_AT_set_echo_status(void* AT_data, char *response);
extern int mobile_AT_set_auto_register(void* AT_data, char *response) ;
extern int mobile_AT_get_network_service_type(void* AT_data, char* response);
extern int mobile_AT_get_software_version(void* AT_data, char *response);
extern int mobile_AT_set_caller_ID(void* AT_data, char *response);
extern int mobile_AT_set_TE_status(void* AT_data, char *response);
extern int mobile_AT_set_SMS_storage_area(void* AT_data, char *response);
extern int mobile_AT_set_SMS_format(void* AT_data, char *response);
extern int mobile_AT_set_PDP_status(void* AT_data, char *response);
extern int mobile_AT_clear_APN(void* AT_data, char *response);
extern int mobile_AT_set_APN(void* AT_data, char *response);
extern int mobile_AT_set_QOS_request_briefing(void* AT_data, char* response);
extern int mobile_AT_check_sms_exist(void* AT_data, char *response);
extern int mobile_AT_read_SMS(void* AT_data, char *response);
extern int mobile_AT_unlock_pincode(void *AT_data, char *response);
extern int mobile_AT_set_chip_error_level(void* AT_data, char *response);
extern int mobile_AT_get_network_sysinfo(void* AT_data, char *response);
extern int AT_clean_sms(SMS_FORMAT sms_format, SMS_CLEAN_MODE sms_clean_mode, char* response);
extern int mobile_AT_set_pre_APN(void* AT_data, char *response);
extern int mobile_AT_set_auto_APN(void* AT_data, char* response);
extern int mobile_AT_get_sim_status(void* AT_data, char* response);
extern int mobile_AT_reset_module(void* AT_data, char* response);
extern MODEM_DIAL_STAT mobile_get_modem_stat(void);
extern void mobile_set_modem_stat(MODEM_DIAL_STAT currdialStat);
extern  int check_file_exist(char* filename);
extern int mobile_check_usb_lost(SHM_PARAM* sm);
 

/**@brief         initialize a list descriptor
 * @param[in]     pList:����ʼ��������
 * @param[out]    ��
 * @return        ��
 */
void lstInit(LIST *pList)
{
	if(NULL == pList)
	{
		LTE4G_DEBUG(RT_ERROR, "lstInit: input NULL\n");
		return;
	}
	pList->HEAD  = NULL;
	pList->TAIL  = NULL;
	pList->count = 0;
}


/**@brief         add a node to the end of a list
 * @param[in]     pList:Ŀ������
 * @param[in]     pNode:������Ľ��
 * @param[out]    ��
 * @return        ��
 */
void lstAdd(LIST *pList, NODE *pNode)
{
	if(NULL == pList || NULL == pNode)
	{
		LTE4G_DEBUG(RT_ERROR, "lstAdd: input NULL\n");
		return;
	}
	lstInsert (pList, pList->TAIL, pNode);
}


/**@brief         report the number of nodes in a list
 * @param[in]     pList:Ŀ������
 * @param[out]    ��
 * @return        �����
 */
int lstCount(LIST *pList)
{
	if(NULL == pList)
	{
		LTE4G_DEBUG(RT_ERROR, "lstCount: input NULL\n");
		return 0;
	}

	return (pList->count);
}


/**@brief         delete a specified node from a list
 * @param[in]     pList:Ŀ������
 * @param[in]     pNode:��ɾ���Ľ��
 * @param[out]    ��
 * @return        ��
 */
void lstDelete(LIST *pList,NODE *pNode)
{
	if(NULL == pList || NULL == pNode)
	{
		LTE4G_DEBUG(RT_ERROR, "lstDelete: input NULL\n");
		return;
	}
	
	if (pNode->previous == NULL)
	{
		pList->HEAD = pNode->next;
	}
	else
	{
		pNode->previous->next = pNode->next;
	}

	if (pNode->next == NULL)
	{
		pList->TAIL = pNode->previous;
	}
	else
	{
		pNode->next->previous = pNode->previous;
	}

	/* update node count */
	pList->count--;
}


/**@brief         find first node in list
 * @param[in]     pList:Ŀ������ 
 * @param[out]    ��
 * @return        ��
 */
NODE *lstFirst(LIST *pList)
{
	if(NULL == pList)
	{
		LTE4G_DEBUG(RT_ERROR, "lstFirst: input NULL\n");
		return NULL;
	}
	return (pList->HEAD);
}


/**@brief         insert a node in a list after a specified node
 * @param[in]     pList:Ŀ������ 
 * @param[in]     pPrev:ǰ�ý��
 * @param[in]     pNode:��������
 * @param[out]    ��
 * @return        ��
 */
void lstInsert(LIST *pList,NODE *pPrev,NODE *pNode)
{
	NODE *pNext = NULL;

	if(NULL == pList || NULL == pNode)
	{
		LTE4G_DEBUG(RT_ERROR, "lstDelete: input NULL\n");
		return;
	}

	if (pPrev == NULL)
	{				/* new node is to be first in list */
		pNext = pList->HEAD;
		pList->HEAD = pNode;
	}
	else
	{				/* make prev node point fwd to new */
		pNext = pPrev->next;
		pPrev->next = pNode;
	}

	if (pNext == NULL)
	{
		pList->TAIL = pNode;		/* new node is to be last in list */
	}
	else
	{
		pNext->previous = pNode;	/* make next node point back to new */
	}

	/* set pointers in new node, and update node count */

	pNode->next = pNext;
	pNode->previous	= pPrev;

	pList->count++;
}


/**@brief         find the next node in a list 
 * @param[in]     pNode:Ŀ����
 * @param[out]    ��
 * @return        next node
 */
NODE *lstNext(NODE *pNode)
{
	if(NULL == pNode)
	{
		LTE4G_DEBUG(RT_ERROR, "lstNext: input NULL\n");
		return NULL;
	}
	return (pNode->next);
}


/**@brief         free up a list
 * @param[in]     pList:Ŀ������
 * @param[out]    ��
 * @return        ��
 */
void lstFree(LIST *pList)
{
	NODE *p1 = NULL, *p2 = NULL;
	if(NULL == pList)
	{
		LTE4G_DEBUG(RT_ERROR, "lstFree: input NULL\n");
		return ;
	}
	
	if (pList->count > 0)
	{
		p1 = pList->HEAD;
		while (p1 != NULL)
		{
			p2 = p1->next;
			free ((char *)p1);
			p1 = p2;
		}
		pList->count = 0;
		pList->HEAD = pList->TAIL = NULL;
	}
}


/** @fn	INT32 get_dns(INT8* p_dns1, INT8* p_dns2, INT32 len)	  
 *  @brief	��ȡ��dns�ͱ���dns,Ȼ��ֱ�洢��p_dns1,p_dns2��	  
 *  @param[in]  p_dns1 �����dns�ĵ�ַ����Χ:��NULL
 *  @param[in]  p_dns2 ��ű���dns�ĵ�ַ����Χ:��NULL
 *  @param[out] p_dns1 ��dns��ַ
 *  @param[out] p_dns2 ����dns��ַ
 *  @return	  0 �ɹ�; -1 ʧ��
 */
INT32 get_dns(INT8* p_dns1, INT8* p_dns2, INT32 len)
{
	INT8 buf[128],name[50];
	INT8* dns[2];
	INT32 dns_index = 0;

	memset(buf, 0, sizeof(buf));
	memset(name, 0, sizeof(name));
	memset(dns, 0, sizeof(dns));

	if ((NULL == p_dns1) || (NULL == p_dns2))
	{
		LTE4G_DEBUG(RT_ERROR, "get_dns: param err.\n");
		return ERROR;
	}

	FILE * fp = fopen(RESOLV_FILE, "r");
	if(NULL == fp)
	{
		LTE4G_DEBUG(RT_ERROR, "can not open file /etc/resolv.conf\n");
		return ERROR;
	}

	dns[0] = p_dns1;
	dns[1] = p_dns2;

	while(fgets(buf, sizeof(buf), fp))
	{
		sscanf(buf, "%s", name);
		if(!strcmp(name, "nameserver"))
		{
			sscanf(buf, "%s%s", name, dns[dns_index++]);
		}

		if (dns_index >= 2)
		{
			break;
		}
	}

	fclose(fp);

	return OK;
}

/** @fn	INT32 get_netmask(INT8 *p_interface_name, INT8 *p_netmask, INT32 len)	  
 *  @brief	��ȡ���ʮ������ʽ���������룬�����p_netmask��	  
 *  @param[in]  p_interface_name �����豸������,����"eth0"
 *  @param[in]  p_netmask ���ڴ���������롣��Χ:��NULL
 *  @param[in]  len ���������ַ����ĳ��ȡ���Χ:p_macָ��Ŀռ�Ĵ�С
 *  @param[out] p_netmask ���ʮ���Ʊ�ʾ����������
 *  @return	  0 �ɹ�; -1 ʧ��
 */
INT32 get_netmask(INT8 *p_interface_name, INT8 *p_netmask, INT32 len)
{
	INT32 s = 0;
	struct ifreq ifr;
	struct sockaddr_in *ptr = NULL;
	struct in_addr addr_temp;

	memset(&ifr, 0, sizeof(ifr));
	memset(&addr_temp, 0, sizeof(addr_temp));

	if ((NULL == p_interface_name) || (NULL == p_netmask))
	{
		LTE4G_DEBUG(RT_ERROR, "get_netmask param error\n");
		return ERROR;
	}

	if(len < 16)
	{
		printf("The netmask need 16 byte !\n");
		return ERROR;
	}

	if((s = socket(PF_INET, SOCK_STREAM, 0)) < 0)
	{
		return ERROR;
	}

	strncpy(ifr.ifr_name, p_interface_name, MIN(strlen(p_interface_name), sizeof(ifr.ifr_name) - 1));

	if(ioctl(s, SIOCGIFNETMASK, &ifr) < 0)
	{
		LTE4G_DEBUG(RT_ERROR, "get_netmask ioctl error and errno=%d\n", errno);
		close(s);
		return ERROR;
	}

	ptr = (struct sockaddr_in *)&ifr.ifr_ifru.ifru_netmask;
	addr_temp = ptr->sin_addr;
	snprintf(p_netmask, len, "%s", inet_ntoa(addr_temp/*ptr->sin_addr*/));
	close(s);

	return OK;
}

/** @fn	INT32 get_gateway(INT8 *p_interface_name, INT8 *p_gateway, INT32 len)	  
 *  @brief	ͨ�������豸����ȡ���ʮ���Ʊ�ʾ�����أ����ش���p_gateway��	  
 *  @param[in]  p_interface_name �����豸��,����"eth0"
 *  @param[in]  p_gateway ������صĵ�ַ����Χ:��NULL
 *  @param[in]  len �����ַ������ȡ���Χ:ָ��Ŀռ�Ĵ�С
 *  @param[out] p_gateway ���ء����ʮ���Ʊ�ʾ������
 *  @return	  0 �ɹ�; -1 ʧ��
 */
INT32 get_gateway(INT8 *p_interface_name, INT8 *p_gateway, INT32 len)
{
	INT8 devname[64];
	ULONG d = 0;
	ULONG g = 0;
	ULONG m = 0;
	INT32 r = 0;
	INT32 flgs = 0;
	INT32 ref = 0;
	INT32 use = 0;
	INT32 metric = 0;
	INT32 mtu = 0;
	INT32 win = 0;
	INT32 ir = 0;
	struct in_addr mask,dst,gw;
	INT32 ret = -1;
	FILE *fp = NULL;

	if ((NULL == p_interface_name) || (NULL == p_gateway) || (len < 16))
	{
		return ERROR;
	}

	memset(devname, 0, sizeof(devname));
	memset(&mask, 0, sizeof(mask));
	memset(&dst, 0, sizeof(dst));
	memset(&gw, 0, sizeof(gw));

	fp = fopen(ROUTE_FILE, "r");
	if(NULL == fp)
	{
		LTE4G_DEBUG(RT_ERROR, "open file failed %d\n", errno);
		return ERROR;
	}

	if (fscanf(fp, "%*[^\n]\n") < 0)
	{ /* Skip the first line. */
		fclose(fp);
		return ERROR;        /* Empty or missing line, or read error. */
	}

	memset(&mask, 0, sizeof(struct in_addr));
	memset(&dst, 0, sizeof(struct in_addr));
	memset(&gw, 0, sizeof(struct in_addr));

	while (1)
	{
		r = fscanf(fp, "%63s%lx%lx%X%d%d%d%lx%d%d%d\n",
				devname, &d, &g, &flgs, &ref, &use, &metric, &m, &mtu, &win, &ir);
		if (r != 11)
		{
			LTE4G_DEBUG(KEY_WARN, "get_gateway fscanf error and r=%d,errno\n", r, errno);
			break;
		}

		if (!(flgs & RTF_UP))
		{ /* Skip interfaces that are down. */
			continue;
		}

		if (strcmp(devname, p_interface_name) != 0)
		{
			continue;
		}

		mask.s_addr = m;
		dst.s_addr  = d;
		gw.s_addr   = g;

		if(flgs & RTF_GATEWAY)
		{
			if ( d == 0 && m == 0 && g != 0 )
			{
				snprintf(p_gateway, len, "%s", inet_ntoa(gw));
				ret = 0;
				break;
			}

		}
	}

	fclose(fp);

	return ret;
}


  
/**@brief         ��ȡIP��ַ
 * @param[in]     interface_name: ������
 * @param[in]     len: IP����
 * @param[out]    ip: IP��ַ
 * @return        OK:0,ERROR:-1
 */
int get_ipaddr(INT8 *p_interface_name, INT8 *p_ip, INT32 len)
{
	int sock_fd = -1;
	struct in_addr addr_temp;
	struct ifconf ifconf;
	struct ifreq *ifr = NULL;
	unsigned char buf[512];
	int i = 0;
	
	bzero(buf, sizeof(buf));
	bzero(&addr_temp, sizeof(addr_temp));
	bzero(&ifconf, sizeof(ifconf));

	if ((NULL == p_interface_name) || (NULL == p_ip) || len < 16)
	{
		LTE4G_DEBUG(RT_ERROR, "get_ipaddr param err .\n");
		return ERROR;
	}

	if((sock_fd = socket(PF_INET, SOCK_STREAM, 0)) < 0)
	{
		LTE4G_DEBUG(RT_ERROR, "socket failed !errno = %d\n", errno);
		return ERROR;
	}

	ifconf.ifc_len = 512;
	ifconf.ifc_buf = (char*)buf;

	/*
	 * Get all interfaces list
	 */
	if(ioctl(sock_fd, SIOCGIFCONF, &ifconf) < 0)
	{
		LTE4G_DEBUG(RT_ERROR, "SIOCGIFCONF socket failed !errno = %d\n", errno);
		close(sock_fd);
		return ERROR;
	}

	close(sock_fd);

	ifr = (struct ifreq*)buf;
	for(i = (ifconf.ifc_len/sizeof(struct ifreq)); i > 0; i--)
	{
		if(AF_INET == ifr->ifr_flags 
			&& 0 == memcmp(ifr->ifr_name, p_interface_name, strlen(p_interface_name)))
		{
			LTE4G_DEBUG(DEBUG_ALL_DAV, "Interface_name:[%s], IP_addr:[%s]\n", 
				ifr->ifr_name, inet_ntoa(((struct sockaddr_in*)&(ifr->ifr_addr))->sin_addr));
			break;
		}
		ifr++;
	}

	if(0 == i)
		return ERROR;
	
	addr_temp = ((struct sockaddr_in*)&(ifr->ifr_addr))->sin_addr;
	
	(void)inet_ntop(AF_INET, &addr_temp, p_ip, len);
	
	return OK;
}  

#if 0
/**@brief get current dialProcessStat 
 * @param[In]   NONE 
 * @return	DIAL_DEFAULT_STAT -  DIAL_CUTOFF_POWER
 */
UINT32 mobile_get_dial_stat(void)
{
	return shareMemParam->realMobileStat.dialProcessStat;
}
#endif

/**@brief ��⵱ǰ4G�����Ƿ�����
 * @param[In]	��
 * @return	TRUE: ����
 			FALSE: ������
 */
BOOL is_mobile_online(void)
{
	char ipAddr[20];

	memset(ipAddr, 0, sizeof(ipAddr));
	//ֻ�е�ǰ������4G���Ų�ȥ�жϵ�ǰ4G�����Ƿ���ã�����ֱ�ӷ���FALSE
	if(TRUE ==pDevDialParam->byEnableMobile)
	{
		if(get_ipaddr(PPP_INTERFACE, ipAddr, 20) != OK)
		{
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
	else
	{
		return FALSE;
	}
}


/**@brief         ���ô��ڲ�����
 * @param[in]     fd: ���ڵ��ļ�������
 * @param[in]     speed: ������
 * @param[out]    none
 * @return        OK:0,ERROR:-1
 */
int SetSerialBaud(int fd,int speed)
{
	struct termios opt;
	
	tcgetattr(fd,&opt);
	cfsetispeed(&opt,speed);
	cfsetospeed(&opt,speed);
	return tcsetattr(fd,TCSANOW,&opt);
}


/**@brief         ���ô���ģʽ
 * @param[in]     fd: ���ڵ��ļ������� 
 * @param[out]    none
 * @return        OK:0,ERROR:-1
 */
int SetSerialRawMode(int fd)
{
	struct termios opt;
	
	tcgetattr(fd,&opt);
	opt.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG); 		/* input */
	opt.c_iflag &= ~(IXON|IXOFF|ICRNL|INLCR|IGNCR);	/* ���� CR(0D) ӳ��� NR(0A) */
	opt.c_oflag &= ~OPOST;							/* output */
	return tcsetattr(fd,TCSANOW,&opt);
}

/**@brief         ����tick��
 * @param[in]     ��
 * @param[out]    ��
 * @return        tick��
 */
unsigned long tickGet(void)
{
	struct timeval now;
	
	gettimeofday(&now, NULL);
	long a = now.tv_sec*1000+ now.tv_usec/1000;	
	return a/V2PT_TICK;
}


/**@brief         ð����������б�
 * @param[in]     ��
 * @param[out]    ��
 * @return        ��
 */
void smsBubbleSort(int listNums)
{
	int i = 0, j = 0;
	SMS_STATUS tmpSms;
	
	for (i = 0; i < listNums; i++)
	{
		//earliest = &(sms_status[0].recvTime);
		j = listNums - i -1;
		while (j)
		{
			//Ϊ���������뾯�棬��recvTimeǿ��ת����char *
			if (strcmp((char *)(sms_status[j].recvTime), (char *)(sms_status[j - 1].recvTime)) < 0)
			{
				memcpy(&tmpSms, &sms_status[j - 1], sizeof(SMS_STATUS));
				memcpy(&sms_status[j - 1], &sms_status[j], sizeof(SMS_STATUS));
				memcpy(&sms_status[j], &tmpSms, sizeof(SMS_STATUS));
			}
			j--;
		}
	}
	return;
}


/**@brief         when the initATChannel task was cancel by pthread_cancel, release this task resouce
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
void at_cleanup(void *arg)
{
	/* �����߳��˳�ʱ�ѱ�lock����unlock��ֹ���� */
	pthread_mutex_unlock(&atFdSem);
	pthread_mutex_unlock(&rilSem);
	releaseATResponse();
	releaseATChannel();
	return;
}

/**@brief         Query whether current chip module containing 4G function
 * @param[in]     none
 * @param[out]    none
 * @return        TRUE/FALSE
 */
BOOL is_4G_chip_module(void)
{
	if(M_U8300 == shareMemParam->iModel
		|| M_LM91XX== shareMemParam->iModel
		|| M_HUAWEI_4G== shareMemParam->iModel)
		return TRUE;
	else
		return FALSE;
}


/**@brief         update 4G info regularly
 * @param[in]     ��ǰ���к�
 * @param[out]    none
 * @return        none
 */
void update_mobile_info_regularly(int ATComTurn)
{
	int retVal = -1;
	char response[128];
	static int iNotRegTime = 0;		/* time for not register the networks */
	static int iStartNotRegTime = 0;	/* start time for not register the networks */						
	static int iSearchTimes = 0;		/* search networks times */
	time_t curTime; 
	static int queryTimes = 0;
	PHONE_FUNCTION phone_function = CFUN_ONLINE_MODE;
 
	memset(response, 0, sizeof(response));

	curTime = time(NULL);

	LTE4G_DEBUG(DEBUG_INFO, "ATComTurn = %d\n",ATComTurn);

	//get infomation of Rssi, (signal)
	(void)mobile_AT_get_signal(NULL, NULL);
	// get sms register stauts
	//(void)query_network_sysinfo(NULL);
	
	switch(ATComTurn)
	{
		case 1:	// get information of wireless networks
			FindSysInfo();
			break;
		case 2:	// reregister the  wireless network 	
			mobile_reregister_network(); 
			break;
		case 3:	// get information of networks registion 
			if ((MODE_WCDMA == mobile_mode) || (MODE_TDSCDMA == mobile_mode) 
				|| (MODE_TDLTE == mobile_mode) || (MODE_FDDLTE == mobile_mode))
			{
				if (is_4G_chip_module())
				{
					(void)mobile_AT_get_4G_status(NULL, NULL);		/* query 4G register information  */
				}

				(void)mobile_AT_get_3G_status(NULL, NULL);	/* query 3G register information  */
				(void)mobile_AT_get_2G_status(NULL, NULL);	/* query 2G register information  */
				
				if (mobile_reg2gInfo != CREG_STAT_REGISTED_LOCALNET 
					&& mobile_reg2gInfo != CREG_STAT_REGISTED_ROAMNET
					&& mobile_reg3gInfo != CREG_STAT_REGISTED_LOCALNET 
					&& mobile_reg3gInfo != CREG_STAT_REGISTED_ROAMNET
					&& mobile_reg4gInfo != CREG_STAT_REGISTED_LOCALNET 
					&& mobile_reg4gInfo != CREG_STAT_REGISTED_ROAMNET
					&& mobile_signal >= 10)
				{
					if (iStartNotRegTime == 0)
					{
						iStartNotRegTime = curTime;
					}
					iNotRegTime = abs(curTime - iStartNotRegTime);
					/* under the condition of good signal strength, 
					it still can't register the networks for 10 min, reset it */

					/* can't register for 2 min, search the networks */
					if (iNotRegTime >= 120) 
					{  
						if (iSearchTimes++ >= 5)
						{
							LTE4G_DEBUG(RT_ERROR, "iSearchTimes > 5\n");
							dial_error_occur(EXIT_DIAL_ABNORMAL);
						}
						//<TODO: ��������ܻ�����AT��������������
						//(void)query_list_current_all_network_operators(NULL);
						iNotRegTime = 0;
						iStartNotRegTime = 0;
					}
				}
				else
				{
					iNotRegTime = 0;
					iStartNotRegTime = 0;								
					iSearchTimes = 0;
				}
			}
			break;
		case 4:	// reserved
			
			break;
		case 5:	// get systerm mode config infomation in every 1 min
			retVal = mobile_AT_get_search_network_mode(NULL, response);
			if (retVal == OK)
			{ 
				mobile_sysCfg = getSyscfg(response);
			}
			break;
		case 6:	// reserved
			break;
		case 7:	// reserved
			break;
		case 8:	// reserved
			break;
		case 9:	// get operator's infomation
			if ((MODE_WCDMA == mobile_mode) || (MODE_TDSCDMA == mobile_mode)
				|| (MODE_TDLTE == mobile_mode) || (MODE_FDDLTE == mobile_mode))
			{
				retVal = mobile_AT_list_operator_by_numeric(NULL, NULL);	//set mobile_operator's infomation in numeric format.
				retVal = mobile_AT_list_sim_operator(NULL, NULL);			// get current network mobile_operator's infomation
			}
			break;
		case 10:
			retVal = mobile_AT_get_phone_function(NULL, NULL);
			if (shareMemParam->realMobileStat.operMode != CFUN_ONLINE_MODE)
			{
				/* arbitrarily turn the mode to ONLINE_MODE */
				retVal = mobile_AT_set_phone_function(&phone_function, NULL);
			}
			break;
		default:
			break;
	}

	return;
}


/**@brief         �жϵ�ǰ�����Ƿ���Ҫ�����л�
 * @param[in]     ��ǰ���к�
 * @param[out]    none
 * @return        none
 */
void check_is_need_switch_network(void)
{
	SEARCH_NETWORK_MODE search_mode = SEARCH_AUTO_MODE;
	
	// Telecom 
	if(mobile_mode != MODE_EVDO 
		&& mobile_mode != MODE_CDMA1X)
	{
		//���µ�ǰ������3G��4G�ķ���״̬
		mobile_AT_get_3G_status(NULL, NULL);
		if(is_4G_chip_module())
		{
			mobile_AT_get_4G_status(NULL, NULL);
		}
	}

	LTE4G_DEBUG(DEBUG_INFO, "check_is_need_switch_network: swtichMethold = %d\n",pDevDialParam->bySwitchMethold);
	switch(pDevDialParam->bySwitchMethold)
	{
		case SWITCH_AUTO:		//�Զ��л�ģʽ,������ֵ�ǰ����3G��4Gͬʱ���ڣ�������4G		
		{
			// check whether current mode to automatic mode
			if(mobile_sysCfg != SYSCFG_MODE_AUTO)
			{
				if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
				{	
					/*��ͨ��3Gģʽ�л����Զ�ģʽ֮�������ǰ��4G�źţ�4Gʶ���ٶ��ر�����������Ҫ����࣬
					 *�����л����Զ�ʱ�Ƚ�������Ϊǿ��4G��Ȼ��������Ϊ�Զ�ģʽ*/
					 search_mode = SEARCH_LTE_ONLY;
					(void)mobile_AT_set_search_network_mode(&search_mode, NULL);
					sleep(3);
					search_mode = SEARCH_AUTO_UNICOM;
					(void)mobile_AT_set_search_network_mode(&search_mode, NULL);
				}
				else
				{
					search_mode = SEARCH_AUTO_MODE;
					(void)mobile_AT_set_search_network_mode(&search_mode, NULL);
				}
				mobile_sysCfg = SYSCFG_MODE_AUTO;
				
				// when switching the current search network mode requires a few seconds of sleep.
				sleep(2);
			}
			
			if((mobile_mode != MODE_TDLTE)
				&& (mobile_mode != MODE_FDDLTE))
			{
				if((CREG_STAT_REGISTED_LOCALNET == mobile_reg4gInfo
				||  CREG_STAT_REGISTED_ROAMNET == mobile_reg4gInfo)
				&& (shareMemParam->iModel != M_HUAWEI_4G ))
				{
					//when swtiching Telecom 3G to 4G need dialing parameters need to be replaced.
					if(OPERATOR_CHINA_TELECOM == pDevDialParam->mobile_operator)
					{
						set_ppp_param(MODE_FDDLTE);
					}

					// UniCom should reconfig the APN parameter
					if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
					{
						//update current network service type
						(void)mobile_AT_get_network_service_type(NULL, NULL);
						//(void)set_context_num_cid_undefined(NULL);
						(void)mobile_AT_set_APN(NULL, NULL);
						(void)set_ppp_param(MODE_FDDLTE);
					}
					if(TRUE == is_mobile_online())
					{
						LTE4G_DEBUG(DEBUG_INFO, "check_is_need_switch_network AUTO: disconnect 3G, switch to 4G\n");
						LTE4G_DEBUG(DEBUG_INFO, "realMobileStat.mode = %d\n",mobile_mode);
						modem_finiPPP();
					}
				}
			}
#if 0			//��Ϊģ����ʱ���Զ��л��������������˵ģ����Լ������л�
			//��Ϊģ��4Gע��״̬��ѯat+sysinfoex���at+cereg��׼������Ŀǰ�޷���֤ģ����Զ��л�
			if(shareMemParam->iModel == M_HUAWEI_4G)
			{
				if(modemMode == MODE_TDLTE
					|| modemMode == MODE_FDDLTE)
				{
					// UniCom should reconfig the APN parameter
					if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
					{
						//update current network service type
						(void)mobile_AT_get_network_service_type(NULL, NULL);
						(void)mobile_AT_clear_APN(NULL, NULL);
						(void)mobile_AT_set_APN(NULL, NULL);
						(void)set_ppp_param(MODE_FDDLTE);
					}
					if(TRUE == is_mobile_online())
					{
						LTE4G_DEBUG(DEBUG_INFO, "check_is_need_switch_network AUTO: disconnect 3G, switch to 4G\n");
						LTE4G_DEBUG(DEBUG_INFO, "realMobileStat.mode = %d\n",realMobileStat.mode);
						modem_finiPPP();
					}
				}
			}
#endif
			break;
		}
		case SWITCH_MANUAL_4G:
		{
			if(mobile_sysCfg != SYSCFG_MODE_TDLTE
				&& mobile_sysCfg != SYSCFG_MODE_FDDLTE)
			{
				search_mode = SEARCH_LTE_ONLY;
				mobile_AT_set_search_network_mode(&search_mode, NULL);
				if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator)
				{
					mobile_sysCfg = SYSCFG_MODE_TDLTE;
				}
				else
				{
					mobile_sysCfg = SYSCFG_MODE_FDDLTE;
				}

				// when switching the current search network mode requires a few seconds of sleep.
				sleep(2);
			}
			
			if((mobile_mode != MODE_TDLTE) 
				&& (mobile_mode != MODE_FDDLTE))
			{
				//when swtiching Telecom 3G to 4G need dialing parameters need to be replaced.
				if(OPERATOR_CHINA_TELECOM == pDevDialParam->mobile_operator)
				{
					(void)set_ppp_param(MODE_FDDLTE);
				}
				// UniCom should reconfig the APN parameter
				if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
				{
					//update current network service type
					(void)mobile_AT_get_network_service_type(NULL, NULL);
					//(void)set_context_num_cid_undefined(NULL);
					(void)mobile_AT_set_APN(NULL, NULL);
					(void)set_ppp_param(MODE_FDDLTE);
				}
				
				if(TRUE == is_mobile_online())
				{
					LTE4G_DEBUG(DEBUG_INFO, "check_is_need_switch_network: disconnect 3G, switch to 4G\n");
					LTE4G_DEBUG(DEBUG_INFO, "realMobileStat.mode = %d\n",mobile_mode);
					modem_finiPPP();
				}
			}
			break;
		}
		case SWITCH_MANUAL_3G:
		{
			if(mobile_sysCfg != SYSCFG_MODE_TDSCDMA
				&& mobile_sysCfg != SYSCFG_MODE_WCDMA
				&& mobile_sysCfg != SYSCFG_MODE_EVDO)
			{
				LTE4G_DEBUG(DEBUG_INFO, "mobile_operator : %d\n", pDevDialParam->mobile_operator);
				if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator)
				{
					search_mode = SEARCH_TDCMDA_ONLY;
					mobile_AT_set_search_network_mode(&search_mode, NULL);
					mobile_sysCfg = SYSCFG_MODE_TDSCDMA;
				}
				else if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
				{
					search_mode = SEARCH_UMTS_ONLY;
					mobile_AT_set_search_network_mode(&search_mode, NULL);
					mobile_sysCfg = SYSCFG_MODE_WCDMA;
				}
				else
				{
					search_mode = SEARCH_EVDO_ONLY;
					mobile_AT_set_search_network_mode(&search_mode, NULL);
					mobile_sysCfg = SYSCFG_MODE_EVDO;
				}

				// when switching the current search network mode requires a few seconds of sleep.
				sleep(2);
			}			

			if((mobile_mode != MODE_TDSCDMA) 
				&&  (mobile_mode != MODE_WCDMA)
				&&  (mobile_mode != MODE_EVDO))
			{
				//when swtiching Telecom 3G to 4G need dialing parameters need to be replaced.
				if(OPERATOR_CHINA_TELECOM == pDevDialParam->mobile_operator)
				{
					set_ppp_param(MODE_EVDO);
				}

				// UniCom should reconfig the APN parameter
				if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
				{
					//update current network service type
					(void)mobile_AT_get_network_service_type(NULL, NULL);
					//(void)set_context_num_cid_undefined(NULL);
					(void)mobile_AT_set_APN(NULL, NULL);
					set_ppp_param(MODE_WCDMA);
				}
				
				if(TRUE == is_mobile_online())
				{
					LTE4G_DEBUG(DEBUG_INFO, "check_is_need_switch_network: disconnect 4G, switch to3G\n");
					LTE4G_DEBUG(DEBUG_INFO, "realMobileStat.mode = %d\n",mobile_mode);
					modem_finiPPP();
				}
			}
			break;
		}
		default:		//2G��ʱ������,���ֶ���2G�����ϵ�����
			LTE4G_DEBUG(RT_ERROR, "check_is_need_switch_network: erro bySwitchMethold %d\n",pDevDialParam->bySwitchMethold);
			break;
	}

	return;
}

/**@brief         ������ǰsim����Ӫ��
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
void query_current_sim_operator(void)
{
	char response[128];
	AUTO_APN_STATUS auto_apn;
	UINT8 mobile_operator = 0;
	SEARCH_NETWORK_MODE search_mode = SEARCH_AUTO_MODE;
	
	memset(response, 0, sizeof(response));
	if(OK == mobile_AT_list_sim_operator(NULL, response))
	{
		LTE4G_DEBUG(RT_ERROR, "Device cimi : %s\n", response);

		//refer from android:apns-conf.xml
		if(strstr(response, "46000") 	
		|| strstr(response, "46002")	
		|| strstr(response, "46004") 	//�й��ƶ�������
		|| strstr(response, "46007")	
		|| strstr(response, "46020")
		|| strstr(response, "46027"))
		{
			mobile_operator = OPERATOR_CHINA_MOBILE;
		}
		else if(strstr(response, "46001") //China Unicom 3G,3gnet,3gwap
			|| strstr(response, "46006") //��ͨ������
			|| strstr(response, "46009")) 
		{
			mobile_operator = OPERATOR_CHINA_UNICOM;
		}
		else if(strstr(response, "46011")
			|| strstr(response, "46003")
			|| strstr(response, "46005")
			|| strstr(response, "2040"))
		{
			mobile_operator = OPERATOR_CHINA_TELECOM;
		}
		else
		{	
			/* Operator can be recognized in China by three cases before,
			   but sometimes fail to get Operator overseas, so when cannot be recognized
			   default UNICOM*/
			if(LANGUAGE_CHN_SIMPL != shareMemParam->language){
				mobile_operator = OPERATOR_CHINA_UNICOM;
			}
			LTE4G_DEBUG(RT_ERROR, "ERROR mobile_operator : %s\n", response);
		}

		LTE4G_DEBUG(DEBUG_INFO, "NOW mobile_operator : %d\n", mobile_operator);
	}
	else
	{
		LTE4G_DEBUG(RT_ERROR, "query_current_sim_operator ERROR\n");
	}

	//ʶ�𵽵�ǰ��Ӫ�̺��������APN�����ⲿ�ֵ�����Ҫʹ��APN��������ʶ��
	(void)mobile_AT_set_pre_APN(NULL, NULL);

	if(M_U8300 == shareMemParam->iModel)
	{
		auto_apn = AUTO_APN_OPEN;
		(void)mobile_AT_set_auto_APN(&auto_apn, NULL);
	}

	//�����ֵ�ǰ����Ӫ�̺��ϴβ�һ��������в��Ų�����գ�������һ�εĲ����Ա��β������Ӱ��
	if(mobile_operator != pDevDialParam->mobile_operator)
	{
		pDevDialParam->mobile_operator = mobile_operator;
		memset(pDevDialParam->dialParam.szDialNum, 0, NAME_LEN);
		memset(pDevDialParam->dialParam.szUsername, 0, NAME_LEN);
		memset(pDevDialParam->dialParam.szPassword, 0, NAME_LEN);
		memset(pDevDialParam->dialParam.netAPN, 0, NAME_LEN);
		memset(pDevDialParam->dialParam.dataAPN, 0, NAME_LEN);
	}

	switch(pDevDialParam->bySwitchMethold)
	{
		case SWITCH_AUTO:
			if(OPERATOR_CHINA_UNICOM == mobile_operator)
			{
				search_mode = SEARCH_AUTO_UNICOM;
				mobile_AT_set_search_network_mode(&search_mode, NULL);
			}
			else
			{
				search_mode = SEARCH_AUTO_MODE;
				mobile_AT_set_search_network_mode(&search_mode, NULL);
			}
			break;
		case SWITCH_MANUAL_4G:
			search_mode = SEARCH_LTE_ONLY;
			mobile_AT_set_search_network_mode(&search_mode, NULL);
			break;
		case SWITCH_MANUAL_3G:
			if(OPERATOR_CHINA_UNICOM == mobile_operator)
			{
				search_mode = SEARCH_UMTS_ONLY;
				mobile_AT_set_search_network_mode(&search_mode, NULL);
			}
			else if(OPERATOR_CHINA_MOBILE== mobile_operator)
			{
				search_mode = SEARCH_TDCMDA_ONLY;
				mobile_AT_set_search_network_mode(&search_mode, NULL);
			}
			else
			{
				search_mode = SEARCH_EVDO_ONLY;
				mobile_AT_set_search_network_mode(&search_mode, NULL);
			}
			break;
		default :
			LTE4G_DEBUG(DEBUG_INFO, "ERROR bySwitchMethold = %d\n", pDevDialParam->bySwitchMethold);
			break;
	}

	//������������ģʽ����Ҫsleep�¡�
	sleep(3);
	
	mobile_AT_set_APN(NULL, NULL);
	
	return;
}


/**@brief        ��⵱ǰ���Ͷ����Ƿ���Ҫ�з�
 * @param[in]    msg	��������
 * @param[out]   
 * @return       FALSE 	����Ҫ	> 0 ��ǰ�зֵ�λ��
 */
int check_sms_need_fragment(char *msg)
{
	if(NULL == msg)
	{
		LTE4G_DEBUG(RT_ERROR, "check_sms_length: input msg NULL\n");
		return FALSE;
	}

	int i = 0;
	int chn_num = 0;
	int eng_num = 0;

	for(i = 0; i < strlen(msg); i++)
	{
		if(msg[i] > 0xA0)	//���ֱ���2���ֽڱ����2���ֽ�
		{
			chn_num ++;
		}
		else				//�Ǻ���һ���ֽڱ����2���ֽ�
		{
			eng_num++;
		}

		if((chn_num + 2*eng_num) >= 139 && (0 == chn_num % 2))
		{
			return (chn_num+ eng_num);
		}
	}

	return FALSE;
}

/**@brief        ���Ͷ����߳�
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
static void at_send_sms(void)
{
	SEND_SMS send_sms[2];
	int i = 0;
	int len = 0;
	
	memset(&send_sms[0], 0, sizeof(SEND_SMS));
	memset(&send_sms[1], 0, sizeof(SEND_SMS));

	//�����߳�����
	prctl(15, (unsigned long)"4G_ATSendSms");
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);		//�߳̿��Ա�ȡ����
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS,NULL);	//��������Դ��Ҫ�ͷţ������˳�
	LTE4G_DEBUG(DEBUG_INFO, "<at_send_sms>: enter\n");

	FOREVER
	{
		pthread_testcancel();
		//���PDUģʽ����Ҫ�������ĺ��롣
		if( SMS_PDU_MODE == smsFormat)
		{
			if(0 == strlen(SMSCenter))
			{
				sleep(1);
				continue;
			}
		}
		if(ERROR == atFd)
		{
			atPrintf("at_send_sms: exit");
			break;
		}
		while(FD_USB_DOWN ==  atFd)
		{
			pthread_testcancel();
			sleep(1);
			//continue;
		}		

		if(mobile_srvDomain >= SRV_STATUS_CS_PS
			|| SRV_STATUS_CS == mobile_srvDomain)
		{
			// �����Ҫ���Ż�ִ�����ȷ��Ͷ��Ż�ִ
			if(check_is_need_receipt(&send_sms[0]))
			{
				if(ATSendSMS((char*)send_sms[0].phoneNum, (char*)send_sms[0].msg) != OK)
				{
					LTE4G_DEBUG(RT_ERROR, "send alarm sms failed\n");
				}
				sleep(1);
			}
			
			// when mobile network is registered CS service, than we can send sms.
			if (strlen((char *)(shareMemParam->sendSmsParam.msg)) != 0)
			{
				memset(&send_sms[0], 0, sizeof(SEND_SMS));
				memset(&send_sms[1], 0, sizeof(SEND_SMS));

				if((len = check_sms_need_fragment((char *)shareMemParam->sendSmsParam.msg)) != FALSE)
				{
					memcpy(send_sms[0].msg, shareMemParam->sendSmsParam.msg, len);
					memcpy(send_sms[0].phoneNum,shareMemParam->sendSmsParam.phoneNum, sizeof(send_sms[0].phoneNum));
					memcpy(send_sms[1].msg, (shareMemParam->sendSmsParam.msg + len), strlen((char*)shareMemParam->sendSmsParam.msg) - len);
					memcpy(send_sms[1].phoneNum,shareMemParam->sendSmsParam.phoneNum, sizeof(send_sms[0].phoneNum));
				}
				else
				{
					memcpy(&send_sms[0], &shareMemParam->sendSmsParam, sizeof(SEND_SMS));
				}
				
				i = 0;
				while(i < 2 && strlen((char*)send_sms[i].msg) != 0)
				{
					pthread_testcancel();
					if(ATSendSMS((char*)send_sms[i].phoneNum, (char*)send_sms[i].msg) != OK)
					{
						LTE4G_DEBUG(RT_ERROR, "send alarm sms failed\n");
						//���Ͷ���ʧ�ܣ�sleep1��֮��������͡�
						sleep(1);
						continue;
					}
					i++;
					sleep(2);
				}
				memset(&(shareMemParam->sendSmsParam), 0 ,sizeof(SEND_SMS));
				
			}

			 if(strlen((char *)(shareMemParam->sendSmsParam.msg)) != 0
				&& (SRV_STATUS_PS == mobile_srvDomain
				|| SRV_STATUS_NONE == mobile_srvDomain))
			{
				LTE4G_DEBUG(DEBUG_INFO, "network is not registered PS service, status = %d \n",mobile_srvDomain);
			}
		}

		sleep(1);
	}

	return;
}

/**@brief        ��ʼ��3G/4Gģ�飬����:1. get Modem name; 
 *                                  2. pin code;
 *                                  3. modem function; 
 *                                  4. get sys_info;
 *                                  5. get sms center number;
 *                                  6. config the modem parameters;
 *               ��ʼ����ɺ�ͨ��ATָ�������Եļ��ģ��״̬�� 
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
void initATChannel(void)
{
	int retVal = ERROR;
	char response[128];
	char modName[32];
	char printfBuf[256];
	int ret = 0;
	int i = 0;
	static time_t lastCheckTime = 0;
	time_t curT = 0;
	time_t intervalTime = 2;
	int ATComTurn = 1;
	char phoneNum[32];
	char msg[144];
	static int count = 0;
	static int sms_count = 0;
	RENEW_PINCODE renew_pincode;
	SEARCH_NETWORK_MODE search_mode = SEARCH_AUTO_MODE;

	/*�����߳̽ӿ��������߳�����
	  *setPthreadName("ipc_supplicant");*/
	prctl(15, (unsigned long)"4G_ATChannel");
	
	pthread_cleanup_push(at_cleanup, (void *)NULL);

	memset(response, 0, sizeof(response));
	memset(modName, 0, sizeof(modName));
	memset(printfBuf, 0, sizeof(printfBuf));
	memset(phoneNum, 0, sizeof(phoneNum));
	memset(msg, 0, sizeof(msg));
	memset(&renew_pincode, 0, sizeof(renew_pincode));
	
	/* Dial-Status: 0-DEFAULT_STAT */ 
	mobile_set_modem_stat(DIAL_DEFAULT_STAT);
	
	//����ƥ��Ĵ����豸
	while(findATChannel() != OK)
	{
		pthread_testcancel();
		sleep(1);
	}
	
	LTE4G_DEBUG(DEBUG_INFO, "init AT device end\n");

	/* Dial-Status: 1-FIND_DEVICE */ 
	mobile_set_modem_stat(DIAL_FIND_DEVICE);

	pthread_mutex_lock(&rilSem);
	/* ��ʼ��AT ��Ӧ���� */
	atResponse.used = FALSE;
	lstInit(&atResponse.atList);
	pthread_mutex_unlock(&rilSem);
	
	smsNum = 0;

	LTE4G_DEBUG(DEBUG_INFO, "ATReaderLoop begin...\n");
	if ((ret = pthread_create(&tids[RECV_AT_THREAD], NULL, (void *)&ATReaderLoop, NULL)) != OK)		// ATָ������߳�
	{
		LTE4G_DEBUG(RT_ERROR, "pthread_create ATReaderLoop err, ret = %d\n", ret);
	}

	usleep(100*1000);
	getModemName(modName);
	LTE4G_DEBUG(DEBUG_INFO, "<initATChannel>: getModemName end\n");
	
	//��ȡ��ǰsim������Ӫ��
	query_current_sim_operator();
	LTE4G_DEBUG(DEBUG_INFO, "<initATChannel>: mobile_operator = %d\n", pDevDialParam->mobile_operator);

	/* ��ѯ�Ƿ���ҪPIN ���� */
	usleep(600*1000);
	pinInit();
	LTE4G_DEBUG(DEBUG_INFO, "pinInit end\n");

	/* Dial-Status: 2-UNLOCK_PIN */ 
	mobile_set_modem_stat(DIAL_READY_PIN);
	LTE4G_DEBUG(DEBUG_INFO, "Dial-Status: 2-UNLOCK_PIN\n");

	// ���õ�ǰSIM��ģʽ������Ϊȫ��ģʽ��Ҳ��������CFUN=1
	funInit();
	
	// Dial-Status: 3-FULL_FUNC  
	mobile_set_modem_stat(DIAL_FULL_FUNC);
	LTE4G_DEBUG(DEBUG_INFO, "Dial-Status: 3-FULL_FUNC\n");

	//��ѯϵͳ��Ϣ  
	sysinfoInit();

	/* Dial-Status: 4-SYS_INFO */ 
	mobile_set_modem_stat(DIAL_SYS_INFO);
	LTE4G_DEBUG(DEBUG_INFO, "Dial-Status: 4-SYS_INFO\n");
	
	// �ж�����ģ����ʽ(������ʽ) 
	if((mobile_mode != MODE_EVDO) && (mobile_mode != MODE_CDMA1X)
		&& (mobile_mode != MODE_WCDMA) && (mobile_mode != MODE_TDSCDMA)
		&& (mobile_mode != MODE_TDLTE) && (mobile_mode != MODE_FDDLTE)
		&& (mobile_mode != MODE_GPRS))
	{
		LTE4G_DEBUG(RT_ERROR, "unknown modem mode:%d\n", mobile_mode);
	}

	while(MODE_NONE == mobile_mode)
	{
		pthread_testcancel();
		// Every 2 minutes set current mode automatically,in order to recognize current mode.
		if(0 == (count++ % 12))
		{
			search_mode = SEARCH_AUTO_MODE;
			mobile_AT_set_search_network_mode(&search_mode, NULL);
			sleep(3);
		}
		FindSysInfo();
		LTE4G_DEBUG(DEBUG_INFO, "Current modem mode:%d\n", mobile_mode);
		sleep(10);
	}
	
	shareMemParam->modemMode = mobile_mode;

	/* ��ѯ�������ĺ��룬������ʱ�ã�����EVDOû�ж�������*/
	if ((MODE_WCDMA == mobile_mode) 
		|| (MODE_TDSCDMA == mobile_mode)
		|| (MODE_TDLTE == mobile_mode)
		|| (MODE_FDDLTE == mobile_mode))	
	{
		memset(response, 0, sizeof(response));
		for (i = 0; i < 10; i++)
		{
			atcmd_snd_other();
			if ((retVal = mobile_AT_get_SMS_center_num(NULL, response)) != OK)
			{
				usleep(100 * 1000);
			}
			else
			{
				break;
			}
		}
		if(OK == retVal)
		{
			getSCA(response);
			sprintf(printfBuf, "SMS center: %s", SMSCenter);
			atPrintf(printfBuf);
			LTE4G_DEBUG(DEBUG_INFO, "SMS center: %s\n",SMSCenter );
		}
		else
		{
			memset(SMSCenter, '0', 15);
			SMSCenter[15] = 0;
		}
	}
	/* Dial-Status: 5-SMS_CENTER */
	mobile_set_modem_stat(DIAL_SMS_CENTER);
	LTE4G_DEBUG(DEBUG_INFO, "Dial-Status: 5-SMS_CENTER\n");

	/* ��ʼ��Modem */
	modemInit();
	
	/* Dial-Status: 6-FINI_INIT */
	mobile_set_modem_stat(DIAL_FINI_INIT);
	LTE4G_DEBUG(DEBUG_INFO, "Dial-Status: 6-FINI_INIT\n");

	LTE4G_DEBUG(DEBUG_INFO, "at_send_sms begin...\n");
	if ((ret = pthread_create(&tids[SEND_SMS_THREAD], NULL, (void *)&at_send_sms, NULL)) != OK)		// ���ŷ����߳�
	{
		LTE4G_DEBUG(RT_ERROR, "pthread_create at_send_sms err, ret = %d\n", ret);
	}

	/* ��ʾģ���Ѿ���ʼ����� */ 
	LTE4G_DEBUG(DEBUG_INFO, "initFinish before ---pause\n");
	shareMemParam->initFinish = 1;
	
	/* ��ʼ����ɺ��������� */
	if (0 == shareMemParam->manualPause)
	{
		resumeDial();					
	}

	lastCheckTime = time(NULL); 

	pthread_mutex_lock(&rilSem);
	bTastExitStatus |= 1 << 1;
	pthread_mutex_unlock(&rilSem);

	memset(&(shareMemParam->smsList), 0, MAX_SMSLIST_NUM *sizeof(SMS_LIST_1));

	FOREVER
	{
		if (atFd == ERROR)
		{
			LTE4G_DEBUG(RT_ERROR, "checkModemStatus: exit");
			break;
		}

		atcmd_snd_other();

		// �����ǰpin����������Ҫ��PUK��ȥ����SIM��������������PIN��
		if (strlen((char *)(shareMemParam->pinInfo.puk)) != 0 && 
		((shareMemParam->pinInfo.pinStatus == CPIN_PUK) || (shareMemParam->pinInfo.pinStatus == CPIN_PUK2)))
		{
			memcpy(renew_pincode.oldcode,  shareMemParam->pinInfo.puk, strlen((char*)shareMemParam->pinInfo.puk));
			memcpy(renew_pincode.newcode,  shareMemParam->pinInfo.newPin, strlen((char*)shareMemParam->pinInfo.newPin));
			ret = mobile_AT_set_new_pincode(&renew_pincode, NULL);

			memset(response, 0, sizeof(response));
			if (OK == mobile_AT_check_sim_isLock(NULL, response))
			{
				getPinInfo(response);
			}

			if (retVal == OK)
			{
				retVal = 1;	/* pin manage excute OK */
			}
			shareMemParam->curCommRet = retVal;	/* set the return value of pin related function */		

			memset(shareMemParam->pinInfo.puk, 0, 12);
			memset(shareMemParam->pinInfo.newPin, 0, 12);
		}
		
		curT = time(NULL);
		/* send query command every interval Time: AT^SYSINFO, AT+CSQ. (EVDO: AT^HDRCSQ), and so on... 
		 * send these AT commands in different interval time to avoid the overload of the physical AT channel.  */
		if ((curT >= lastCheckTime + intervalTime) || curT < lastCheckTime)  	/* query interval: 2 seconds */
		{
		 	 	
			update_mobile_info_regularly(ATComTurn);
			check_is_need_switch_network();

		 
			if(ATComTurn++ >=10)
				ATComTurn = 1;
			lastCheckTime = curT;
		}
		usleep(10*1000);
	}
	pthread_mutex_lock(&rilSem);
	bTastExitStatus &= ~(1 << 1);
	pthread_mutex_unlock(&rilSem);
	pthread_cleanup_pop(0);
	return;
}


/**@brief        �ر��շ�ATָ���ͨ��
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
void releaseATChannel(void)
{
	while (atFd != ERROR)
	{
		pthread_testcancel();
		if (close(atFd) != 0)
		{
			mobile_log_write("<releaseATChannel>:close atFd err: 0x%x\n", errno);
			LTE4G_DEBUG(RT_ERROR, "<releaseATChannel>: close atFd err: 0x%x\n", errno);
			sleep(1);
			continue;
		}
		atFd = ERROR;
	}

	return;
}


/**@brief        ��phoneNum��������Ϊmsg�Ķ���
 * @param[in]    phoneNum: �绰����
 * @param[in]    msg: ��������
 * @param[out]   ��
 * @return       OK:0,ERROR:-1
 */
STATUS ATSendSMS(char * phoneNum, char * msg)
{
	char atCommand[32] = {0};
	int nPduLength = 0;
	unsigned char nSmscLength = 0;
	char pdu[512]={0};
	char printfBuf[256]={0};
	SM_PARAM smParam;
	int fd = atFd;
	int retVal = ERROR;

	memset(&smParam, 0, sizeof(SM_PARAM));
	
	if(NULL == phoneNum || NULL == msg)
	{
		LTE4G_DEBUG(RT_ERROR, "input param error\n");
		return retVal;
	}

	if(ERROR == fd)
	{
		LTE4G_DEBUG(RT_ERROR, "the wireless modem is not valid\n");
		return retVal;
	}

	if(strlen(msg) > MAX_SMS_LEN)
	{
		LTE4G_DEBUG(RT_ERROR, "the short message is too long\n");
		return retVal;
	}
	
	LTE4G_DEBUG(DEBUG_INFO, "send to [%s] a message:%s.\n", phoneNum, msg);
	
	if (SMS_TEXT_MODE == smsFormat)
	{
		writeline(fd, "AT^HSMSSS=0,0,6,0");	/* set SMS param */
		nSmscLength = strGB2Unicode(msg, (unsigned char *)pdu, strlen(msg));
		sprintf(printfBuf, "%d, %d", nSmscLength, strlen(msg));
		atPrintf(printfBuf);
		sprintf(atCommand, "AT^HCMGS=\"%s\"", phoneNum);
		while (prepareATResponse() != OK)
		{
			pthread_testcancel();
			usleep(500*1000);
		}
		writeline(fd, atCommand);
		retVal = waitATResponse(">", (char*)NULL, 0, TRUE, 2000);
		if (retVal == OK)
		{
			retVal = writeCtrlZ(fd, pdu, nSmscLength);
		}

		releaseATResponse();
	}
	else /*PDU mode*/
	{
		// �����Ų�����
		initSmParam(&smParam, phoneNum, msg);
		
		LTE4G_DEBUG(DEBUG_INFO,"smParam.TPA = %s, SMSCenter = %s\n",smParam.TPA,SMSCenter);

		// ���պ��볤�ȼ��
		if(strlen(smParam.TPA) > strlen(SMSCenter))
		{
			LTE4G_DEBUG(RT_ERROR, "send sms failed, the phone number is too long\n");
			return ERROR;
		}

		nPduLength = gsmEncodePdu(&smParam, pdu);
		gsmString2Bytes(pdu, &nSmscLength, 2);
		nSmscLength++;

		LTE4G_DEBUG(DEBUG_INFO, "the pdu after encode is: %s\n", pdu);
		sprintf(printfBuf, "nPduLength[%d], nSmscLength[%d]", nPduLength, nSmscLength);
		atPrintf(printfBuf);
		
		if(MODE_EVDO == mobile_mode)
		{
			sprintf(atCommand, "AT^HCMGS=%d", nPduLength / 2 - nSmscLength);	/* SMS send */
		}
		else
		{
			sprintf(atCommand, "AT+CMGS=%d", nPduLength / 2 - nSmscLength);	/* SMS send */
		}
		
		while (prepareATResponse() != OK)
		{
			pthread_testcancel();
			usleep(500*1000);
		}
		writeline(fd, atCommand);
		
		/* wait \r\n> */
		retVal = waitATResponse(">", (char*)NULL, 0, TRUE, 2000);
		if (retVal == OK)
		{
			retVal = writeCtrlZ(fd, pdu, nPduLength);
		}
		else
		{
			retVal = writeCtrlZ(fd, pdu, nSmscLength);
		}
		/*wait response*/
		releaseATResponse();
	}
	return retVal;
}


/**@brief        ��fd�з����ַ���s
 * @param[in]    fd: ģ��������ļ�������
 * @param[in]    s: �ַ���
 * @param[out]   ��
 * @return       OK:0,ERROR:-1
 */
STATUS writeline(int fd, const char *s)
{
	int cur = 0;
	int len = 0;
	int written =  ERROR;
	fd_set wSet;
	struct timeval selectTimeout = {6, 0};
	int sRet = ERROR;

	if(NULL == s)
	{
		LTE4G_DEBUG(RT_ERROR, "writeline: input NULL\n");
		return ERROR;
	}

	len = strlen(s);
	atPrintf(s);
	if (fd < 0)
	{
		return ERROR;
	}

	selectTimeout.tv_sec = 6;
	selectTimeout.tv_usec = 0;
		
	FD_ZERO(&wSet);
	FD_SET(fd, &wSet);
	if ((sRet = select (fd + 1, NULL, &wSet, NULL, &selectTimeout)) < 0) 
	{
		LTE4G_DEBUG(RT_ERROR, "writeline: sRet = %d, errno = 0x%x\n", sRet, errno);
		return ERROR;
	}
	else if (0 == sRet)
	{
		return -2;
	}
	pthread_mutex_lock(&atFdSem);
	if (FD_ISSET(fd, &wSet))
	{
		startWriteTime = time(NULL); 	
		/* the main string */
		while (cur < len)
		{
			do
			{
				written = write(fd, s + cur, len - cur);
				
			} while ((written < 0) && (errno == EINTR));

			if (written < 0)
			{
				pthread_mutex_unlock(&atFdSem);
				startWriteTime = 0; 	
				return ERROR;
			}
			cur += written;
		}
		/* the \r  */
		do
		{
			written = write(fd, "\r", 1);
		} while (((written < 0) && (errno == EINTR)) || (written == 0));
		startWriteTime = 0; 	
	}

	pthread_mutex_unlock(&atFdSem);
	if (written < 0)
	{
		return ERROR;
	}

	usleep(100*1000);
	return 0;
}


/**@brief        ��fd�з���s��,�ٷ���0x00 0x1a
 * @param[in]    fd: ģ��������ļ�������
 * @param[in]    s: �ַ���
 * @param[in]    len: s�ĳ���
 * @param[out]   ��
 * @return       OK:0,ERROR:-1
 */
static int writeCtrlZ(int fd, const char *s, int len)
{
	int cur = 0;
	int written = 0;
	char CtrlZ[2] = {0};
	fd_set wSet;
	struct timeval selectTimeout = {6, 0};
	int sRet = ERROR;

	CtrlZ[0] = 0x00;
	CtrlZ[1] = 0x1a;
	
	if (fd < 0)
	{
		LTE4G_DEBUG(RT_ERROR, "written error, fd < 0\n");
		return ERROR;
	}
	
	selectTimeout.tv_sec = 6;
	selectTimeout.tv_usec = 0;
		
	FD_ZERO(&wSet);
	FD_SET(fd, &wSet);
	if ((sRet = select (fd + 1, NULL, &wSet, NULL, &selectTimeout)) < 0) 
	{
		LTE4G_DEBUG(RT_ERROR, "writeCtrlZ: sRet = %d, errno = 0x%x\n", sRet, errno);
		return ERROR;
	}
	else if (sRet == 0)
	{
		return -2;
	}
		
	pthread_mutex_lock(&atFdSem);
	if (FD_ISSET(fd, &wSet))
	{
		/* the main string */
		while (cur < len)
		{
			do
			{
				written = write(fd, s + cur, len - cur);
			} while (written < 0 && errno == EINTR);

			if (written < 0)
			{
				pthread_mutex_unlock(&atFdSem);
				LTE4G_DEBUG(RT_ERROR, "written error\n");
				return ERROR;
			}

			cur += written;
		}

		/* the ^Z  */
		if(MODE_EVDO == mobile_mode)
		{
			do
			{
				written = write(fd, CtrlZ, 2);
			} while ((written < 0 && errno == EINTR) || (written == 0));
		}
		else if( MODE_WCDMA == mobile_mode || MODE_TDSCDMA == mobile_mode 
			|| MODE_TDLTE == mobile_mode|| MODE_FDDLTE == mobile_mode)
		{
			do
			{
				written = write(fd, &CtrlZ[1], 1);
			} while ((written < 0 && errno == EINTR) || (written == 0));
		}
		else
		{
			LTE4G_DEBUG(RT_ERROR, "send SMS, writeCtrlZ, error mode. mode = %d\n", mobile_mode);
		}
	}
	pthread_mutex_unlock(&atFdSem);

	if (written < 0)
	{
		LTE4G_DEBUG(RT_ERROR, "written error, written < 0\n");
		return ERROR;
	}

	return 0;
}

/**@brief        �ж�line�Ƿ���prefix��ͷ
 * @param[in]    line: ��Ҫ�������ַ���
 * @param[in]    prefix: ��ͷ�ַ���
 * @param[out]   ��
 * @return       0:FALSE, 1:TRUE
 */
static int strStartsWith(const char *line, const char *prefix)
{
	if(NULL == line || NULL == prefix)
	{
		return FALSE;
	}

	for (; *line != '\0' && *prefix != '\0'; line++, prefix++)
	{
		if (*line != *prefix)
		{
			return FALSE;
		}
	}

	return *prefix == '\0';
}


/**@brief        ������һ��'\0'
 * @param[in]    �� 
 * @param[out]    ��
 * @return       '\0'��λ�û�NULL
 */
static char * findNextEOL(char *cur)
{
	if (cur[0] == '>' && cur[1] == ' ' && cur[2] == '\0')
	{
		/* SMS prompt character...not \r terminated */
		return cur + 2;
	}

	// Find next newline
	/* zqs modify 091217, in order to avoid confliction of '\0' in SMS content which is in UNICODE format */
	//while (*cur != '\0' && *cur != '\r' && *cur != '\n')
	//while ((*cur != '\0' || (*(cur + 1) != '\0' && *(cur + 1) != '\n')) && *cur != '\r' && *cur != '\n')	
	while ((*cur != '\0' || *(cur + 1) != '\0' || *(cur + 2) != '\0') 
		&& (*cur != '\r' || *(cur + 1) != '\n'))
	{
		cur++;
		//cur += 2;
	}

	return *cur == '\0' ? NULL : cur;
}


/**@brief        ��ģ������ڶ�����
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��ģ������ڶ�ȡ������
 */
static const char *readLine()
{
	int count = ERROR;
	int len = 0;
	int atFdTmp = ERROR;
	char *p_read = NULL;
	char *p_eol = NULL;
	char *cmd = NULL;
	fd_set rSet;
	struct timeval selectTimeout = {6, 0};
	int sRet = ERROR;

	
	if (*s_ATBufferCur == '\0' && *(s_ATBufferCur + 1) == '\0' && *(s_ATBufferCur + 2) == '\0')		
	{
		/* zqs modify 091217, in order to avoid confliction of '\0' in SMS content which is in UNICODE format */
		/* there's no data in the buffer */
		s_ATBufferCur = s_ATBuffer;
		//*s_ATBufferCur = '\0';
		memset(s_ATBuffer, 0, sizeof(s_ATBuffer));
		p_read = s_ATBuffer;
	}
	else
	{
		// skip over leading newlines
		while (*s_ATBufferCur == '\r' && *(s_ATBufferCur + 1) == '\n')
			s_ATBufferCur += 2;

		p_eol = findNextEOL(s_ATBufferCur);
		if (p_eol == NULL)
		{
			/* a partial line. move it up and prepare to read more */
			len = strlen(s_ATBufferCur);
			//memmove(s_ATBuffer, s_ATBufferCur, len + 1);
			memmove(s_ATBuffer, s_ATBufferCur, len);
			//p_read = s_ATBuffer + len;
			p_read = s_ATBuffer + len;
			s_ATBufferCur = s_ATBuffer;
			memset(s_ATBuffer + len, 0, sizeof(s_ATBuffer) - len);
		}
		/* Otherwise, (p_eol = NULL) there is a complete line  */
		/* that will be returned the while () loop below        */
	}
	while (p_eol == NULL)
	{
		if (NULL == p_read)
		{
			return NULL;
		}
		
		if (0 == (MAX_AT_RESPONSE - (p_read - s_ATBuffer)))
		{
			/* ditch buffer and start over again */
			s_ATBufferCur = s_ATBuffer;
			//*s_ATBufferCur = '\0';
			memset(s_ATBuffer, 0, sizeof(s_ATBuffer));
			p_read = s_ATBuffer;
		}

		selectTimeout.tv_sec = 6;
		selectTimeout.tv_usec = 0;
		if (atFd != ERROR)
		{
			atFdTmp = atFd;
		}
		else
		{
			return NULL;
		}
			
		FD_ZERO(&rSet);
		FD_SET(atFdTmp , &rSet);
		if ((sRet = select (atFdTmp + 1, &rSet, NULL, NULL, &selectTimeout)) <= 0) 
		{
			// ע:�˴�����LTE4G_DEBUG����ʹ���߳��޷���ȡ����ԭ����ʱ����
			return NULL;
		}
		pthread_mutex_lock(&atFdSem);
		if (FD_ISSET(atFdTmp, &rSet))
		{
			count = read(atFdTmp, p_read, MAX_AT_RESPONSE - (p_read - s_ATBuffer));
		}
		pthread_mutex_unlock(&atFdSem);


		if (count > 0)
		{
			//p_read[count] = '\0';
			// skip over leading newlines
			while (*s_ATBufferCur == '\r' && *(s_ATBufferCur + 1) == '\n' )
				s_ATBufferCur += 2;
			p_eol = findNextEOL(s_ATBufferCur);
			p_read += count;
		}
		else if (count <= 0)
		{
			/*log do something.*/
			LTE4G_DEBUG(DEBUG_INFO, "Read nothing\n");
			return NULL;
		}
	}

	/* a full line in the buffer. Place a \0 over the \r and return */

	cmd = s_ATBufferCur;
	*p_eol = '\0';
	*(p_eol + 1) = '\0';
	s_ATBufferCur = p_eol + 2; /* this will always be <= p_read,*/
	/* and there will be a \0 at *p_read */

	return cmd;
}


/**@brief        �ȴ�AT ��Ӧ,����Ӧ��startString ��ʼ
 * @param[in]    startString:��Ӧ��startString��ʼ
 * @param[in]    breakWhileError:���������Ƿ��˳�
 * @param[in]    waitTick:�ȴ���ʱ��,��tickΪ��λ
 * @param[in]    fullLen:fullString�ĳ���
 * @param[out]   fullString:��Ӧ�������ִ�, ���ΪNULL,������
 * @return       �ɹ��ӵ���Ӧ OK / ���ִ��� ERROR
 */
static STATUS waitATResponse(const char* startString, char* fullString,
				int fullLen, BOOL breakWhileError, int waitTick)
{
	int startTick = 0;
	int endTick = 0;
	AT_RESPONSE_NODE *var =  NULL;
	char * p = NULL;
	int errNo = ERROR;

	var = (AT_RESPONSE_NODE*)lstFirst(&atResponse.atList);
	endTick = startTick = tickGet();

	while ((endTick - startTick) <= waitTick)
	{
		var = (AT_RESPONSE_NODE*)lstFirst(&atResponse.atList);
		while (var != NULL)
		{
			if (strStartsWith(var->atResponse, startString))
			{
#ifdef LAST_RESP
				if(fullString != NULL && fullLen >0 && lastRsp.bEnable == 0)
#else
				if(fullString != NULL && fullLen >0)
#endif
				{
					strncpy(fullString, var->atResponse, fullLen-1);
					fullString[fullLen -1] = '\0';
				}
				return OK;
			}

#ifdef LAST_RESP
			if (lastRsp.bEnable)
			{
				if (fullString != NULL && fullLen >0)
				{
					if (strlen(var->atResponse) > 0 && var->atResponse[0] != 0x0d)
					{
						strncpy(fullString, var->atResponse, fullLen-1);
						fullString[fullLen -1] = '\0';
					}
				}
			}
#endif

			if(breakWhileError)
			{
				/* �Ժ���������һ������������� */
				if (strstr(var->atResponse, "+CME ERROR:") != NULL)
				{
					if(NULL == (p = strstr(var->atResponse, ":")))
						return ERROR;
					p++;
					if (isspace((int) *p))
					{
						p++;
					}
					if (*p >= '0' && *p <= '9')	/* "+CME ERROR:"������Ǵ����� */
					{
						errNo = atoi(p);
						if (errNo == 16)		/* incorrect password */
						{
							return INCORRECT_PASSWD;		/* �Ժ���ĳ�return -16 */
						}
						else
						{
							return -errNo;
						}
					}
					else						/* "+CME ERROR:"������Ǵ��������ı� */
					{
						if (strstr(p, "incorrect password"))
						{
							return -2;		
						}
						else if (strstr(p, "SIM not inserted"))
						{
							return SIM_NOT_INSERTED;
						}
						else if (strstr(p, "SIM PIN required"))
						{
							return SIM_PIN_REQUIRED;
						}
						else if (strstr(p, "SIM PUK required"))
						{
							return SIM_PUK_REQUIRED;
						}
						else if (strstr(p, "SIM failure"))
						{
							return SIM_FAILURE;
						}
						else
						{
							return ERROR;
						}
					}
				}
				else if (strstr(var->atResponse, "ERROR") != NULL ||
						strstr(var->atResponse, "COMMAND NOT SUPPORT") != NULL)           /*�д���*/
				{
					return ERROR;
				}
			}
			var = (AT_RESPONSE_NODE*)lstNext(&var->node);
		}

		if (waitTick == 0)
		{
			return ERROR;
		}

		usleep(10000);
		endTick = tickGet();
	}
	return ERROR;
}


/**@brief        �ͷŽ���ATָ�����ʱ����
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
static void releaseATResponse(void)
{
	AT_RESPONSE_NODE *var =  NULL;
	
	var = (AT_RESPONSE_NODE*)lstFirst(&atResponse.atList);
	pthread_mutex_lock(&rilSem);
	
	/*�ͷ������������Դ*/
	atResponse.used = FALSE;
	while(var != NULL)
	{
		if(var->atResponse != NULL)
		{
			free(var->atResponse);
			var->atResponse = NULL;
		}
		lstDelete(&atResponse.atList, &var->node);
		free(var);
		var = (AT_RESPONSE_NODE*)lstFirst(&atResponse.atList);
	}
//	LTE4G_DEBUG(DEBUG_NOTICE, "lstcount is %d\n", lstCount(&atResponse.atList));
	lstFree(&atResponse.atList);            /*����ͷβ����*/
	pthread_mutex_unlock(&rilSem);
}


/**@brief        ׼����ʱ��������AT������Ϣ, �μ� ATRecvOtherResponse
 * @param[in]    ��
 * @param[out]   ��
 * @return       �����ʱ�����ѱ�ʹ��,����ERROR,����,OK
 */
static STATUS prepareATResponse(void)
{
	pthread_mutex_lock(&rilSem);
	if(atResponse.used)     /*һ��ֻ�ܴ���һ���������Ӧ*/
	{
		atPrintf("atResponse is used");
		pthread_mutex_unlock(&rilSem);
		return ERROR;
	}
	atResponse.used = TRUE;
	lstFree(&atResponse.atList); 
	pthread_mutex_unlock(&rilSem);
	return OK;
}


/**@brief        AT���ʱ����д��
 * @param[in]    fd:�ļ�������
 * @param[in]    s:��д���ATָ��
 * @param[in]    startString:��Ӧ��startString��ʼ
 * @param[in]    breakWhileError:���������Ƿ��˳�
 * @param[in]    waitTick:�ȴ���ʱ��,��tickΪ��λ
 * @param[in]    fullLen:fullString�ĳ���
 * @param[out]   fullString:��Ӧ�������ִ�, ���ΪNULL,������
 * @return       OK:0,ERROR:-1
 */
int writeATCommand(int fd, const char *s, const char* startString, char* fullString,
                int fullLen, BOOL breakWhileError, int waitTick)
{
	int retVal = ERROR;
	int i = 0;
	int ret = ERROR;
	int countOvertime = 0;
	char command[128];
	char compare[128];
	char *p1 = NULL, *p2 = NULL;
	int prepFaildTimes = 0;

	memset(command, 0, sizeof(command));
	memset(compare, 0, sizeof(compare));
	
	if ((FALSE == strStartsWith(s, "AT")) && (FALSE == strStartsWith(s, "at")))
	{
		return ERROR;
	}
	if(ERROR == fd)
	{
		atPrintf("writeATCommand: exit");
		return ERROR;
	}
	while(FD_USB_DOWN == fd)
	{
		pthread_testcancel();
		sleep(1);
		//continue;
	}

	/* ÿ��ʹ��writelineǰҪ��prepareATResponse,��ɺ�ҪreleaseATResponse */
	while (prepareATResponse() != OK)
	{
		pthread_testcancel();
		usleep(500*1000);
		if (++prepFaildTimes >= 10)
		{
			return ERROR;
		}
	}
	
#if 0	//Those code were compatible with other 4G moudles, such as EM700,EM770W.
	if (strStartsWith(s, "AT^") && shareMemParam->iModel != M_HUAWEI_4G)
	{
		strcpy(command, s);
		p1 = strstr(command, "^");
		*p1 = '%';
		strcpy(compare, startString);
		if ((p2 = strstr(compare, "^")) != NULL)
		{
			*p2 = '%';
		}

		if(writeline(fd, (const char *)command) != OK)
		{
			LTE4G_DEBUG(RT_ERROR, "send AT command[%s] faild!\n", command);
			return ERROR;
		}
		retVal = waitATResponse((const char *)compare, fullString, fullLen, breakWhileError, waitTick);
	}
	else
#endif
	{
		if(writeline(fd, s) != OK)
		{
			LTE4G_DEBUG(RT_ERROR, "send AT command:[%s] faild!\n", s);
			return ERROR;
		}
		retVal = waitATResponse(startString, fullString, fullLen, breakWhileError, waitTick);
	}

	releaseATResponse();
	if (retVal == ERROR)
	{
		LTE4G_DEBUG(KEY_WARN, "write AT cmd error, [%s]\n", s);
		sleep(1);
		for (i = 0; i< 5; i++)
		{
			while (prepareATResponse() != OK)
			{
				pthread_testcancel();
				usleep(500*1000);
			}
			if (OK == (ret = writeline(fd, "AT")))
			{
				LTE4G_DEBUG(DEBUG_INFO, "ret = ok, i = %d, s = <%s>\n",i, s);
				if (waitATResponse("OK", (char*)NULL, 0, TRUE, 300) == OK)
				{
					releaseATResponse();
					break;
				}
				else if (++countOvertime >= 5)
				{
					releaseATResponse(); 
					LTE4G_DEBUG(RT_ERROR, "ok,++countOvertime >= 5, command = %s\n",s);
					dial_error_occur(EXIT_DIAL_ABNORMAL);
				}
				releaseATResponse();
				sleep(1);
				continue;
			}
			else if (-2 == ret)
			{
				LTE4G_DEBUG(DEBUG_INFO, "ret = -2,i = %d, s = <%s>\n",i, s);
				if (++countOvertime >= 5)
				{
					releaseATResponse();
					LTE4G_DEBUG(RT_ERROR, "-2,++countOvertime >= 5\n");
					dial_error_occur(EXIT_DIAL_ABNORMAL);
				}
				else
				{
					releaseATResponse();
					continue;
				}
			}
			else if (ERROR == ret)
			{
				releaseATResponse();
				LTE4G_DEBUG(RT_ERROR, "ret = error, s = <%s>\n",s);
				dial_error_occur(EXIT_DIAL_ABNORMAL);
			}
		}
	}
	else if ((SIM_PIN_REQUIRED == retVal) || (SIM_PUK_REQUIRED == retVal))/* AT Command return: "CME ERROR: SIM PIN required" or "CME ERROR: SIM PUK required" */
	{
		shareMemParam->pinInfo.pinLockStatus = 1;   /* has been locked */
		mobile_simStat = SIM_VALID;
	}
	else if ((SIM_NOT_INSERTED == retVal) || (SIM_FAILURE == retVal)) /* AT Command return: "CME ERROR: SIM not inserted" or "CME ERROR: SIM failure" */
	{
		mobile_simStat = SIM_NOTEXIST;
	}

	return retVal;
}


/**@brief        ATָ������̣߳�ѭ����AT�豸�������
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
static void ATReaderLoop(void)
{
	const char* line = NULL;
	char lineHead[MAX_SMS_HEAD];
	const char* lineContent = NULL;	
	int index = 0;
	SMS_STATUS tmpSmsStatus;
	int i = 0;
	char command[128];
	int smslen = 0;
	BOOL bReadNewSms = FALSE;

	//�����߳�����
	prctl(15, (unsigned long)"4G_ATReaderLoop");
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);		//�߳̿��Ա�ȡ����
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS,NULL);	//��������Դ��Ҫ�ͷţ������˳�

	memset(lineHead, 0, MAX_SMS_HEAD);
	memset(command, 0, sizeof(command));
	memset(&tmpSmsStatus, 0, sizeof(tmpSmsStatus));
	LTE4G_DEBUG(DEBUG_INFO, "<ATReaderLoop>: enter\n");

	pthread_mutex_lock(&rilSem);
	bTastExitStatus |= 1 << 0;
	pthread_mutex_unlock(&rilSem);
	
	FOREVER
	{
		if(ERROR == atFd)
		{
			atPrintf("ATReaderLoop: exit");
			break;
		}

		while(FD_USB_DOWN == atFd)
		{
			pthread_testcancel();
			sleep(1);
		}
		
		/*��ģ��AT USB���ж�ȡһ������*/
		line = readLine();

		 /*������ʧ��*/
		if(NULL == line)
		{ 
			LTE4G_DEBUG(KEY_WARN, "ATReaderLoop: readline null\n");
			/* bug. ģ��ε�ʱselect���ز�������read����Ϊ0�������޼�Ъѭ��ϵͳ��ס */
			usleep(100);	
			continue;
		}
		if (isCertainResponse(line, "+CGDCONT:", NULL, NULL))
		{
			atPrintf(line);
			//mobile_get_curentAPNS(line);
		}
		/*���յ�һ���µĶ���֪ͨ*/
		else if (isCertainResponse(line, "+CMTI:", NULL, NULL))		
		{
			atPrintf(line);
			strncpy(lineHead, line, MAX_SMS_HEAD-1);
			LTE4G_DEBUG(DEBUG_INFO, "Recive a new SMS \n");
			if(ERROR == (index = ATReceiveNotes(lineHead)))
			{
				continue;
			}

			sms_status[smsNum].index = index;
			shareMemParam->smsReadStat |= 1 << index;

			bReadNewSms = TRUE;
			continue;
		}
		else if (isCertainResponse(line, "^HCMGR:", "+CMGR:", NULL))	 /* ������*/
		{
			atPrintf(line);
			strncpy(lineHead, line, MAX_SMS_HEAD-1);
			lineContent = readLine();
			LTE4G_DEBUG(DEBUG_INFO, "Read SMS \n");

			smslen = (int)(s_ATBufferCur - lineContent -2);
			/*����Ƕ���(+CMT��ͷ,�ٶ�һ��)*/
			if(NULL == lineContent)
			{
				atPrintf("ATReaderLoop: read SMS error \n");
				continue;
			}
			/*do something*/
			if (smslen)
			{
				ATReadSMS(lineHead, lineContent, index, smslen, &tmpSmsStatus, bReadNewSms);
				if (bReadNewSms)
				{
					bReadNewSms = FALSE;
				}
			}
			
			if (0 == smsNum)	/* add first sms */
			{
				tmpSmsStatus.index = sms_status[smsNum].index;
				memcpy(&sms_status[smsNum], &tmpSmsStatus, sizeof(SMS_STATUS));
				smsNum++;
			}
			else
			{
				for (i = 0; i < smsNum; i++)
				{
					if ((strcmp((char *)(sms_status[i].recvTime), (char *)(tmpSmsStatus.recvTime)) == 0) 
						&& (sms_status[i].index == sms_status[smsNum].index))
					//if (sms_status[i].index == sms_status[smsNum].index)
					{
						break;
					}

					if ((smsNum-1) == i)		/* add new sms */
					{
						tmpSmsStatus.index = sms_status[smsNum].index;
						memcpy(&sms_status[smsNum], &tmpSmsStatus, sizeof(SMS_STATUS));
						smsNum++;
						smsBubbleSort(smsNum);
						if (smsNum > MAX_SMSLIST_NUM)
						{
							sprintf(command, "AT+CMGD=%d", sms_status[0].index);
							//writeline(atFd, command);
							add_atcmd_buff(command);
							smsNum--;
							shareMemParam->smsReadStat &= ~(1 << sms_status[0].index);
							memmove(&sms_status[0], &sms_status[1], MAX_SMSLIST_NUM * sizeof(SMS_STATUS));
							memset(&sms_status[10], 0, sizeof(SMS_STATUS));
						}
						break;
					}
				}
			}
			continue;
		}
		else if (isCertainResponse(line, "^SMMEMFULL", "%SMMEMFULL", "+SMMEMFULL")) /* ���յ����������ϱ���Ϣ */
		{
			atPrintf(line);
			(void)AT_clean_sms(SMS_PDU_MODE, SMS_CLEAN_READ_UNREAD_SEND_UNSEND, NULL);
		}
		else if (isCertainResponse(line, "+CLIP:", NULL, NULL)) /*�ӵ�һ���绰����*/
		{
			atPrintf(line);
			ATReceiveACall(line);
		}
		else if (isCertainResponse(line, "^MODE:", "%MODE:", NULL)) /* ���յ���ǰ����ģʽ */
		{
			atPrintf(line);
			ATReceiveMode(line);
		}
		else if (isCertainResponse(line, "^DSFLOWRPT:", NULL, NULL))	/* ���˵��ϱ���Ϣ */
		{
			ATReceiveFilter();
			//ATReceiveHRSSILVL();
		}
	    else if (isCertainResponse(line, "+PSRAT:", NULL, NULL))
		{
		    	atPrintf(line);
		    	ATReceivePSRAT(line); 
		}
		else if (isCertainResponse(line, "^SYSINFO:", "%SYSINFO:", "^SYSINFOEX:"))		/* ϵͳ��ѯ������Ϣ */
		{
			atPrintf(line);
			ATReceiveSYSINFO(line);
		}
		else if(isCSQRecieve(line)) 	/* ��ȡ��ǰ ������ź�ǿ�� */
		{
			atPrintf(line);
			ATReceiveCSQ(line);
		}
		else if (isCertainResponse(line, "+CFUN:", NULL, NULL)) 	/* ģ�����ģʽ��Ϣ */
		{
			atPrintf(line);
			ATReceiveCFUN(line);
		}
		else if (isCertainResponse(line, "+COPS:", NULL, NULL)) 	/* ��������Ϣ */
		{
			atPrintf(line);
			ATReceiveCOPS(line);
		}
		else if (isCertainResponse(line, "+CREG:", "+CGREG:", "+CEREG:"))	/* ����ע����Ϣ CREG-3G CGREG-2G CEREG-4G*/
		{
			atPrintf(line);
			ATReceiveCREG(line);
		}
		else /*ATָ�����ʱ��Ӧ,��ʶ�����Ϣ*/
		{
			atPrintf(line);
			ATRecvOtherResponse(line);
		}

		usleep(10*1000);
	}

	lstFree(&atResponse.atList);

	pthread_mutex_lock(&rilSem);
	bTastExitStatus &= ~(1 << 0);
	pthread_mutex_unlock(&rilSem);
	return;
}



/**@brief        ��ӡ�ַ���
 * @param[in]    stringline: ��Ҫ��ӡ���ַ���
 * @param[out]   ��
 * @return       ��
 */
static void atPrintf(const char *stringline)
{
	if(NULL == stringline)
	{
		return;
	}
	
	//LTE4G_DEBUG(DEBUG_INFO, "atPrintf: %s\n",stringline);
	return;
}

/**@brief        ����ATָ����ͻ�����
 * @param[in]    line: ��Ҫ���ͻ������ַ���
 * @param[out]   ��
 * @return       OK:0,ERROR:-1
 */
static STATUS add_atcmd_buff(char * line)
{
	int i = 0;

	if(NULL == line)
	{
		return ERROR;
	}
	
	for (i = 0; i < MAX_SHM_ATCOM_NUM; i++)
	{
		if (strlen(shareMemParam->ATComBuf[i]) == 0)
		{
			if(strlen(line) < sizeof(shareMemParam->ATComBuf[i]))
			{
				strcpy(shareMemParam->ATComBuf[i], line);
				return OK;
			}
			else 
				return ERROR;
		}		
	}
	return ERROR;
}

/**@brief        �����Ų�����
 * @param[in]    phoneNum: �绰����
 * @param[in]    message: ��������
 * @param[out]   pDst:���Ų�������ַ
 * @return       OK:0,ERROR:-1
 */
static void initSmParam(SM_PARAM *pDst, const char* phoneNum,
		const char* message)
{
	char phone[16] = {0};
	int len = 0;
	int i = 0;
	char phoneNum_tmp[32] = {0};

	if(pDst == NULL || phoneNum == NULL || message == NULL)
	{
		LTE4G_DEBUG(RT_ERROR, "Input param error!\n");
		return;
	}

	memset(phone, 0, sizeof(phone));
	memset(phoneNum_tmp, 0, sizeof(phoneNum_tmp));
	strncpy(phoneNum_tmp, phoneNum, MIN(strlen(phoneNum), (sizeof(phoneNum_tmp) -1)));

	// ȥ�����ǰ����ַ�'0'
	len = strlen(phoneNum_tmp);
	while(phoneNum_tmp[i++] == 0x30 && i < len);
	strncpy(phoneNum_tmp, phoneNum_tmp + i - 1, MIN(strlen(phoneNum_tmp + i - 1), sizeof(phoneNum_tmp)));

	LTE4G_DEBUG(DEBUG_INFO, "phoneNum[%s]->[%s]\n", phoneNum, phoneNum_tmp);

	if('+' == phoneNum_tmp[0])				/*ȥ��+��*/
	{
		// eg. "+8615959971212"
		memcpy(phone, phoneNum_tmp + 1, MIN(strlen(phoneNum_tmp + 1), sizeof(phone) - 1));
	}
	else
	{
		LTE4G_DEBUG(DEBUG_INFO, "language = %d\n", shareMemParam->language);
		if(shareMemParam->language == 1)
		{
			// �����豸
			strcpy(phone, phoneNum_tmp);
		}
		else
		{
			// �����豸,eg."8613524278686"
			 if((phoneNum_tmp[0] == '8') && (phoneNum_tmp[1] == '6'))	/*����86��ͷ,��86*/
			{
				 strcpy(phone, phoneNum_tmp);
			}
			else
			{
				// �����豸,eg."13524278686"
				strcpy(phone, "86");
				strncpy(phone+2, phoneNum_tmp, 13);
			}

		}
	}	

	LTE4G_DEBUG(DEBUG_INFO, "phone = %s\n", phone);

	memcpy(pDst->SCA, SMSCenter, 16);		/*�������ĺ���,���ӿ�*/ 
	memcpy(pDst->TPA, phone, 16); 
	pDst->TP_PID = 0;
	pDst->TP_DCS = GSM_UCS2;
	//pDst->TP_DCS = GSM_8BIT;
	pDst->TP_SCTS[0] = 0;
	memcpy(pDst->TP_UD, message, MIN(strlen(message), sizeof(pDst->TP_UD)));
}

/**@brief        �ж��Ƿ���CSQָ��
 * @param[in]    ��
 * @param[out]   ��
 * @return       TRUE:1, FALSE:0
 */
static BOOL isCSQRecieve(const char* line)
{
	if(NULL == line)
	{
		LTE4G_DEBUG(RT_ERROR, "isCSQRecieve: line NULL\n");
		return FALSE;
	}

	if (strStartsWith(line, "^CCSQ")
		|| strStartsWith(line, "+CSQ")
		|| strStartsWith(line, "+CCSQ"))
	{
		return TRUE;
	}
	
	return FALSE;
}

/**@brief        �ж��Ƿ���strcomp1��strcomp2��strcomp3ָ��
 * @param[in]    line:�������ַ���
 * @param[in]    strcomp1:ָ��1
 * @param[in]    strcomp2:ָ��2
 * @param[in]    strcomp3:ָ��3
 * @param[out]   ��
 * @return       OK:0,ERROR:-1
 */
static BOOL isCertainResponse(const char* line, char* strcomp1, char *strcomp2, char *strcomp3)
{
	if (line == NULL)
	{
		return FALSE;
	}
	if (strcomp1 != NULL)
	{
		if (strStartsWith(line, strcomp1))
		{
			return TRUE;
		}
	}
	if (strcomp2 != NULL)
	{
		if (strStartsWith(line, strcomp2))
		{
			return TRUE;
		}
	}
	if (strcomp3 != NULL)
	{
		if (strStartsWith(line, strcomp3))
		{
			return TRUE;
		}
	}
	return FALSE;
}

/**@brief        �ж������ֻ������Ƿ���ͬ
 * @param[in]    phone1:�ֻ�����1
 * @param[in]    phone2:�ֻ�����2
 * @param[out]   ��
 * @return       TRUE:1,FALSE:0
 */
static BOOL isPhoneNumSame(const char* phone1, const char* phone2)
{
	int len1 = 0, len2 = 0;
	int minlen = 0;
	const char *p1 = NULL;
	const char *p2 = NULL;

	if(NULL == phone1 || NULL == phone2)
	{
		return FALSE;
	}
	
	len1 = strlen(phone1);
	len2 = strlen(phone2);
	minlen = MIN(len1,len2);

	if (minlen == 0)
	{
		return FALSE;
	}

	if (minlen >= 11)         /*�ֻ������λ��,ֻ�Ⱥ�11 λ*/
	{
		minlen = 11;
	}
	else if (minlen >7)      /*7 ~ 11, ��Ϊ������,ֻ�Ⱥ�7 λ*/
	{
		minlen = 7;
	}
	p1 = phone1 +(len1 - minlen);
	p2 = phone2 +(len2 - minlen);
	
	if (strncasecmp(p1, p2, minlen) == 0)
	{
		LTE4G_DEBUG(DEBUG_INFO, "phone number is same\n");
		return TRUE;
	}
	else
	{
		LTE4G_DEBUG(DEBUG_INFO, "phone number is not same\n");
		return FALSE;
	}
}


/**@brief        ���½��յ���ATָ���Ƕ���ʱ����������ͷ����
 * @param[in]    line1:�������� 
 * @param[out]   ��
 * @return       ERROR:-1, ��������ǰ���ŵ����к�
 */
static STATUS ATReceiveNotes(const char* line1)
{
	char *p1 = NULL;
	UINT8 szTemp[8] = {0};
	int ret = 0, numLen = 0;
	UINT8 command[64] = {0};				/*����ҵ����BUFF*/

	if(NULL == line1)
	{
		return ERROR;
	}

	p1 = strstr(line1, ",");//�Һ����ĵ�һ������,������Ǹ���������
	if(p1 != NULL)
	{
		/*��ȡ�������*/
		numLen = (p1 - (char *)line1)+1;
		numLen = strlen(line1) -numLen;
		memset(szTemp, 0, sizeof(szTemp));
		strncpy((char *)szTemp, p1+1, numLen);

		ret = atoi((char *)szTemp);
		LTE4G_DEBUG(DEBUG_INFO, "Recive a new SMS index:%d\n", ret);

		/*���Ͷ��Ŷ�ȡ*/
		memset(command, 0, sizeof(command));

		if(MODE_EVDO == mobile_mode)
		{
			sprintf((char *)command, "AT^HCMGR=%d", ret);
		}
		else
		{
			sprintf((char *)command, "AT+CMGR=%d", ret);
		}

		add_atcmd_buff((char *)command);

		return ret;
	}
	return ERROR;

}


/**@brief        ���ö��Ż�ִ����������Ŀǰֻ����������reboot sucess������Ϊ���Ժ���չ���㣬д�ɺ���
 * @param[in]    whitelist_index �յ���ǰ���ŵķ������ڰ������е�λ��
 * @param[in]    ceceipt ��ǰ���Ż�ִ����
 * @param[out]   ��
 * @return       ��
 */
static void set_sms_receipt_operation(int whitelist_index, SMS_RECEIPT_OPERATION ceceipt)
{
	//�����ǰһ�εĻ�ִ�����Ƿ��Ѿ����
	while((shareMemParam->sms_receipt_operation & 0xffff) != 0)
	{
		usleep(200*1000);
	}

	shareMemParam->sms_receipt_operation = 0;
	shareMemParam->sms_receipt_operation |= whitelist_index << 16;

	shareMemParam->sms_receipt_operation |= ceceipt & 0xffff;

	LTE4G_DEBUG(DEBUG_INFO, "sms_receipt_operation = %d, whitelist_index = %d, ceceipt = %d\n", 
		shareMemParam->sms_receipt_operation, whitelist_index, ceceipt);
	
	if(SMS_OPERATION_REBOOT == ceceipt)
	{
		shareMemParam->is_need_reboot = TRUE;
	}

	LTE4G_DEBUG(DEBUG_INFO, "is_need_reboot = %d\n",shareMemParam->is_need_reboot);

	return;
}

/**@brief        ��⵱ǰ�Ƿ���Ҫ���ж��Ż�ִ
 * @param[in]    send_sms �����Ҫ��ִ����ñ����ִ���Ų���
 * @param[out]   ��
 * @return       TRUE, FALSE
 */
static BOOL check_is_need_receipt(SEND_SMS *send_sms)
{
	BOOL ret = FALSE;
	int whitelist_index = 0;
	
	if(NULL == send_sms)
	{
		LTE4G_DEBUG(RT_ERROR, "check_is_need_receipt: input param error\n");
		return FALSE;
	}
	
	if((shareMemParam->sms_receipt_operation & 0xffff) > 0)
	{
		whitelist_index = shareMemParam->sms_receipt_operation >> 16 ;
		LTE4G_DEBUG(DEBUG_INFO, "check_is_need_receipt: whitelist_index = %d, operation = %d \n", 
			whitelist_index, (shareMemParam->sms_receipt_operation & 0xffff));
		switch((shareMemParam->sms_receipt_operation & 0xffff))
		{
			case SMS_OPERATION_REBOOT:
				// ���is_need_rebootΪTRUE�����ʾ���θ��յ�reboot���ţ����λ�ִ��Ҫ������ظ�
				if(shareMemParam->is_need_reboot != TRUE)
				{
					memcpy(send_sms->phoneNum, shareMemParam->cellNumber[whitelist_index].byWhiteList, MAX_PHONE_NUM_LEN);
					memcpy(send_sms->msg, "reboot success", sizeof("reboot success"));
					shareMemParam->sms_receipt_operation = 0;
					ret = TRUE;
				}
				break;
#if 0			//����Ϊ����ʱ��������
			case SMS_OPERATION_TEST:
				memcpy(send_sms->phoneNum, shareMemParam->cellNumber[whitelist_index].byWhiteList, MAX_PHONE_NUM_LEN);
				memcpy(send_sms->msg, "test sucess", sizeof("test sucess"));
				shareMemParam->sms_receipt_operation = 0;
				ret = TRUE;
				break;
#endif
			default:
				LTE4G_DEBUG(RT_ERROR, "check_is_need_receipt: not support receipt %d\n", (shareMemParam->sms_receipt_operation & 0xffff));
				ret = FALSE;
				break;
		}
	}

	return ret;
}

static void char_to_lower(char *string)
{
	int i = 0;
	
	if(NULL == string)
	{
		LTE4G_DEBUG(RT_ERROR, "char_to_lower: input error\n");
		return;
	}
	
	for(i = 0; i < strlen(string); i++)
	{
		if(*(string + i) >= 'A' && *(string + i) <= 'Z')
		{
			*(string + i) = *(string + i) + 32;
		}
	}

	return ;
}



/**@brief        ��ȡ����Ϣʱ����,�ú��������ص��ϲ�ĺ���
 * @param[in]    line1 ��ȡ������ϢʱATָ��ĵ�һ��
 * @param[in]    line2 ��ȡ����ʱ,ATָ��صĵڶ���
 * @param[in]    index ����������
 * @param[in]    line2Len ATָ��صĵڶ��г���
 * @param[in]    smsStatus ����״̬�����ַ
 * @param[out]   ��
 * @return       OK:0,ERROR:-1
 */
static STATUS ATReadSMS(const char* line1, const char* line2, int index, int line2Len, SMS_STATUS * smsStatus, BOOL bNewSms)
{
	/*
	 ����TD��TXTģʽ�½�����Ϣ����: (text mode)
	 +CMT: "1065815401",,"09/03/11,12:14:06+02"
	 messsageContent
	 */
	char msg[164];                       /*����Ϣֻ����70�ֽ�*/
	char phoneNum[32];
	char printfBuf[256];
	const char *pTmp1 = NULL;
	const char *pTmp2 = NULL;
	SM_PARAM smParam;
	int i = 0;
	int smsEncForm = 0;

	/*TODO:WCDMA���ı�ͷ��һ��*/

	if (line1 == NULL || line2 == NULL)
	{
		return ERROR;
	}

	memset(msg, 0, sizeof(msg));
	memset(phoneNum, 0, sizeof(phoneNum));
	memset(printfBuf, 0, sizeof(printfBuf));
	memset(&smParam, 0, sizeof(SM_PARAM));
	
	pTmp1 = pTmp2 = line1;
	if (SMS_TEXT_MODE == smsFormat)
	{
		/*
		<CR><LF>^HCMGR: <callerID>, <year>, <month>, <day>, <hour>, <minute>, <second>, 
				<lang>, <format>, <length>, <prt>,<prv>,<type>,<stat> 
		<CR><LF><msg><CTRL+Z><CR><LF>
		*/
		/*ȥ��^HCMGR:*/
		pTmp1 += 7;
		pTmp2 = strchr(pTmp1, ',');
		strncpy(phoneNum, pTmp1, (pTmp2 - pTmp1));
		strncpy((char *)(smsStatus->phoneNum), phoneNum, MIN(sizeof(smsStatus->phoneNum) - 1, strlen(phoneNum)));
		strncpy((char *)(smsStatus->recvTime), pTmp2 + 1, 4);

		LTE4G_DEBUG(DEBUG_INFO, "ATReadSMS: smsStatus->phoneNum = %s, smsStatus->recvTime = %s\n", 
			smsStatus->phoneNum, smsStatus->recvTime);
	
		for (i = 0; i <5;i++)
		{
			pTmp2 = strchr(pTmp2 + 1, ',');
			/* <month>, <day>, <hour>, <minute>, <second> */
			strncpy((char *)(&(smsStatus->recvTime[i * 2 + 4])), pTmp2 + 1, 2);
		}

		if(NULL == (pTmp2 = strchr(pTmp2 + 1, ',')))
			return ERROR;
		if(NULL == (pTmp2 = strchr(pTmp2 + 1, ',')))
			return ERROR;
		pTmp2++;
		smsEncForm = atoi(pTmp2);

		line2Len = line2Len > 140  ? 140 : line2Len;		

		if (1 == smsEncForm)	/* 1-- ASCII */
		{
			/*һ���������70������modify 0318*/
			strncpy(msg, line2, line2Len);
		}
		else if (4 == smsEncForm)	/* 6-- UNICODE */
		{
			strUnicode2GB((unsigned char *)line2, msg, line2Len - 2); /* delete the last 2 byte 0x00 0x1a */
		}		
	}
	/*PUDģʽ*/
	else
	{
		initSmParam(&smParam, "", "");
		gsmDecodePdu(line2, &smParam);
		strcpy(phoneNum, smParam.TPA);
		strcpy(msg, smParam.TP_UD);
		strncpy((char *)(smsStatus->phoneNum), phoneNum, MIN(sizeof(smsStatus->phoneNum) - 1, strlen(phoneNum)));
		smsStatus->recvTime[0] = '2';						/* ����20xx ͷ */
		smsStatus->recvTime[1] = '0';
		strncpy((char *)(&smsStatus->recvTime[2]), smParam.TP_SCTS, 12);	/* SMS received time */		
	}
	
	memcpy(smsStatus->msg, msg, sizeof(smsStatus->msg));
	LTE4G_DEBUG(DEBUG_INFO, "ATReadSMS, SMS smsStatus->msg = %s, bNewSms = %d\n",smsStatus->msg, bNewSms);

	if (bNewSms)
	{
		/*����Ҫ��Ҫ��ʱ����ж�*/
		sprintf(printfBuf, "before call back in ATReceiveNewSMS %s, %s", phoneNum, msg);
		atPrintf(printfBuf);

		//����д��ĸת����Сд
		char_to_lower(msg);

		/*ƥ����Ϣ*/
		for(i = 0; i < MAX_WHITELIST_NUM; i++)
		{
			if(isPhoneNumSame((char *)phoneNum, (char *)(shareMemParam->cellNumber[i].byWhiteList))
			&& (shareMemParam->cellNumber[i].iPhoneCfg & (1 << PHONECFG_SMS_REBOOT)))  /* ������������ */
			{
				/*
				 * Compared with China MObile, 
				 * The length of SMS is longer than 1 byte in China TeleCom with EVDO mode.
				 */
				if(0 == strncmp((char *)msg, "reboot", 6) && 
					(strlen(msg) == strlen("reboot") || 
					((MODE_EVDO == mobile_mode || MODE_CDMA1X == mobile_mode) && strlen(msg) == strlen("reboot") + 1)))
				{
					LTE4G_DEBUG(DEBUG_INFO, "telephone %d(%s) call device reboot\n", i, phoneNum);
					LOG_SMS strulog;
					bzero((char *)&strulog, sizeof(LOG_SMS));
					strulog.byOnOff = TRUE;
					memcpy(strulog.szPhoneNumber, phoneNum, sizeof(phoneNum));
					sendLog(LOG_OPER_REBOOT, (char *)&strulog);
					set_sms_receipt_operation(i, SMS_OPERATION_REBOOT);
				}
				
#if 0 	// ����Ϊ����ʱ��������
				if((0 == strncmp((char *)msg, "test", 4)) || (strlen(msg) == sizeof("test")))
				{
					LTE4G_DEBUG(DEBUG_INFO, "telephone %d(%s) call device test\n", i, phoneNum);
					set_sms_receipt_operation(i, SMS_OPERATION_TEST);
				}
#endif
#if 0		//Ŀǰ�������֧��
				if(0 == strncmp((char *)msg, "on", 2) || 0 == strncmp((char *)msg, "ON", 2))
				{
					LTE4G_DEBUG(DEBUG_INFO, "telephone %d(%s) set pppd open\n", i, phoneNum);
					LOG_SMS strulog;
					bzero((char *)&strulog, sizeof(LOG_SMS));
					strulog.byOnOff = 1;
					memcpy(strulog.szPhoneNumber, phoneNum, sizeof(phoneNum));
					sendLog(LOG_OPER_SMS, (char *)&strulog);
					resumeDial();
					//realMobileStat.enableConnect = 1;
				}
				else if(0 == strncmp((char *)msg, "off", 3) || 0 == strncmp((char *)msg, "OFF", 3))
				{
					SET_DIAL_STAT(shareMemParam->realMobileStat.dialProcessStat, DIAL_STOP_DIAL);
					LTE4G_DEBUG(DEBUG_INFO, "telephone %d(%s) set pppd close\n", i, phoneNum);
					//pauseDial();
					LOG_SMS strulog;
					bzero((char *)&strulog, sizeof(LOG_SMS));
					strulog.byOnOff = 0;
					memcpy(strulog.szPhoneNumber, phoneNum, sizeof(phoneNum));
					sendLog(LOG_OPER_SMS, (char *)&strulog);
					if (getDialStatus())
					{
#if 0
						if (modemMode == MODE_TDSCDMA)
						{
							shareMemParam->initFinish = 0;
							/* TD EM560 ģ����Ҫ����ģ����ܱ�֤�Ժ󲦺ųɹ� */
							startDiscon(1);
						}
						else
						{
#endif
					
						/* ��tdģ����������ģ�� */
						shareMemParam->manualPause = 1;
						if (shareMemParam->iModel == M_LC5740 || shareMemParam->iModel == M_LC5731 
						|| shareMemParam->iModel == M_U6100)
						{   /* LEADCORE */
							add_atcmd_buff("AT+CGACT=0,1");
							usleep(300 * 1000);
							add_atcmd_buff("AT+CGATT=0");
							usleep(300 * 1000);
						}
						else if (getModemModel(shareMemParam->szModemName) != M_EM770W)
						//if (strstr(shareMemParam->szModemName, "EM770W") == NULL)
						{
							add_atcmd_buff("AT+CFUN=0");
							add_atcmd_buff("AT+CFUN=1");
							sleep(1);
						}
						pauseDial();
					}
				}
				else if((0 == strncmp((char *)msg, "arm", 3)) || (0 == strncmp((char *)msg, "ARM", 3)))
				{
					// ���벼��״̬
					shareMemParam->sms_cmd= SMS_CMD_ARM;
				}
				else if((0 == strncmp((char *)msg, "disarm", 6)) || (0 == strncmp((char *)msg, "DISARM", 6)))
				{
					// ���볷��״̬
					shareMemParam->sms_cmd = SMS_CMD_DISARM;
				}
				else
				{
					LTE4G_DEBUG(DEBUG_INFO, "unKnown msg received(%s)\n", msg);
				}
#endif
				break;
			}
		}
	}


#if 0
	if (index >= MAX_SMSLIST_NUM)	/* define MAX_SMSLIST_NUM	10 */
	{
		LTE4G_DEBUG(RT_ERROR, "clean all SMS\n", msg);
		writeline(atFd, "AT+CMGD=0,4");	/* clean all SMS */
		writeline(atFd, "AT+CMGD=10");
	}
#endif
	return OK;
}

/**@brief        ���д���
 * @param[in]    line:�������Ĵ�
 * @param[out]   ��
 * @return       ��
 */
static void ATReceiveACall(const char* line)
{
	const char* p1 = NULL;
	const char* p2 = NULL;
	char phoneNum[32];
	int i = 0;

	if(NULL == line)
	{
		return ;
	}
	
	memset(phoneNum, 0, sizeof(phoneNum));
	p1 = line;

	/*<CR><LF>+CLIP:<number>,<type>,,,,<CLI validity><CR><LF>*/
	p1 += strlen("+CLIP:");
	if (isspace((int) *p1))
	{
		p1++;
	}
	p2 =  strstr(p1, ",");
	if(strstr(p1, "\"") != NULL)
	{
		p1 += 1;    /* ȥ��ǰ��һ��˫���� */
		p2 -= 1;    /* ȥ������һ��˫���� */
	}
	strncpy(phoneNum, p1, p2-p1);
	LTE4G_DEBUG(DEBUG_INFO, "recv a call from %s\n", phoneNum);

	/*ƥ����Ϣ*/
	for(i = 0; i < MAX_WHITELIST_NUM; i++)
	{
		LTE4G_DEBUG(DEBUG_INFO, "phone %d: 0x%x\n", i, shareMemParam->cellNumber[i].iPhoneCfg);
		if(isPhoneNumSame((char *)phoneNum, (char *)(shareMemParam->cellNumber[i].byWhiteList))
			&& (shareMemParam->cellNumber[i].iPhoneCfg & (1 << PHONECFG_CALL_CONTROL))  /* �������п��� */
			)
		{
			LTE4G_DEBUG(DEBUG_INFO, "telephone %d(%s) set pppd open\n", i, phoneNum);
			LOG_CALL strulog;
			bzero((char *)&strulog, sizeof(LOG_CALL));
			memcpy(strulog.szPhoneNumber, phoneNum, sizeof(phoneNum));
			sendLog(LOG_OPER_CALL, (char *)&strulog);
			resumeDial();
			break;
		}
	}
}

/**@brief        ����ģʽ����
 * @param[in]    line:�������Ĵ�
 * @param[out]   ��
 * @return       ��
 */
static void ATReceiveMode(const char* line)
{
	char* p = NULL;

	if(NULL == line)
	{
		return;
	}

	
#if 0		//�ⲿ�ִ�������е�ǰ����ģʽ�ܻ��ң��Ȳ���
	if ((p = strstr(line, "^MODE:")) == NULL)
	{
		p = strstr(line, "%MODE:");
	}
	if(p != NULL)
	{
		p = p + 6;
		if (isspace((int) *(p + 6))) 
		{
			p++;
		}
		if ((modemMode == MODE_EVDO) || (modemMode == MODE_TDSCDMA))
		{
			realMobileStat.mode = atoi(p);
			shareMemParam->realMobileStat.mode = realMobileStat.mode;
		}
		else if (modemMode == MODE_WCDMA)
		{
			sscanf(p, "%d,%d", &(realMobileStat.mode), &(realMobileStat.subMode));
			shareMemParam->realMobileStat.mode = realMobileStat.mode;
			shareMemParam->realMobileStat.subMode = realMobileStat.subMode;
		}
	}
#endif
}

/**@brief        �����ϱ�����Ϣ
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
static void ATReceiveFilter(void)
{
	return;
}

/****************************************
    Function:     // ATReceiveSYSINFO
    Description:  // ��ȡģ��ĵ�ǰ��Ϣ
    Input:        // line: ��Ҫ�������ַ���
    Output:       // NULL
    Return:       // NULL
****************************************/

static void ATReceivePSRAT(const char* line)
{
	if(NULL == line)
	{
		return;
	}
	serviceExist = getPsPart(line);
	return;
}


/**@brief        ϵͳ��Ϣ����
 * @param[in]    line:�������Ĵ�
 * @param[out]   ��
 * @return       ��
 */
static void ATReceiveSYSINFO(const char* line)
{
	if(NULL == line)
	{
		return;
	}
	serviceExist = getSysinfo(line);
	return;
}

/**@brief        ������������
 * @param[in]    line:�������Ĵ�
 * @param[out]   ��
 * @return       ��
 */
static void ATReceiveCSQ(const char* line)
{
	if(NULL == line)
	{
		return;
	}
	signalExist = getRSSI(line);
	return;
}

/**@brief        ģ�����ģʽ��Ϣ����
 * @param[in]    line:�������Ĵ�
 * @param[out]   ��
 * @return       ��
 */
static void ATReceiveCFUN(const char*line)
{
	char* p = NULL;

	if(NULL == line)
	{
		return;
	}

	p = strstr(line, "+CFUN:");
	if(p != NULL)
	{
		p = p + 6;
		if (isspace((int) *(p))) 
		{
			p++;
		}
		shareMemParam->realMobileStat.operMode = atoi(p);
	}
}

/**@brief        ��������Ϣ����
 * @param[in]    line:�������Ĵ�
 * @param[out]   ��
 * @return       ��
 */
static void ATReceiveCOPS(const char*line)
{
	const char* p = NULL, *q = NULL, *pend = NULL;
	int i = 0, j = 0;
	int format = -1;

	if(NULL == line)
	{
		return;
	}

	p = line;
	
	//SIMCOM
	//+COPN: "46001"," China Unicom"

	if ((strstr(p, "(") == NULL) && (strstr(p, ",,") == NULL))	/* return the current network information by READ commad */
	{
		//+COPS: 0,0,"CHINA  MOBILE",7
		/* +COPS: 1,2,"46000",0
		     +COPS: 1,0,"CHINA MOBILE",0
		     +COPS: <mode>[,<format>,<oper>[,<rat>]] */
		if ((p = strstr(p, ",")) != NULL)
		{
			memset(&curCopsInfo, 0, sizeof(COPS_INFO));
			format = atoi(p + 1);		/* format */
			p = strstr(p, "\"");
			if (p == NULL)
			{
				return;
			}
			q = strstr(p + 1, "\"");
			if (q == NULL)
			{
				return;
			}
			if (format == 0)			/* l_alpha <oper> */
			{
				strncpy((char *)(curCopsInfo.l_alpha_oper), p + 1, q - p -1);
			}
			else if (format == 2)		/* num <oper> */
			{
				strncpy((char *)(curCopsInfo.num_oper), p + 1, q - p -1);
			}
			else						/* s_alpha <oper> */
			{
				strncpy((char *)(curCopsInfo.s_alpha_oper), p + 1, q - p -1);
			}

			if ((p = strstr(q, ",")) != NULL)		/* rat */
			{
				curCopsInfo.rat = atoi(p + 1);
			}
		}
	}
	else						/* return the exists networks information by TEST commad */
	{
		/* +COPS: (1,"CHINA MOBILE","","46000",0)
		     +COPS: (<stat>, l_alpha <oper>, s_alpha <oper>, num <oper>[,<rat>]) */
		pend = strstr(p, ",,");
		while (((p = strstr(p, "(")) != NULL) && i < COPS_MAX_NETWORKS)
		{
			if ((pend != NULL) && (p > pend))
			{
				break;
			}
			copsInfo[i].stat = atoi(p + 1);				/* stat */
			
			if(!(p = strstr(p, "\"")))
				return;
			if(!(q = strstr(p + 1, "\"")))
				return;
			strncpy((char *)(copsInfo[i].l_alpha_oper), p + 1, q -p -1);
			copsInfo[i].l_alpha_oper[q -p -1] = '\0';		/* l_alpha <oper> */
			
			if(!(p = strstr(q + 1, "\"")))
				return;
			if(!(q = strstr(p + 1, "\"")))
				return;
			strncpy((char *)(copsInfo[i].s_alpha_oper), p + 1, q -p -1);
			copsInfo[i].s_alpha_oper[q -p -1] = '\0';	/* s_alpha <oper> */
			
			if(!(p = strstr(q + 1, "\"")))
				return;
			if(!(q = strstr(p + 1, "\"")))
				return;
			strncpy((char *)(copsInfo[i].num_oper), p + 1, q -p -1);
			copsInfo[i].num_oper[q -p -1] = '\0';		/* num <oper> */
			
			if (strstr(q, ",") != NULL)
			{
				copsInfo[i].rat = atoi(q + 2);				/* rat */
			}

			i++;
			p = q + 2;
		}
	}

	for (j = 0; j < i; j++)
	{
		LTE4G_DEBUG(DEBUG_INFO, "\t%d\t%s\t%s\t%s\t%d\n",
			copsInfo[j].stat, copsInfo[j].l_alpha_oper, copsInfo[j].s_alpha_oper,
			copsInfo[j].num_oper, copsInfo[j].rat);
	}
	return;
}

/**@brief        ����ע����Ϣ����
 * @param[in]    line:�������Ĵ�
 * @param[out]   ��
 * @return       ��
 */
static void ATReceiveCREG(const char* line)
{
	char* p = NULL;
	UINT32 regInfo = 0;

	if(NULL == line)
	{
		return;
	}

	if ((p = strstr(line, ",")) == NULL)		/* return of read commad: "+CREG: 1,1" */
	{
		if((p = strstr(line, ":")) == NULL)	/* auto report: "+CREG: 1" */
			return; 
	}
	
	if (isspace((int) *(++p))) 
	{
		p++;
	}

	regInfo = atoi(p);
	
	if ((p = strstr(line, "+CREG:")) != NULL)		//CREG:3Gע����Ϣ
	{ 
		mobile_reg3gInfo = regInfo;
	}
	else if((p = strstr(line, "+CGREG:")) != NULL)	//CGREG:2Gע����Ϣ
	{ 
		mobile_reg2gInfo = regInfo; 
	}
	else		//CEREG:4Gע����Ϣ
	{
		mobile_reg4gInfo = regInfo;
	}
	

	// ϵͳ����״̬
	mobile_regStat = regInfo;  
	 		
	if (regInfo > 0 && regInfo < 6)       /* ��⵽״̬Ϊ�޷���״̬ */
	{
		signalExist = TRUE;
	}
	else
	{
		signalExist = FALSE;
	}
	
	return;
}


/**@brief        readerLoop����һ��AT��Ϣ,�Ȳ����¶���Ҳ��������,�ڸú�������ǲ�������ָ��ķ���,�����,
 *               �ú�������Щ���طŵ�һ����ʱ����,�ȴ���ȡ(�μ�waitATResponse).������֮.
 * @param[in]    content:��������Ϣ����
 * @param[out]   ��
 * @return       ��
 */
static void ATRecvOtherResponse(const char *content)
{
	if(NULL == content)
	{
		return ;
	}

	pthread_mutex_lock(&rilSem);

	if(atResponse.used)       /*�������ڵȽ�AT����*/
	{
		AT_RESPONSE_NODE *tmp = (AT_RESPONSE_NODE *)malloc(sizeof(AT_RESPONSE_NODE));
		if(!tmp)
		{
			pthread_mutex_unlock(&rilSem);
			return;
		}		
		tmp->atResponse = strdup(content);
		lstAdd(&atResponse.atList, &tmp->node);
	}
	pthread_mutex_unlock(&rilSem);
	return;
}

/**@brief        ��ȡģ������
 * @param[in]    ��
 * @param[out]   modemName:ģ������
 * @return       OK:0,ERROR:-1
 */
static STATUS getModemName(char * modemName)
{
#ifdef LAST_RESP
	int defaultCid = 2;
	char response[128];
	const char *modName = NULL;
	PHONE_FUNCTION phone_function = CFUN_ONLINE_MODE;
	CHIP_ERROR_OUTPUT_LEVEL level = CHIP_ERROR_NUMERIC;

	if(NULL == modemName)
	{
		LTE4G_DEBUG(RT_ERROR, "getModemName: input NULL\n");
		return ERROR;
	}

	memset(response, 0, sizeof(response));
	
	(void)mobile_AT_set_chip_error_level(&level, NULL);
	(void)mobile_AT_set_phone_function(&phone_function, NULL);
	
	lastRsp.bEnable = 1;
	
	/*��ѯ�豸оƬ���ͺ�*/
	if (OK == mobile_AT_get_chip_type(NULL, response))
	{
		lastRsp.bEnable = 0;
		modName = getModType(response);
		mobile_log_write("modName : %s\n", modName);
		
		memset(modemName, 0, 32);

		if(0 == strcmp(modName,"HSPA USB MODEM"))
		{
			strcpy(modemName,"U7500");	// U7500���ص��ͺ�ΪHSPA USB MODEM
			defaultCid = 2;
		}
		else if(0 == strcmp(modName,"EVDO USB MODEM"))	//C5300����Ҳ��"EVDO USB MODEM"�������Ƚ�ģ�����ó�C7500�������������ټ���
		{
			strcpy(modemName,"C7500");	// C7500���ص��ͺ�ΪEVDO USB MODEM
			defaultCid = 2;
		}
		else if(0 == strncmp(modName,"LTE Hotspot", strlen("LTE Hotspot")) 
			||0 == strncmp(modName,"LM9165", strlen("LM9165"))
			||0 == strncmp(modName,"LM9115", strlen("LM9115"))) 
		{
			strcpy(modemName,"LM91XX");
			defaultCid = 2;
		}
		else if(0 == strncmp(modName,"8300W", strlen("8300W"))
			|| 0 == strncmp(modName,"8300C", strlen("8300C"))
			|| 0 == strncmp(modName,"8300", strlen("8300"))
			|| 0 == strncmp(modName,"U8300C", strlen("U8300C"))
			|| 0 == strncmp(modName,"U9300C", strlen("U9300C"))
			|| 0 == strncmp(modName,"U8300W", strlen("U8300W"))
			|| 0 == strncmp(modName,"U8300", strlen("U8300")))
		{
			strcpy(modemName,"U8300");
			defaultCid = 2;
		}
		else if(0 == strncmp(modName, "MU709s-2", strlen("MU709s-2")))		//��Ϊģ��MU709s	
		{
			strcpy(modemName,"HUAWEI_3G");
			defaultCid = 0;
		}
		else if(0 == strncmp(modName, "ME909s-821", strlen("ME909s-821"))
			|| 0 == strncmp(modName, "ME909s-120", strlen("ME909s-120")))  //��Ϊģ��MU909s)	 
		{
			strcpy(modemName,"HUAWEI_4G");
			defaultCid = 0;
		}
		/* Other Huawei Modem
			��Ϊ��ר����APN���ú�ģ���������й�*/
		/* ��˼ƽ̨ME909s ME906s�� */
		else if(strstr(modName, "ME909s") || strstr(modName, "ME906s"))
		{
			defaultCid = 0; 
		}
		/* ��ͨƽ̨ ME909u,ME906E,ME906E�� */
		else if(strstr(modName, "ME909u") || strstr(modName, "ME906E") || strstr(modName, "ME906C"))
		{
			defaultCid = 16;
		}
		/* IMCƽ̨ ME936, ME206V�� */
		else if(strstr(modName, "ME936") || strstr(modName, "ME206V"))
		{
			defaultCid = 11;
		}
		else
		{
			LTE4G_DEBUG(RT_ERROR, "ModName unkown, modName = %s",modName);
			strncpy(modemName, modName, 31);
			shareMemParam->iModel = M_UNKNOWN;
		}
		
		LTE4G_DEBUG(DEBUG_INFO, "modemName = <%s>\n", modemName);

		if ((shareMemParam->iModel = getModemModel(modemName)) != 0)
		{
			sprintf(shareMemParam->szModemName, "%s", modemName);
			memset(response, 0, sizeof(response));
			sprintf(response, "modem type is %s", modemName);
			atPrintf(response);
		}
		pDevDialParam->dialParam.dataCid = defaultCid; //Ĭ�����ݳ��ص�

		LTE4G_DEBUG(RT_ERROR, "iModel defaultDataCid APN cid= <%d>\n", defaultCid);
		
		LTE4G_DEBUG(DEBUG_INFO, "iModel = <%d>\n", shareMemParam->iModel);
		
		return OK;
	}
	else
	{
		lastRsp.bEnable = 0;
	}
	return ERROR;
#endif
}

/**
 *Function: getPsPart
 *Description: getPsPartͨ����ȡline��Ϣ����ʾϵͳ��Ϣ
 *Input: line ��Ҫ�������ַ���
 		 sysmode ���ص��豸��Ϣ
 		 sim sim����Ϣ
 *Return:STATUS
 */
static int getPsPart(const char *line )
{
	if (line == NULL)
	{
		return 0;
	}

	if (strStartsWith(line, "+PSRAT:"))
	{
		if (strstr(line, "NONE"))
		{ 
			mobile_mode = 0;
		}
		else if (strstr(line, "LTE FDD"))
		{
			mobile_mode = MODE_FDDLTE;
		}
		else if (strstr(line, "LTE TDD"))
		{
			mobile_mode = MODE_TDLTE;
		}
		else if (strstr(line, "UMTS"))
		{
			if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator)
			{
				mobile_mode = MODE_TDSCDMA;
			}
			else if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
			{
				mobile_mode = MODE_WCDMA;
			}
			else
			{
				LTE4G_DEBUG(RT_ERROR, "getPsPart: CHINA_TELECOM 3G\n");
			}
		}
		else if (strstr(line, "HSUPA"))
		{
			mobile_mode = MODE_WCDMA;
		}	
		else if (strstr(line, "HSDPA"))
		{
			mobile_mode = MODE_WCDMA;
		}
		else if (strstr(line, "TDSCDMA"))
		{
			mobile_mode = MODE_TDSCDMA;
		}
		else if (strstr(line, "GPRS"))
		{
			mobile_mode = MODE_GPRS;
		}
		else if (strstr(line, "EDGE"))
		{
			mobile_mode = MODE_GPRS;
		} 
	}
	else if (strStartsWith(line, "^HCSQ:"))
	{
		if (strstr(line, "WCDMA"))
		{ 
			mobile_mode = MODE_WCDMA;
			return 0;
		}
	}
    
    if(MODE_NONE == mobile_mode)
        return 0;
    else
        return 1;
}

 
/**@brief        getSysinfoͨ����ȡline��Ϣ����ʾϵͳ��Ϣ
 * @param[in]    line ��Ҫ�������ַ���
 * @param[in]    ��
 * @param[out]   wirelessStat ���ص��豸��Ϣ 
 * @return       TRUE:1,FALSE:0
 */
static STATUS getSysinfo(const char *line )
{
	/*<CR><LF>^SYSINFO:<srv_status>,<srv_domain>,<roam_status>,<sys_mode>,<si
		m_state>[,<lock_state>,<sys_submode>]<CR><LF><CR><LF>OK<CR><LF>*/
	char *p = NULL, *last = NULL;
	int tmp[7];
	int i = 0;

	if (NULL == line)
	{
		LTE4G_DEBUG(RT_ERROR, "getSysinfo line is  NULL\n");
		return FALSE;
	}
	memset(tmp, 0, sizeof(tmp));
	
	if (strStartsWith(line, "^SYSINFO:") ||strStartsWith(line, "%SYSINFO:"))
	{
		if(NULL == (p = strstr(line, ":")))
			return FALSE;
		
		sscanf(p, ":%d,%d,%d,%d,%d", &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4]);
		while (p != NULL)
		{
			i++;
			last = p;
			p++;
			p = strstr(p, ",");
		}
		if (i >5)
		{
			sscanf(last, ",%d", &tmp[6]);
		}		
#if 0			//EVDO chip bug��when using sysinfo command query, the last one can't represent the current status of sim card
		if (255 == tmp[4] && MODE_TDSCDMA == modemMode)		// SIM��״̬��1:��Ч��240:ROMSIM�汾��255:�޿�
		{   /* when EM560(TDSCDMA) is PIN locked, this param value is 255(same as no UIM card).
			So don't update the UIM card status value here on TDSCDMA. the UIM card status
			should be updated by ^CPIN command. Modify 110313.
			*/
			wirelessStat->SIMCard = shareMemParam->realMobileStat.SIMCard;
		}
		else
		{
			wirelessStat->SIMCard = tmp[4];
		}		
		if (wirelessStat->SIMCard == 2 || wirelessStat->SIMCard == 3)
		{
			wirelessStat->SIMCard = 4;  /* all invalid */
		}
#endif
		// Setting the registration status.
		mobile_srvStat = tmp[0]; 

		if (255 == tmp[1])
		{
			mobile_srvDomain = 3;
		}
		else
		{
			mobile_srvDomain = tmp[1];
		}
	 
		if(OPERATOR_CHINA_TELECOM == pDevDialParam->mobile_operator
			|| (M_HUAWEI_3G == shareMemParam->iModel ))
		{
			//when current mobile_operator is Telecom,current mode is only 3 kinds, MODE_EVDO��MODE_FDDLTE��MODE_CDMA1X
			if(4 == tmp[3] ||8 == tmp[3])
			{	
				mobile_mode = MODE_EVDO;
				if(0 == tmp[2])
				{
					mobile_reg3gInfo = CREG_STAT_REGISTED_LOCALNET;
				}
				else
				{
					mobile_reg3gInfo = CREG_STAT_REGISTED_ROAMNET;
				}
			}
			else if(9 == tmp[3])
			{
				mobile_mode = MODE_FDDLTE;
				if(0 == tmp[2])
				{
					mobile_reg4gInfo = CREG_STAT_REGISTED_LOCALNET;
				}
				else
				{
					mobile_reg4gInfo = CREG_STAT_REGISTED_ROAMNET;
				}
			}
			else if(2 == tmp[3])
			{
				mobile_mode = MODE_CDMA1X;
				if(0 == tmp[2])
				{
					mobile_reg2gInfo = CREG_STAT_REGISTED_LOCALNET;
				}
				else
				{
					mobile_reg2gInfo = CREG_STAT_REGISTED_ROAMNET;
				}
			}
			else if(5 == tmp[3])
			{
				mobile_mode = MODE_WCDMA;
			}
			else if(3 == tmp[3])
			{
				mobile_mode = MODE_GPRS;
			}
			else;


			mobile_srvStat = tmp[0]; 

			if (255 == tmp[1])
			{
				mobile_srvDomain = 3;
			}
			else
			{
				mobile_srvDomain = tmp[1];
			}
		}
		else
		{
			mobile_simStat = tmp[4];	

			if(1 == tmp[4])
			{
				mobile_simStat = SIM_VALID;
			}
			else if(255 == tmp[4])
			{
				mobile_simStat = SIM_NOTEXIST;
			}
			else  // ��֪������240 255  ������CPIN����ʹ��
			{
				mobile_simStat = SIM_INVALID;  /* all invalid */
			}
		}
		
		if ((0 == tmp[0])
			|| MODE_NONE == mobile_mode)       /* ��⵽״̬Ϊ�޷���״̬ */
		{
			return FALSE;
		}
	}
	else if(strStartsWith(line, "^SYSINFOEX:"))
	{

		char curr_mode[32];
		memset(curr_mode, 0, sizeof(curr_mode));
		if(!(p = strstr(line, ":")))
			return FALSE;
		sscanf(p, ":%d,%d,%d,%d,,%d,\"%s\"", &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], curr_mode);

		if(M_HUAWEI_4G == shareMemParam->iModel)
		{ 
			mobile_srvStat = tmp[0]; 

			if (255 == tmp[1])
			{
				mobile_srvDomain = 3;
			}
			else
			{
				mobile_srvDomain = tmp[1];
			}
			
			if(1 == tmp[4])
			{
				mobile_mode = MODE_GPRS;
				if(0 == tmp[2])
					mobile_reg2gInfo = CREG_STAT_REGISTED_LOCALNET;
				else
					mobile_reg2gInfo = CREG_STAT_REGISTED_ROAMNET;
			}
			else if(3 == tmp[4])
			{
				mobile_mode = MODE_WCDMA;
				if(0 == tmp[2])
					mobile_reg3gInfo = CREG_STAT_REGISTED_LOCALNET;
				else
					mobile_reg3gInfo = CREG_STAT_REGISTED_ROAMNET;
			}
			else if(4 == tmp[4])
			{
				mobile_mode = MODE_TDSCDMA;
				if(0 == tmp[2])
					mobile_reg3gInfo = CREG_STAT_REGISTED_LOCALNET;
				else
					mobile_reg3gInfo = CREG_STAT_REGISTED_ROAMNET;
			}
			else if(6 == tmp[4])
			{
				if(OPERATOR_CHINA_MOBILE== pDevDialParam->mobile_operator)
					mobile_mode = MODE_TDLTE;
				else if(OPERATOR_CHINA_UNICOM== pDevDialParam->mobile_operator)
					mobile_mode = MODE_FDDLTE;

				if(0 == tmp[2])
					mobile_reg4gInfo = CREG_STAT_REGISTED_LOCALNET;
				else
					mobile_reg4gInfo = CREG_STAT_REGISTED_ROAMNET;
			}
			
			
			if (1 == tmp[3])
			{
				mobile_simStat = SIM_VALID; 
			}
			else if(255 == tmp[3])
			{
				mobile_simStat = SIM_NOTEXIST;  
			}
			else //0  2 3 4 255 
			{
				mobile_simStat = SIM_INVALID;  /* all invalid */
			}
		}
	}


	

	return TRUE;
}

/**@brief        ���ö��ŷ������ĵ�ַ��Ӧ�Ĵ���
 * @param[in]    line ��Ҫ�������ַ���
 * @param[in]    ��
 * @param[out]   ��
 * @return       TRUE:1,FALSE:0
 */
static STATUS getSCA(const char * line)
{
	/*+CSCA: "+8613800571500",145*/
	char *p1 = NULL, *p2 = NULL;

	if(NULL == line)
	{
		return FALSE;
	}
	
	if(strStartsWith(line, "+CSCA:"))
	{
		if(NULL == (p1 = strstr(line, ":")))
			return FALSE;
		if(NULL == (p2 = strstr(p1, ",")))
			return FALSE;
		
		/* ��Щר��Ӧ�����޶��ŷ�����������Ϊ��: +CSCA: "",145
		��SMSCenter���Ϊ'0'*/
		if ((p2-p1) < 5)	
		{
			memset(SMSCenter, '0', 15);
			SMSCenter[15] = 0;
		}
		else
		{
			strncpy(SMSCenter, p1+4, p2-p1-5);
		}
		strncpy((char *)(shareMemParam->SmsCenter), SMSCenter, MIN(strlen(SMSCenter), sizeof(shareMemParam->SmsCenter) - 1));
		LTE4G_DEBUG(DEBUG_INFO, "p1[%s], p2[%s], SCA[%s]\n", p1, p2, SMSCenter);
		return TRUE;
	}
	return FALSE;
}

#ifdef DEBUG
/**@brief        ��ȡģ��APN����
 * @param[in]    line ��Ҫ�������ַ���
 * @param[in]    ��
 * @param[out]   ��
 * @return       ����ģ���ͺŻ�NULL
 */
int mobile_get_curentAPNS(const char* line)
{	
	char *p = NULL;
	BOOL bapn_chg = FALSE;
	char apn0[32];
	char apn1[32];
	char apn2[32];

	char pdp_type[8];

	if(NULL == line)
	{
		LTE4G_DEBUG(RT_ERROR,"input line NULL\n");
		return ERROR;
	}
	memset(apn0, 0, sizeof(apn0));
	memset(apn1, 0, sizeof(apn1));
	memset(apn2, 0, sizeof(apn2));
	memset(pdp_type, 0, sizeof(pdp_type));
	
	//+CGDCONT: 1,"IP","3gnet","0.0.0.0",0,0
	//+CGDCONT: 2,"IP","3gnet","0.0.0.0",0,0
	//pdp X.25 ipv6 OSPIH ppp 3gnet
	if(strStartsWith(line, "+CGDCONT:"))
	{
		if(M_HUAWEI_3G == shareMemParam->iModel
		|| M_HUAWEI_4G == shareMemParam->iModel){

			/* Current only support ME909s-821,data_cid 0 */
			if(NULL == (p = strchr(line, '0'))){
				return FALSE;
			}
			sscanf(p + 2, "\"%s\",\"%s\",", pdp_type, apn0); 
			//sscanf(p + 2,"\"%[A-Za-z.]\",\"%[A-Za-z1-9.]\",", pdp_type, apn0);
		}
		if(NULL == (p = strchr(line, '1'))){
			LTE4G_DEBUG(RT_ERROR,"input line NULL\n");
			return FALSE;
		}
		sscanf(p + 2, "\"%s\",\"%s\",", pdp_type, apn1);
		if(memcmp(pDevDialParam->dialParam.netAPN, apn1, NAME_LEN) != 0){
			bapn_chg = TRUE;
		}
		LTE4G_DEBUG(RT_ERROR, "lt:mobile_get_curentAPNS apn1 conf:%s\n",
					pDevDialParam->dialParam.netAPN);
		LTE4G_DEBUG(RT_ERROR, "lt:mobile_get_curentAPNS apn1:%s\n", apn1);
		
		if (NULL == (p = strchr(line, '2'))){
			return FALSE;
		} 
		sscanf(p + 2, "\"%s\",\"%s\",", pdp_type, apn2);
		if(memcmp(pDevDialParam->dialParam.dataAPN, apn2, NAME_LEN) != 0){
			bapn_chg = TRUE;
		}
		LTE4G_DEBUG(RT_ERROR, "lt:mobile_get_curentAPNS apn2 conf:%s\n",
					pDevDialParam->dialParam.dataAPN);
		LTE4G_DEBUG(RT_ERROR, "lt:mobile_get_curentAPNS apn2:%s\n", apn2);
	}
	return bapn_chg;
}

#endif

/**@brief        ��ȡģ���ͺ�
 * @param[in]    line ��Ҫ�������ַ���
 * @param[in]    ��
 * @param[out]   ��
 * @return       ����ģ���ͺŻ�NULL
 */
const char* getModType(const char * line)
{
	/* +CGMM: ��Щֱ�ӷ���ģ�����ͣ���Щǰ�����"+CGMM" ǰ׺��ȥ��*/
	char *p = NULL;
	int i = 0;

	if(NULL == line)
	{
		LTE4G_DEBUG(RT_ERROR,"getModType: input NULL\n");
		return NULL;
	}

	if(strStartsWith(line, "+CGMM:"))
	{
		if(NULL == (p = strstr(line, ":")))
			return NULL;
		p++;
		for (i =0; isspace((int) *p)&&(i < MAX_AT_RESPONSE); ++i,++p);    /* ���Ͳ���ǰ��Ŀո�*/
		return p;
	}
	return line;
}


/**@brief        ������ǰ�ź�����
 * @param[in]    ԭʼ���ź�����
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��������ź�����
 */
int analysis_signal_strength(int i_signal)
{
	//UINT32 i_signal = 0;
	int ret = -1;
	static UINT32 lastRet = 0;
	UINT32 mode = MODE_NONE;
	
	if (shareMemParam != NULL)
	{
		if(M_HUAWEI_4G == shareMemParam->iModel)
		{
			if(i_signal >= 0 && i_signal <= 31)
					ret = i_signal * 3.5;
			if(99 == i_signal)
				ret = 0;
			ret = (ret > 100) ? 100 : ret;	
		}
		else
		{
			mode = mobile_mode;
			switch(mode)
			{
				case MODE_TDLTE:	
				case MODE_FDDLTE:	// TDLTE,WCDMA: signal qulity by percentile
					if(M_LM91XX == shareMemParam->iModel)
					{
						if ((i_signal < -127) ||(i_signal == 99))
							ret = 0;
						else
							ret = (i_signal + 127) * 2.5;

						if(ret > 100)
							ret = 100;
						break;
					} //����break�����棬���е�ģ���źű�ʾ������һ��
				case MODE_WCDMA:
				case MODE_EVDO:
				case MODE_HYBRID:
				case MODE_CDMA1X:
					if(i_signal >= 0 && i_signal <= 31)
						ret = i_signal * 3.5;
					
					if(99 == i_signal)
						ret = 0;

					ret = (ret > 100) ? 100 : ret;	
					break;
					
				case MODE_TDSCDMA:	// TDSCDMA: signal qulity by percentile
					if((i_signal <= 100) || (199 == i_signal))
						ret = 0;
					else
						ret = (i_signal - 100)*2;

					ret = (ret > 100) ? 100 : ret;	
					break;
		        case MODE_GPRS:
					if ((i_signal < 8) ||(i_signal == 99))
						ret = 0;
					else if (i_signal >= 8 && i_signal < 12)
						ret = 1;
					else if (i_signal >= 12 && i_signal < 18)
						ret = 2;
					else if (i_signal >= 18 && i_signal < 24)
						ret = 3;
					else if (i_signal >= 24 && i_signal < 30)
						ret = 4;
					else if (i_signal >= 30 && i_signal <= 31)
						ret = 5;
					break;
					
				default:
					ret=lastRet;
					break;
			}
		}
	}
	
	lastRet = ret;
	if(-1 == ret)
	{
		ret = 0;
	}
	return ret;
}

/**@brief        ��ȡ�ź�ǿ��
 * @param[in]    line ��Ҫ�������ַ��� 
 * @param[out]   wirelessStat:ģ��״̬
 * @return       FALSE,��ǰ�ź�ǿ��
 */
static STATUS getRSSI(const char * line)
{
	char *p = NULL;
	static int signal = 0;
	int signalCdma = -1, signalEvdo = -1;
	char printfBuf[256];

	if(NULL == line)
	{
		return FALSE;
	}

	memset(printfBuf, 0, sizeof(printfBuf));

	if ( MODE_EVDO == mobile_mode)
	{
		if(strStartsWith(line, "^HDRCSQ:"))
		{
			if(!(p = strstr(line, ":")))
				return FALSE;
			//sscanf(p, ":%d,", &signal);
			signalEvdo = atoi(p + 1);
			sprintf(printfBuf, "HDRCSQ RSSI: %d", signalEvdo);
			atPrintf(printfBuf);
		}
		else if (strStartsWith(line, "^HRSSILVL:"))
		{
			if(!(p = strstr(line, ":")))
				return FALSE;
			signalEvdo = atoi(p + 1);
		}
		
		if(strStartsWith(line, "^CSQLVL:"))
		{
			if(!(p = strstr(line, ":")))
				return FALSE;
			sscanf(p, ":%d,", &signalCdma);
			sprintf(printfBuf, "CSQLVL RSSI: %d", signalCdma);
			atPrintf(printfBuf);
		}
		else if (strStartsWith(line, "^RSSILVL:"))
		{
			if(!(p = strstr(line, ":")))
				return FALSE;
			signalCdma = atoi(p + 1);
		}
		else if(strStartsWith(line, "+CCSQ:"))
		{
			if(!(p = strstr(line, ":")))
				return FALSE;
			sscanf(p, ":%d,", &signalEvdo);
			sprintf(printfBuf, "CCSQ RSSI:  %d", signalEvdo);
			atPrintf(printfBuf);
		}
		else if(strStartsWith(line, "+CSQ:"))
		{
			if(!(p = strstr(line, ":")))
				return FALSE;
			sscanf(p, ":%d,", &signalEvdo);
			sprintf(printfBuf, "CSQ RSSI:  %d", signalEvdo);
			atPrintf(printfBuf);
		}

		if ((mobile_mode != MODE_CDMA1X)
			&& (mobile_mode != MODE_EVDO) 
			&& (mobile_mode != MODE_HYBRID ))
		{
			if (signalCdma != -1)
			{
				signal = signalCdma;
			}
			else if (signalEvdo != -1)
			{
				signal = signalEvdo;
			}
		}
		else if ((MODE_CDMA1X == mobile_mode) && (signalCdma != -1))
		{
			signal = signalCdma;
		}
		else if (((MODE_EVDO == mobile_mode) 
			|| (MODE_HYBRID == mobile_mode)) 
			&& (signalEvdo != -1))
		{
			signal = signalEvdo;
		}
		else if ((signalCdma != -1) || (signalEvdo != -1))  /* BUG: ʵʱ������ʽδ֪���Ҵ�����Ч���ź�ֵ */
		{
			signal = MAX(signalCdma, signalEvdo);
		}
	}
	else
	{
		if(strStartsWith(line, "+CSQ:"))
		{
			if((p = strstr(line, ":")) != NULL)
			{
				sscanf(p, ":%d,", &signal);
				sprintf(printfBuf, "CSQ RSSI:  %d", signal);
				atPrintf(printfBuf);
			}
		}
		else if(strStartsWith(line, "^RSSI:"))
		{
			if((p = strstr(line, ":")) != NULL)
			{
				sscanf(p, ": %d,", &signal);
				sprintf(printfBuf, "RSSI:  %d", signal);
				atPrintf(printfBuf);
			}
		}
	}
 	mobile_signal = analysis_signal_strength(signal);
	return signal;
}

/**@brief        ��ȡģ��ϵͳ��������
 * @param[in]    line ��Ҫ�������ַ���
 * @param[out]   ��
 * @return       FALSE, ��ǰоƬģʽ
 */
static int getSyscfg(const char * line)
{
	char *p = NULL;
	int iMode = -1, iAcc = -1;

	if(NULL == line)
	{
		LTE4G_DEBUG(RT_ERROR,"getSyscfg: input NULL\n");
		return FALSE;
	}

	if ((p = strstr(line, "^DDTM:")) != NULL)
	{   
		if(NULL == (p  = strstr(line, ":")))
			return FALSE;
		if (isspace((int) *(++p))) 
		{
			p++;
		}
			iMode = atoi(p);
		p = strstr(p, ",");
		if (p != NULL)
		{
			iAcc = atoi(++p); 
		}
		
		if (iAcc == 0)
		{
			return SYSCFG_MODE_GSM;
		}
		else if (iAcc == 2)
		{
			return SYSCFG_MODE_TDSCDMA;
		}
		else
		{
			return SYSCFG_MODE_AUTO;
		}
	}
    	else if ((p = strstr(line, "+MODODR:")) != NULL)
    	{
	        if(NULL == (p  = strstr(line, ":")))
			return FALSE;
	        if (isspace((int) *(++p))) 
	    	{
	    		p++;
	    	}
	        iMode = atoi(p);
	        if (iMode == 3)
	        {
	            return SYSCFG_MODE_GSM;
	        }
	        else if (1 == iMode || 7 == iMode)
	        {
	            return SYSCFG_MODE_WCDMA;
	        }
	        else if (6 ==  iMode)
	        {
	            return SYSCFG_MODE_TDSCDMA;
	        }
	        else if (5 == iMode)
	        {     
			if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator)
			{
				return SYSCFG_MODE_TDLTE;
			}
			else
			{
				return SYSCFG_MODE_FDDLTE;
			}
	        }
	        else if(2 == iMode)
	        {   /* == 2 */
	            return SYSCFG_MODE_AUTO;
	        }
		else
		{
			LTE4G_DEBUG(RT_ERROR,"getSyscfg: MODODR ERROR  iMode= %d\n",iMode);
		}
	}
	else if ((p = strstr(line, "+MODODREX:")) != NULL)
    	{
		if(NULL == (p  = strstr(line, ":")))
			return FALSE;
		if (isspace((int) *(++p))) 
		{
			p++;
		}
		iMode = atoi(p);
		if (10 == iMode)
		{
			return SYSCFG_MODE_EVDO;
		}
		else if (1 == iMode || 7 == iMode)
		{
			return SYSCFG_MODE_WCDMA;
		}
		else if (15 == iMode)
		{
			return SYSCFG_MODE_CDMA1X;
		}
		else if (2 == iMode)
		{
			return SYSCFG_MODE_AUTO;
		}
		else if (5 == iMode)
		{     
			if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator)
			{
				return SYSCFG_MODE_TDLTE;
			}
			else
			{
				return SYSCFG_MODE_FDDLTE;
			}
		}
		else if (6 ==  iMode)
	        {
			return SYSCFG_MODE_TDSCDMA;
	        }
		else if(11 == iMode)		//��ͨ�Զ�ģʽ
		{
			return SYSCFG_MODE_AUTO;
		}
		else
		{
			LTE4G_DEBUG(RT_ERROR,"getSyscfg: MODODREX ERROR  iMode= %d\n",iMode);
		}
	}
	else if ((p = strstr(line, "^PREFMODE:")) != NULL)
	{
		if(NULL == (p  = strstr(line, ":")))
			return FALSE;
		if (isspace((int) *(++p))) 
		{
			p++;
		}
		iMode = atoi(p);
		if (8 == iMode)
		{
			return SYSCFG_MODE_AUTO;
		}
		else if (4 == iMode)
		{
			return SYSCFG_MODE_EVDO;
		}
		else if (2 == iMode)
		{
			return SYSCFG_MODE_CDMA1X;
		}
		else
		{
			LTE4G_DEBUG(RT_ERROR,"getSyscfg: MODODREX ERROR  iMode= %d\n",iMode);
		}
	}
	else
	{
		if(NULL == (p  = strstr(line, ":")))
			return FALSE;
		if (isspace((int) *(++p))) 
		{
			p++;
		}

		return(atoi(p));
	}

	return FALSE;
}



/**@brief        the return result of "AT+CMGD" instruct contains the sms information;
                 eg:  +CMGD:(0,2), it means there are 2 sms and theirs index are 0 and 2
                      +CMGD:(0,1,2), means 3 sms, theirs index are 0, 1 and 2
                 	  
				
                 AT+CPMS?
                 +CPMS: "SM",12,50,"SM",12,50,"SM",12,50  �ܿɴ�50�� ����12�� λ��SIM��
 * @param[in]    line ��Ҫ�������ַ���
 * @param[out]   ��
 * @return       the number of sms in the specified storage
 */

static UINT64 getSMSExist(const char * line)
{
	/*  format:
		+CMGD: <index>s[,<delflag>s)]
		+CMGD:(0,2) 
		+CMGD: (1-5),(0-4)
		+CMGD: (0,1,2,3,4,5,6,7,8,9,10,11),(0-4)
	*/
	
	char *p = NULL, *q = NULL;
	char *comma = NULL, *dash = NULL;
	UINT64 ret = 0;
	UINT8 smsIndex = 0, indexEnd = 0;
	int i = 0;

	if(NULL == line)
	{
		LTE4G_DEBUG(RT_ERROR, "getSMSExist: input NULL\n");
		return FALSE;
	}

	p = strchr(line, '(');
	q = strchr(line, ')');
	if (p != NULL && q != NULL)
	{
		if (1 == (q - p))
		{
			return ret;
		}
		while (p != NULL)
		{
			p++;
			smsIndex = atoi(p);
			if (smsIndex < sizeof(ret) * 8)	/* support max index: 63,  */
			{
				ret |= (1 << smsIndex);
			}
			
			if ((dash = strchr(p, '-')) != NULL)
			{
				if (dash > q)
				{
					dash = NULL;
				}
			}
			if ((comma = strchr(p, ',')) != NULL)
			{
				if (comma > q)
				{
					comma = NULL;
				}
			}
			if (dash != NULL)	/* '-' */
			{
				if (((comma != NULL) && (comma > dash))	/* +CMGD: (1-2, 7) */
					|| NULL == comma)				/* +CMGD: (1-2) */
				{
					dash++;
					indexEnd = atoi(dash);
					indexEnd = MIN(64, indexEnd);
					for (i = (smsIndex + 1); i < indexEnd; i++)
					{
						ret |= (1 << i);
					}
				}
			}
			p = comma;
		}
	}
	return ret;
}


/**@brief        if the S/UIM card need PIN code verification, users can input pin/puk code to unlock it;
                 the time interval of pin code query should been shorten to 1 second
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
void pinInit(void)
{
	char response[128];
	char command[128];
	int ret = ERROR;
	int i = 0;
	UINT32 iLastTime = 0;
	char at_cmd[32];
	char at_rsp[16];
	ECHO_STATUS echo_status = ECHO_CLOSE;
	RENEW_PINCODE renew_pincode;

	memset(response, 0, sizeof(response));
	memset(command, 0, sizeof(command));
	memset(at_cmd, 0, sizeof(at_cmd));
	memset(at_rsp, 0, sizeof(at_rsp));
	memset(&renew_pincode, 0, sizeof(renew_pincode));
	
	LTE4G_DEBUG(DEBUG_INFO, "pinInit enter\n");

	for (i = 0; i < 3; i++)
	{
		/*��ѯsim���Ƿ�������״̬*/
		ret = mobile_AT_check_sim_isLock(NULL, response);
		if (OK == ret)
		{
			shareMemParam->pinInfo.pinLockStatus = getPinLockStatus(response);
			mobile_simStat = SIM_VALID;
			break;
		}		
		else if ((SIM_NOT_INSERTED == ret) || (SIM_FAILURE == ret)) /* AT Command return: "CME ERROR: SIM not inserted" or "CME ERROR: SIM failure" */
		{
			mobile_simStat = SIM_NOTEXIST;
			LTE4G_DEBUG(RT_ERROR, "UIM/SIM Card is Not exist!\n");
			sleep(3);		// Dim not be recognized, sleep for a while,waiting for next recognition.
		}
		else if ((SIM_PIN_REQUIRED == ret) || (SIM_PUK_REQUIRED == ret))  /* AT Command return: "CME ERROR: SIM PIN required" or "CME ERROR: SIM PUK required" */
		{
			break;
		}
		else if (SIM_BUSY == ret)    /* SIM busy, wait for a moment */
		{
			sleep(3);
		}
	}
	
	if(SIM_BUSY == ret)
	{
		LTE4G_DEBUG(RT_ERROR, "pinInit SIM BUSY!\n");
		mobile_AT_reset_module(NULL, NULL);
		dial_error_occur(EXIT_DIAL_MODULERESET);
	}

	if(3 == i)
	{
		if ((SIM_NOT_INSERTED == ret) || (SIM_FAILURE == ret))
		{
			LTE4G_DEBUG(RT_ERROR, "Final UIM/SIM Card is Not exist!\n");
			dial_error_occur(EXIT_DIAL_FATALERR);
		}
	}
	
	LTE4G_DEBUG(DEBUG_INFO, "pinInit: get pinInfo\n");
	/* ��λ�ȡPIN ��Ϣ�������������ȡPIN��Ϣʧ�ܾ�û�б�Ҫ��ִ����ȥ��
	������ĳЩģ����ܻ᲻֧��PIN�������ܣ������ڶ�γ��Ի�ȡʧ�ܺ��˳���
	����ִ��������ʼ��*/
	for (i = 0; i < 20; i++)	
	{
		memset(response, 0, sizeof(response));
		if (OK == (ret = mobile_AT_get_sim_status(NULL, response)))
		{
			getPinInfo(response);
			if (OK == mobile_AT_get_pin_puk_times(NULL, response))	// ��ѯ��ǰsim��pin/puk���ʣ�����
 	            	{   
 	                	(void)getPinTimes(response);	/* LONGCHEER */
 	            	} 
			break;
		}

		if ((SIM_NOT_INSERTED == ret) || (SIM_FAILURE == ret)) /* AT Command return: "CME ERROR: SIM not inserted" or "CME ERROR: SIM failure" */
		{
			mobile_simStat = SIM_NOTEXIST;
			LTE4G_DEBUG(RT_ERROR, "pinInit: UIM/SIM Card is Not exist!\n");
			dial_error_occur(EXIT_DIAL_FATALERR);
		}
		else
		{
			usleep(100 * 1000);
			continue;
		}
	}

	if (20 == i)
	{
		LTE4G_DEBUG(DEBUG_INFO, "pinInit: get pinInfo failded\n");
		return;
	}

	/* ����+CLCK��^CPIN��֤����һ���Ѿ����� */
	mobile_simStat = SIM_VALID;
	while (shareMemParam->pinInfo.pinStatus != CPIN_READY)		//sim������
	{
		while ((strlen((char *)(shareMemParam->pinInfo.pin)) == 0 && 
		(shareMemParam->pinInfo.pinStatus == CPIN_PIN || shareMemParam->pinInfo.pinStatus == CPIN_PIN2))
		|| (strlen((char *)(shareMemParam->pinInfo.puk)) == 0 && 
		(shareMemParam->pinInfo.pinStatus == CPIN_PUK || shareMemParam->pinInfo.pinStatus == CPIN_PUK2)))
		{
			/* ��û��SDK��˵�������£���������ʾ�û�����PIN/PUK����Ϣ */
			if (abs(time(NULL) - iLastTime) >= 30)
			{
				LTE4G_DEBUG(DEBUG_INFO, "########################################\n");
				switch (shareMemParam->pinInfo.pinStatus)
				{
				case CPIN_PIN:
					LTE4G_DEBUG(DEBUG_INFO, "Please Input PIN Code Follow the Following \
						Format:\nsendATCom PIN:1234\t\\* 1234 is the pin code*\\\n");
					break;
				case CPIN_PUK:
					LTE4G_DEBUG(DEBUG_INFO, "Please Input PUK Code Follow the Following \
						Format:\nsendATCom PUK:55667788:1234\t\\* 55667788 is the puk code, \
						12\34 is the new pin code *\\\n");
					break;
				case CPIN_PIN2:
					LTE4G_DEBUG(DEBUG_INFO, "Please Input PIN2 Code Follow the Following \
						Format:\nsendATCom PIN2:1234\t\\* 1234 is the pin2 code *\\\n");
					break;
				case CPIN_PUK2:
					LTE4G_DEBUG(DEBUG_INFO, "Please Input PUK2 Code Follow the Following \
						Format:\nsendATCom PUK2:55667788:1234\t\\* 55667788 is the puk code, \
						1234 is the new pin code *\\\n");
					break;
				default:
					break;
				}
				LTE4G_DEBUG(DEBUG_INFO, "########################################\n");
				iLastTime = time(NULL);
			}

			// ��������ʱ��Ҫ��������PIN����н���������
			if (OK == mobile_AT_get_sim_status(NULL, response))
			{
				/* LEADCORE */
				getPinInfo(response);
			}
			usleep(200*1000);
		}

		mobile_AT_set_echo_status(&echo_status, NULL);
		ret = 0;
		if (((CPIN_PIN == shareMemParam->pinInfo.pinStatus) || (CPIN_PIN2 == shareMemParam->pinInfo.pinStatus))
		&& strlen((char *)(shareMemParam->pinInfo.pin)) != 0)
		{
			if(OK == mobile_AT_unlock_pincode(shareMemParam->pinInfo.pin, NULL))
			{
				ret = 1;
				LTE4G_DEBUG(DEBUG_INFO, "mobile_AT_unlock_pincode ok\n");
			}
			memset(shareMemParam->pinInfo.pin, 0 ,sizeof(shareMemParam->pinInfo.pin));
		}
		else if (((CPIN_PUK == shareMemParam->pinInfo.pinStatus) || (CPIN_PUK2 == shareMemParam->pinInfo.pinStatus))
		&& strlen((char *)(shareMemParam->pinInfo.puk)) != 0)
		{
			memcpy(renew_pincode.oldcode, shareMemParam->pinInfo.puk, strlen((char*)shareMemParam->pinInfo.puk));
			memcpy(renew_pincode.newcode, shareMemParam->pinInfo.newPin, strlen((char*)shareMemParam->pinInfo.newPin));
			if(OK == mobile_AT_set_new_pincode(&renew_pincode, NULL))
			{
				ret = 1;
				LTE4G_DEBUG(DEBUG_INFO, "mobile_AT_set_new_pincode ok\n");
			}
			memset(shareMemParam->pinInfo.puk, 0 ,sizeof(shareMemParam->pinInfo.puk));
			memset(shareMemParam->pinInfo.newPin, 0 ,sizeof(shareMemParam->pinInfo.newPin));
		}
		
		if (ret != 0)	//��������ɹ��͸��µ�ǰsim/uim��Ϣ
		{
			
			shareMemParam->curCommRet = ret;
			memset(command, 0, sizeof(command));
			memset(response, 0, sizeof(response));
			
			if (OK == mobile_AT_get_sim_status(NULL, response))
			{
				getPinInfo(response);
				if (OK == mobile_AT_get_pin_puk_times(NULL, response))	// ��ѯ��ǰsim��pin/puk���ʣ�����
	 	            	{   
	 	                	(void)getPinTimes(response);	/* LONGCHEER */
	 	            	} 
				break;
			}

			//�ٴβ�ѯ��ǰsim�Ƿ��Ѿ�����
			memset(response, 0, sizeof(response));
			if (OK == mobile_AT_get_sim_status(NULL, response))
			{
				shareMemParam->pinInfo.pinLockStatus = getPinLockStatus(response);
			}
		}
		
		/* if pin is set, need wait some time for the wireless modem to wake up */
		for (i = 0; i < 15; i++)
		{
			usleep(200*1000);
			atcmd_snd_other();
		}
	}

	if(shareMemParam->iModel != M_C7500)
	{
		mobile_AT_get_3G_status(NULL, NULL);
		if(is_4G_chip_module())
		{
			mobile_AT_get_4G_status(NULL, NULL);
		}
	}
	
	return;
}


/**@brief        ��ȡPIN��PUK���ʣ���������
 * @param[in]    ��
 * @param[out]   ��
 * @return       OK-�ɹ�,ERROR-ʧ��
 */
static int getPinInfo_PinAndPuk_times()
{
	INT8 response[128] = {0};
	UINT32 tmp[4] = {0};

	if(OK == writeATCommand(atFd, "AT+CPNNUM", "PIN", response, 128, TRUE, 3000))
	{
		if(strlen(response) > 0)
		{			
			sscanf(response,"PIN1=%d; PUK1=%d; PIN2=%d; PUK2=%d", &tmp[0], &tmp[1], &tmp[2], &tmp[3]);
			shareMemParam->pinInfo.pinTimes = tmp[0];
			shareMemParam->pinInfo.pukTimes= tmp[1];
			shareMemParam->pinInfo.pin2Times= tmp[2];
			shareMemParam->pinInfo.puk2Times= tmp[3];
		}
		return OK;
	}
	return ERROR;
}



/**@brief        get the pin information;
 * @param[in]    line:the AT instruct return result
 * @param[out]   ��
 * @return       OK-�ɹ�,ERROR-ʧ��
 */
static int getPinInfo(const char * line)
{
	/* <CR><LF>^CPIN:<code>,[<times>],<puk_times>,<pin_times>,<puk2_times>,<pin2_times><CR><LF><CR><LF>OK<CR><LF> */
	char *p = NULL;
	UINT32 tmp[4] = {0};
	if ((strStartsWith(line, "^CPIN:")) ||(strStartsWith(line, "%CPIN:")))
	{
		if(NULL == (p = strstr(line, ":")))
			return ERROR;
		p++;
		if (strstr(p, "READY") != NULL)		/* <code> */
		{
			shareMemParam->pinInfo.pinStatus = CPIN_READY;
		}
		else if (strstr(p, "SIM PIN") != NULL)
		{
			shareMemParam->pinInfo.pinStatus = CPIN_PIN;
		}
		else if (strstr(p, "SIM PUK") != NULL)
		{
			shareMemParam->pinInfo.pinStatus = CPIN_PUK;
		}
		else if (strstr(p, "SIM PIN2") != NULL)
		{
			shareMemParam->pinInfo.pinStatus = CPIN_PIN2;
		}
		else if (strstr(p, "SIM PUK2") != NULL)
		{
			shareMemParam->pinInfo.pinStatus = CPIN_PUK2;
		}

		if(!(p = strstr(line, ",")))
			return ERROR;
		if (*(++p) != ',')
		{
			shareMemParam->pinInfo.times = atoi(p);	/* [<times>] */
			if(!(p = strstr(p, ",")))
				return ERROR;
		}

		sscanf(p, ",%d,%d,%d,%d", &tmp[0], &tmp[1], &tmp[2], &tmp[3]);
		shareMemParam->pinInfo.pukTimes = (UINT8)tmp[0];		/* <puk_times> */
		shareMemParam->pinInfo.pinTimes = (UINT8)tmp[1];		/* <pin_times> */
		shareMemParam->pinInfo.puk2Times = (UINT8)tmp[2];		/* <puk2_times> */
		shareMemParam->pinInfo.pin2Times = (UINT8)tmp[3];		/* <pin2_times> */

		return TRUE;

	}
	else if (strStartsWith(line, "+CPIN:") ||strStartsWith(line, "+QCPIN:"))
	{   /* <CR><LF>+CPIN:<code><CR><LF><CR><LF>OK<CR><LF> */
		if(!(p = strstr(line, ":")))
			return ERROR;
		p++;
		if (strstr(p, "READY") != NULL)		/* <code> */
		{
			shareMemParam->pinInfo.pinStatus = CPIN_READY;
		}
		else if (strstr(p, "SIM PIN") != NULL)
		{
			shareMemParam->pinInfo.pinStatus = CPIN_PIN;
		}
		else if (strstr(p, "SIM PUK") != NULL)
		{
			shareMemParam->pinInfo.pinStatus = CPIN_PUK;
		}
		else if (strstr(p, "SIM PIN2") != NULL)
		{
			shareMemParam->pinInfo.pinStatus = CPIN_PIN2;
		}
		else if (strstr(p, "SIM PUK2") != NULL)
		{
			shareMemParam->pinInfo.pinStatus = CPIN_PUK2;
		}

		//������ֵ�ǰsim״̬���ԣ���Ҫ����״̬
		if(shareMemParam->pinInfo.pinStatus != CPIN_READY)
		{
			(void)mobile_AT_get_network_sysinfo(NULL, NULL);
		}
		
		return TRUE;
	}
	
	return FALSE;
}


/**@brief         returns the remaining number of attempt for each PIN code;
 * @param[in]     line:the AT instruct return result
 * @param[out]    ��
 * @return        TRUE ,FALSE
 */
static int getPinTimes(const char * line)
{
	char *p = NULL;
	UINT32 tmp[4] = {0};

	if(NULL == line)
	{
		return FALSE;
	}

	/* ^DRAP: <pin1>,<pin2>,<puk1>,<puk2> */
	if (strStartsWith(line, "^DRAP:"))
	{
		if(NULL == (p = strstr(line, ":")))
			return FALSE;
		if (isspace((int) *(++p)))
		{
			p++;
		}
		sscanf(p, "%d,%d,%d,%d", &tmp[0], &tmp[1], &tmp[2], &tmp[3]);        
		shareMemParam->pinInfo.pinTimes = (UINT8)tmp[0];		/* <puk_times> */
		shareMemParam->pinInfo.pin2Times = (UINT8)tmp[1];		/* <pin_times> */
		shareMemParam->pinInfo.pukTimes = (UINT8)tmp[2];	/* <puk2_times> */
		shareMemParam->pinInfo.puk2Times = (UINT8)tmp[3];	/* <pin2_times> */
		shareMemParam->pinInfo.times = (UINT8)tmp[0];	/* [<times>] */

		return TRUE;
	}
	else if(strStartsWith(line,"PIN1"))
	{
		/* U8300 U6100 PIN���ʽΪPIN1=3; PUK1=10; PIN2=3; PUK2=10*/
		sscanf(line,"PIN1=%d; PUK1=%d; PIN2=%d; PUK2=%d", &tmp[0], &tmp[1], &tmp[2], &tmp[3]);
		shareMemParam->pinInfo.pinTimes = tmp[0];
		shareMemParam->pinInfo.pukTimes= tmp[1];
		shareMemParam->pinInfo.pin2Times= tmp[2];
		shareMemParam->pinInfo.puk2Times= tmp[3];
			
		return TRUE;
	}
	else if(strStartsWith(line,"^CPIN:"))	//��Ϊģ�鷵�ظ�ʽ
	{
		sscanf(line,"^CPIN: READY,,%d,%d,%d,%d", &tmp[0], &tmp[1], &tmp[2], &tmp[3]);
		shareMemParam->pinInfo.pinTimes = tmp[0];
		shareMemParam->pinInfo.pukTimes= tmp[1];
		shareMemParam->pinInfo.pin2Times= tmp[2];
		shareMemParam->pinInfo.puk2Times= tmp[3];
		return TRUE;
	}
	else;
	
	return FALSE;
}


/**@brief         get whether PIN has been locked
 * @param[in]     line:the AT instruct return result
 * @param[out]    ��
 * @return        OK-�ɹ�,ERROR-ʧ��
 */
static int getPinLockStatus(const char * line)
{
	char *p = NULL;

	if(NULL == line)
	{
		return ERROR;
	}	

	if(strStartsWith(line, "+CLCK:"))
	{
		if(NULL == (p = strstr(line, ":")))
			return ERROR;
		if (isspace((int) *(++p))) 
		{
			p++;
		}
		return(atoi(p));
	}
	return ERROR;
}


/**@brief         ���õ�ǰSIM����ģʽ��"ȫ������"��ʾ��SIM�Ĺ�������Ϊ��ǿ��"��С����"��ʾ��SIM���Ĺ�������Ϊ��С
 * @param[in]     ��
 * @param[out]    ��
 * @return        ��
 */
 void funInit(void)
{
	PHONE_FUNCTION phone_function = CFUN_ONLINE_MODE;
	
	/* just useful in WCDMA & TDSCDMA. */
	if(shareMemParam->iModel != M_C7500)	//TeleCom cdma/evdo not support 
	{
		(void)mobile_AT_set_auto_register(NULL, NULL);
	}
	
	//���õ�ǰ�ֻ�MEȫ������
	mobile_AT_set_phone_function(&phone_function, NULL);
	while (1)
	{
		atcmd_snd_other();
		if (OK == mobile_AT_get_phone_function(NULL, NULL))
			usleep(100*1000);
		else
		{
			usleep(100*1000);
			continue;
		}

		/* ����Ϊonline��������Ϊonline */
		if (shareMemParam->realMobileStat.operMode != CFUN_ONLINE_MODE)
		{
			if (OK == mobile_AT_set_phone_function(&phone_function, NULL))
				sleep(3);			/* ģʽ�л�ʱ�� */
		}
		else
			break;
	}

	return;
}


/**@brief         ��ѯϵͳ��Ϣ���������SYSINFO����
 * @param[in]     ��
 * @param[out]    ��
 * @return        ��
 */
void FindSysInfo(void)
{	
	INT8 response[128];
	memset(response, 0, sizeof(response));
	int i = 0;
	int ret = 0;

	// check sim/uim is normal
	ret = mobile_AT_get_sim_status(NULL, response);
	if (ret != OK)
	{
		LTE4G_DEBUG(RT_ERROR, "FindSysInfo: AT+CPIN? status:[%d],UIM/SIM Card is Not exist or wrong!\n",ret);
		mobile_mode = MODE_NONE;
		mobile_signal = 0;

		if(SIM_BUSY == ret)
		{
			mobile_simStat = SIM_INVALID;
			mobile_AT_reset_module(NULL, NULL);
			dial_error_occur(EXIT_DIAL_MODULERESET);
		}
		else /* SIM status abnormal(not insert, wrong or invalid), exit current process*/
		{
			mobile_simStat = SIM_NOTEXIST;
			dial_error_occur(EXIT_DIAL_FATALERR);
			return;
		}
	}
	else
	{		
		mobile_simStat = SIM_VALID;		// SIM����Ч
		// SIM�������ҷ���״̬Ϊ5����Ϊ����״̬
		if(5 == mobile_regStat )
		{	
			//SIM_CUSTOM_ROAMЭ��û�ж�Ӧ����
			mobile_simStat = SIM_ROAM;	/* �Զ���11Ϊ����״̬,�ϳɵ�UIM״̬������ */
		}		
	}	


	if((OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator
		|| OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
		&& shareMemParam->iModel != M_HUAWEI_3G
		&& shareMemParam->iModel != M_HUAWEI_4G)		//��Ϊģ��709sû��psratָ���Ҫ��sysinfoex������
	{
		// �������״̬������״̬��ѯ
		(void)mobile_AT_get_3G_status(NULL, NULL);
		if(is_4G_chip_module())
		{
			(void)mobile_AT_get_4G_status(NULL, NULL);
		}
		
		(void)mobile_AT_get_network_sysinfo(NULL, NULL);
		
		// ϵͳģʽ��ѯ
		for(i = 0; i < 5; i++)
		{
			memset(response, 0, sizeof(response));
			if ((mobile_AT_get_network_service_type(NULL, response)) != OK)	//��ȡ��ǰ�����������
			{
				LTE4G_DEBUG(DEBUG_INFO, "<FindSysInfo> AT+PSRAT error\n");
				LTE4G_DEBUG(RT_ERROR, "FindSysInfo: response:%s\n", response);
				sleep(1);
			}
			else
			{
				usleep(100 * 1000);
				serviceExist = getPsPart(response );
			}

			if(mobile_mode != MODE_NONE)
				break;

			sleep(1);
		}

		//shareMemParam->realMobileStat.mode = shareMemParam->realMobileStat.mode;
	}
	else
	{
		//����ģ��ʶ��Ƚ��������Ӷ�ȡģ��Ĵ���
		for(i = 0; i < 10; i++)
		{
			(void)mobile_AT_get_network_sysinfo(NULL, response);

			if(mobile_mode != MODE_NONE)
				break;

			LTE4G_DEBUG(RT_ERROR, "mobile_AT_get_network_sysinfo: realMobileStat.mode = %d\n",mobile_mode);
			sleep(1);
		}
	}
	
	return;
}


/**@brief        get the SYSINFO information for adaptive wireless modem;
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
void sysinfoInit(void)
{
	int failTimes = 0;
	int i = 0;
	UINT32 otherNetValidService = 0;
	
	/* ��ѯϵͳ��Ϣ  */
	while(1)
	{
		atcmd_snd_other();

		LTE4G_DEBUG(DEBUG_INFO, "get SYSINFO begain\n");
		
		FindSysInfo();

		LTE4G_DEBUG(DEBUG_INFO, "sysinfoInit: fialTimes:[%d] serviceExist = %d\n", failTimes, serviceExist);

		if(serviceExist)
		{
			LTE4G_DEBUG(DEBUG_INFO, "sysinfoInit: realMobileStat.mode = %d\n", mobile_mode);
			break;
		}
		else if (++failTimes >= 10)
		{	
			/* 
			��ֹ2G��3G ���粻����ʱ��ǿ���л����絼���޷����ţ�
			��ʱ20s ����û̽�⵽�������ѯ��Ӫ����Ϣ��
			���ܲ鵽�������õ����磬��ѡ������ģʽ��Ϊ˫ģ����Ӧģʽ��
			*/
			memset(copsInfo, 0, COPS_MAX_NETWORKS * sizeof(COPS_INFO));

			mobile_log_write("sysinfoInit: failTimes = %d\n", failTimes);
			LTE4G_DEBUG(DEBUG_INFO, "sysinfoInit: failTimes = %d\n", failTimes);
			otherNetValidService = 0;
			/* PREFMODE ���EVDO */
			if (OK == writeATCommand(atFd, "AT^PREFMODE=8", "OK", (char*)NULL, 0, TRUE, 3000))
			{
				LTE4G_DEBUG(DEBUG_INFO, "the Modem Mode is EVDO\n");
				mobile_sysCfg = PREF_MODE_HYBRID;
				pDevDialParam->bySwitchMethold = SWITCH_METHOLD_AUTO;
			}/* COPS ���TD ��WCDMA */
			else if (OK == mobile_AT_list_all_operators(NULL, NULL))
			{
				(void)mobile_AT_set_auto_register(NULL, NULL);
				for(i = 0; i < COPS_MAX_NETWORKS; i++)
				{
					switch (copsInfo[i].stat)
					{
						case COPS_STAT_UNKNOW:
						case COPS_STAT_FORBID:
							break;
						case COPS_STAT_VALID:
						case COPS_STAT_REGISTED:
							otherNetValidService |= 1 << i;
							break;
						default:
							break;
					}
				}
				if (otherNetValidService)	/* �п���������� */
				{
					if (OK == writeATCommand(atFd, "AT^SYSCFG=2,2,3FFFFFFF,2,2", "OK", (char*)NULL, 0, TRUE, 3000))
					{
						mobile_sysCfg = SYSCFG_MODE_AUTO;
						pDevDialParam->bySwitchMethold = SWITCH_METHOLD_AUTO;
					}
					else if (OK == writeATCommand(atFd, "AT^SYSCONFIG=2,2,2,2", "OK", (char*)NULL, 0, TRUE, 3000))
					{
						mobile_sysCfg = SYSCFG_MODE_AUTO;
						pDevDialParam->bySwitchMethold = SWITCH_METHOLD_AUTO;
					}
				}
			}
			failTimes = 0;
		}
		sleep(2);
	}
	return;
}


/**@brief        initialize the wireless modem;
 * @param[in]    ��
 * @param[out]   ��
 * @return       ��
 */
void modemInit(void)
{
	char response[1024];
	char command[128];
	UINT64 bSmsExit = 0;
	int i = 0;
	//int search_mode = 0;
	PHONE_FUNCTION phone_function = CFUN_ONLINE_MODE;
	CALLER_ID_STATUS caller_id = CALLER_ID_OPEN;
	SMS_STORAGE_AREA storage_area = ME_AREA;
	SMS_FORMAT sms_format = SMS_TEXT_MODE;
	SEARCH_NETWORK_MODE search_mode = SEARCH_AUTO_MODE;
	PDP_STATUS pdp_status = PDP_DEACTIVE;
	
	memset(response, 0, sizeof(response));
	memset(command, 0, sizeof(command));
	memset(&sms_status, 0, MAX_SMSLIST_NUM *sizeof(SMS_STATUS));

	if(MODE_EVDO == mobile_mode || MODE_CDMA1X == mobile_mode)
	{
		LTE4G_DEBUG(DEBUG_INFO, "modemMode = MODE_EVDO \n");
		(void)mobile_AT_set_phone_function(&phone_function, NULL);
		if(shareMemParam->iModel != M_C7500)
		{
			(void)mobile_AT_set_TE_status(NULL, NULL);
		}
		(void)mobile_AT_set_SMS_storage_area(&storage_area, NULL);
		(void)mobile_AT_set_SMS_format(&sms_format, NULL);

		//sprintf(command, "AT^PPPCFG=\"%s\",\"%s\"", szUsername, szPassword);
		//writeATCommand(atFd, command, "OK", (char*)NULL, 0, TRUE, 3000);
		if (OK == mobile_AT_get_search_network_mode(NULL, response))
		{
			mobile_sysCfg = getSyscfg(response);
		}
		
		switch(pDevDialParam->bySwitchMethold)
		{
			case SWITCH_AUTO:
				if (mobile_sysCfg != SYSCFG_MODE_AUTO)
				{
					search_mode = SEARCH_AUTO_MODE;
					if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
					{
						mobile_sysCfg = SYSCFG_MODE_AUTO;
					}
				}
				break;
			case SWITCH_MANUAL_2G:
				if (mobile_sysCfg != SYSCFG_MODE_CDMA1X)
				{
					search_mode = SEARCH_CDMA_ONLY;
					if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
					{
						mobile_sysCfg = SYSCFG_MODE_CDMA1X;
					}
				}
				break;
			case SWITCH_MANUAL_3G:
				if (mobile_sysCfg != SYSCFG_MODE_EVDO)
				{
					search_mode = SEARCH_EVDO_ONLY;
					if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
					{
						mobile_sysCfg = SYSCFG_MODE_EVDO;
					}
				}
				break;
			default:
				LTE4G_DEBUG(RT_ERROR, "modemInit: NOT SUPPORT MODE,%d \n", pDevDialParam->bySwitchMethold);
				break;
		}
		//writeATCommand(atFd, "AT^HDRCSQ", "OK", (char*)NULL, 0, TRUE, 3000);
		//writeATCommand(atFd, "AT^CSQLVL", "OK", (char*)NULL, 0, TRUE, 3000);
	}
	else if(MODE_WCDMA == mobile_mode)
	{
		LTE4G_DEBUG(DEBUG_INFO, "modemMode = MODE_WCDMA \n");
		sms_format = SMS_PDU_MODE;
		mobile_AT_get_software_version(NULL, response);
		LTE4G_DEBUG(DEBUG_INFO, "\nAT+LCTSW > %s\n\n", response);
		(void)mobile_AT_set_caller_ID(&caller_id, NULL);		//����������ʾ��
		(void)mobile_AT_set_TE_status(NULL, NULL);			//����TEָʾ״̬
		(void)mobile_AT_set_SMS_storage_area(&storage_area, NULL);	//���õ�ǰ���ŵĴ洢����
		(void)mobile_AT_set_SMS_format(&sms_format, NULL);	//���õ�ǰ��������ͷ��͸�ʽ
		(void)mobile_AT_get_2G_status(NULL, NULL);			//��ѯ��ǰ2G�������״̬������״̬
		(void)mobile_AT_get_3G_status(NULL, NULL);			//��ѯ��ǰ3G�������״̬������״̬

		if (OK == mobile_AT_get_search_network_mode(NULL, response))
		{
			mobile_sysCfg = getSyscfg(response);
		}
		
		switch(pDevDialParam->bySwitchMethold)
		{
			case SWITCH_AUTO:
				if (mobile_sysCfg != SYSCFG_MODE_AUTO)
				{
					search_mode = SEARCH_AUTO_UNICOM;
					if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
					{
						mobile_sysCfg = SYSCFG_MODE_AUTO;
					}
				}
				break;
			case SWITCH_MANUAL_2G:
				if (mobile_sysCfg != SYSCFG_MODE_GSM)
				{
					search_mode = SEARCH_GSM_ONLY;
    				if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
       				{
           				mobile_sysCfg = SYSCFG_MODE_GSM;
        			}
				}
				break;
			case SWITCH_MANUAL_3G:
				if (mobile_sysCfg != SYSCFG_MODE_WCDMA)
				{
					search_mode = SEARCH_UMTS_ONLY;
       				if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
        			{
            			mobile_sysCfg = SYSCFG_MODE_WCDMA;
        			}
				}
				break;
			default:
				LTE4G_DEBUG(RT_ERROR, "modemInit: NOT SUPPORT MODE,%d \n", pDevDialParam->bySwitchMethold);
				break;
		}
		
		//(void)set_context_num_cid_undefined(NULL);
		(void)mobile_AT_set_APN(NULL, NULL);
		(void)mobile_AT_get_2G_status(NULL, NULL);			//��ѯ��ǰ2G�������״̬������״̬
		(void)mobile_AT_get_3G_status(NULL, NULL);			//��ѯ��ǰ3G�������״̬������״̬
	}
	else if (MODE_TDSCDMA == mobile_mode)
	{
		LTE4G_DEBUG(DEBUG_INFO, "modemMode = MODE_TDSCDMA \n");
		storage_area = SM_AREA;
		sms_format = SMS_PDU_MODE;
		(void)mobile_AT_set_caller_ID(&caller_id, NULL);		//����������ʾ��
		(void)mobile_AT_set_TE_status(NULL, NULL);			//����TEָʾ״̬
		(void)mobile_AT_set_SMS_storage_area(&storage_area, NULL);	//���õ�ǰ���ŵĴ洢����
		(void)mobile_AT_set_SMS_format(&sms_format, NULL);	//���õ�ǰ��������ͷ��͸�ʽ
		(void)mobile_AT_get_2G_status(NULL, NULL);			//��ѯ��ǰ2G�������״̬������״̬
		(void)mobile_AT_get_3G_status(NULL, NULL);			//��ѯ��ǰ3G�������״̬������״̬

		if (OK == mobile_AT_get_search_network_mode(NULL, response))
		{
			mobile_sysCfg = getSyscfg(response);
		}

		switch(pDevDialParam->bySwitchMethold)
		{
			case SWITCH_AUTO:
				if (mobile_sysCfg != SYSCFG_MODE_AUTO)
				{
					search_mode = SEARCH_AUTO_MODE;
					if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
					{
						mobile_sysCfg = SYSCFG_MODE_AUTO;
					}
				}
				break;
			case SWITCH_MANUAL_2G:
				if (mobile_sysCfg != SYSCFG_MODE_GSM)
				{
					search_mode = SEARCH_GSM_ONLY;
    				if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
       				{
           				mobile_sysCfg = SYSCFG_MODE_GSM;
        			}
				}
				break;
			case SWITCH_MANUAL_3G:
				if (mobile_sysCfg != SYSCFG_MODE_TDSCDMA)
				{
					search_mode = SEARCH_TDCMDA_ONLY;
       				if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
        			{
            				mobile_sysCfg = SYSCFG_MODE_TDSCDMA;
        			}
				}
				break;
			default:
				LTE4G_DEBUG(RT_ERROR, "modemInit: NOT SUPPORT MODE,%d \n", pDevDialParam->bySwitchMethold);
				break;
		}

		pdp_status = PDP_DEACTIVE;
		(void)mobile_AT_set_PDP_status(&pdp_status, NULL);
		//(void)set_context_num_cid_undefined(NULL);
		(void)mobile_AT_set_APN(NULL, NULL);

		(void)mobile_AT_set_QOS_request_briefing(NULL, NULL);		//���õ�ǰ��������ķ���������
		
		(void)mobile_AT_get_2G_status(NULL, NULL);			//��ѯ��ǰ2G�������״̬������״̬
		(void)mobile_AT_get_3G_status(NULL, NULL);			//��ѯ��ǰ3G�������״̬������״̬
	}
	else if ((MODE_TDLTE == mobile_mode)
		|| (MODE_FDDLTE == mobile_mode)){
		LTE4G_DEBUG(DEBUG_INFO, "modemMode = MODE_TDLTE || MODE_FDDLTE\n");
		storage_area = SM_AREA;
		sms_format = SMS_PDU_MODE;
		(void)mobile_AT_set_caller_ID(&caller_id, NULL);		//����������ʾ��
		(void)mobile_AT_set_TE_status(NULL, NULL);			//����TEָʾ״̬
		(void)mobile_AT_set_SMS_storage_area(&storage_area, NULL);	//���õ�ǰ���ŵĴ洢����
		(void)mobile_AT_set_SMS_format(&sms_format, NULL);	//���õ�ǰ��������ͷ��͸�ʽ
		(void)mobile_AT_get_2G_status(NULL, NULL);			//��ѯ��ǰ2G�������״̬������״̬
		(void)mobile_AT_get_3G_status(NULL, NULL);			//��ѯ��ǰ3G�������״̬������״̬
		(void)mobile_AT_get_4G_status(NULL, NULL);			//��ѯ��ǰ4G�������״̬������״̬

		if (OK == mobile_AT_get_search_network_mode(NULL, response))
		{
			mobile_sysCfg = getSyscfg(response);
		}

		LTE4G_DEBUG(DEBUG_INFO, "SwitchMethold = %d\n",pDevDialParam->bySwitchMethold);
		switch(pDevDialParam->bySwitchMethold)
		{
			case SWITCH_AUTO:
				if (mobile_sysCfg != SYSCFG_MODE_AUTO)
				{
					if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
					{
						search_mode = SEARCH_AUTO_UNICOM;
					}
					else
					{
						search_mode = SEARCH_AUTO_MODE;
					}
					if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
					{
						mobile_sysCfg = SYSCFG_MODE_AUTO;
					}
				}
				break;
			case SWITCH_MANUAL_2G:
				if (mobile_sysCfg != SYSCFG_MODE_GSM)
				{
					search_mode = SEARCH_GSM_ONLY;
    				if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
       				{
           				mobile_sysCfg = SYSCFG_MODE_GSM;
        			}
				}
				break;
			case SWITCH_MANUAL_3G:
				if (mobile_sysCfg != SYSCFG_MODE_TDSCDMA
					&& mobile_sysCfg != SYSCFG_MODE_WCDMA
					&& mobile_sysCfg != SYSCFG_MODE_EVDO)
				{
					if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator)
					{
						search_mode = SEARCH_TDCMDA_ONLY;
					}
					else if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
					{
						search_mode = SEARCH_UMTS_ONLY;
					}
					else
					{
						search_mode = SEARCH_EVDO_ONLY;
					}
									
					if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
        			{
						if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator)
						{
							mobile_sysCfg = SYSCFG_MODE_TDSCDMA;
						}
						else if(OPERATOR_CHINA_UNICOM == pDevDialParam->mobile_operator)
						{
							mobile_sysCfg = SYSCFG_MODE_WCDMA;
						}
						else
						{
							mobile_sysCfg = SYSCFG_MODE_EVDO;
						}
        			}
				}
				break;
           		case SWITCH_MANUAL_4G:
				if (mobile_sysCfg != SYSCFG_MODE_TDLTE
					&& mobile_sysCfg != SYSCFG_MODE_FDDLTE)
				{
					search_mode = SEARCH_LTE_ONLY;
					if (OK == mobile_AT_set_search_network_mode(&search_mode, NULL))
                    {
						if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator)
						{	
							mobile_sysCfg = SYSCFG_MODE_TDLTE;
						}
						else
						{
							mobile_sysCfg = SYSCFG_MODE_FDDLTE;
						}
            		 }
				}
				break;
			default:
				break;
		}

		pdp_status = PDP_DEACTIVE;
		mobile_AT_set_PDP_status(&pdp_status, NULL);
		//set_context_num_cid_undefined(NULL);
		
		mobile_AT_set_APN(NULL, NULL);

		mobile_AT_set_QOS_request_briefing(NULL, NULL);		//���õ�ǰ��������ķ���������
    }

	atcmd_snd_other();

	memset(response, 0, sizeof(response));
	(void)mobile_AT_check_sms_exist(NULL, response);
	bSmsExit = getSMSExist(response);
	
	if (MODE_EVDO == mobile_mode)
	{
		ECHO_STATUS status = ECHO_CLOSE;
		mobile_AT_set_echo_status(&status, NULL);
	}
	
#ifndef E020M
	for (i = 0; i < 64; i++)
	{
		if (bSmsExit & (1 << i))
		{
			sms_status[smsNum].index = i;
			(void)mobile_AT_read_SMS(&i, NULL);
			usleep(10 * 1000);
		}
	}
#endif
	return;
}

int open_mobile_usb_port(int usb_port)
{
	if(usb_port < 0)
	{
		LTE4G_DEBUG(RT_ERROR,"set_serial_port_mode: ERROR USB port\n");
	}

	int fd = ERROR;
	char devName[32];

	memset(devName, 0, sizeof(devName));
	
	sprintf(devName, "/dev/ttyUSB%d", usb_port);	

	if((fd = open(devName, O_RDWR)) != ERROR)
	{
		atFd = fd;
	}
	else
	{
		return ERROR;
	}

	return OK;
}


/**@brief			���õ�ǰUSB�ڵ�ģʽ�����óɹ���ȫ��atFd����
 * @param[in]		USB_port	��ǰʹ�õ�USB��
 * @param[out]  	��
 * @return        	OK, FALSE
 */
int set_serial_port_mode(int fd)
{
	if(SetSerialBaud(fd, B115200) != OK)
	{
		LTE4G_DEBUG(RT_ERROR,"set_serial_port_mode: SetSerialBaud error\n");
		close(fd);
		return ERROR;
	}
	if(SetSerialRawMode(fd) !=OK)
	{
		LTE4G_DEBUG(RT_ERROR,"set_serial_port_mode: SetSerialRawMode error\n");
		close(fd);
		return ERROR;
	}

	return OK;
}

/**@brief     ����AT�����շ���USB��
 *                (the channel includes: ttyUSB1~5, ttyACM0~ttyACM2; the ttyUSB0 and ttyACM0 are used for "pppd" as default)
 *                if no available channel is found, the process will exit with error number 7; then the parent process will reinstall the driver;
 * @param[in]     ��
 * @param[out]    ��
 * @return        ��
 */
static int findATChannel(void)
{
	int USB_port = -1;
	char id_product[32];
	BOOL bFind = FALSE;
	int errTimes = 0;
	int ret = 0;
	char lineBuf[128];
	char vendor[16];
	char ProdID[16];
	FILE *fp = NULL; 

	memset(id_product, 0, sizeof(id_product));

	memset(lineBuf, 0, sizeof(lineBuf));
	memset(vendor, 0, sizeof(vendor));
	memset(ProdID, 0, sizeof(ProdID));
	
	FOREVER
	{
		fp = fopen(IDPRODUCT_PATH, "r"); 
		if(fp != NULL)
		{
			// ��ȡ3G/4Gģ��Ĳ�ƷID��	
			while (!feof(fp)) 
			{	
				memset(lineBuf, 0, sizeof(lineBuf));
				fgets(lineBuf, sizeof(lineBuf), fp); 
				if(strstr(lineBuf, "P:"))
				{
					sscanf(lineBuf, "P:  Vendor=%s ProdID=%s", vendor, ProdID); 
					LTE4G_DEBUG(DEBUG_INFO, "4G: Vendor=%s ProdID=%s\n", vendor, ProdID);
				}
				else
				{
					continue;
				}

				if(!strncmp(ProdID, "9607", strlen("9607"))
					|| !strncmp(ProdID, "9e00", strlen("9e00"))	// C7500
					||  !strncmp(ProdID, "1c9e", strlen("1c9e")))	//C5300V
				{
					USB_port = 3;		// ttyUSB3
					break;
				}
				else if(!strncmp(ProdID, "9603", strlen("9603"))		// U7500 
					|| !strncmp(ProdID, "9b05",strlen("9b05")) // 8300,LM91XXϵ�� AT�����շ��˿�
					|| !strncmp(ProdID, "9b3c",strlen("9b3c")))		//9300C 
				{
					USB_port = 1;		// ttyUSB1
					break;
				}
				else if(!strncmp(ProdID, "1c25", strlen("1c25"))
					|| !strncmp(ProdID, "15c1", strlen("15c1")))		// ��Ϊģ��MU709S
				{
					USB_port = 4;		// ttyUSB4
					break;
				}
				else
				{
					shareMemParam->iModel = M_UNKNOWN;//ģ��δʶ��
					mobile_log_write("findATChannel: err_id_product = %s\n", ProdID);
					LTE4G_DEBUG(RT_ERROR, "\n\nfindATChannel: Error, id_product error: id_product = %s !!!\n\n",ProdID);
					//return ERROR;
				}
			}

			fclose(fp);
			
			if(-1 == USB_port)
			{
				sleep(1);
				continue;
			}
			
			//��¼��ǰģ���ID��
			strncpy(shareMemParam->id_product, ProdID,strlen(ProdID));

			if(ERROR == mobile_check_usb_lost(shareMemParam))
			{	 
				dial_error_occur(EXIT_DIAL_ABNORMAL);
			}
			if(OK == open_mobile_usb_port(USB_port))
				bFind = TRUE;
			else
			{
				mobile_log_write("findATChannel: open_usb_port Error %d\n", USB_port);
				LTE4G_DEBUG(RT_ERROR, "findATChannel: open_usb_port Error\n");
				sleep(5);
				continue;
			}
			
			if(set_serial_port_mode(atFd) != OK)
			{
				LTE4G_DEBUG(RT_ERROR, "findATChannel: set_serial_port_mode Error\n");
				sleep(5);
				continue;
			}			
		}
		else
		{
			LTE4G_DEBUG(RT_ERROR, "findATChannel: Error, NO USB device ? IDPRODUCT_PATH = %s, errno = %d\n",IDPRODUCT_PATH,errno);
			errTimes++;
		}

		if(bFind == TRUE)
		{
			shareMemParam->realMobileStat.epName = EP_TTYUSB;
			break;
		}
		else
		{
			LTE4G_DEBUG(RT_ERROR, "findATChannel: find USB device again, wait 15s ...\n");
		}
		
		if (errTimes >= 6)
		{
			/* Dial-Status: c-REINST_DRIVE */
			LTE4G_DEBUG(RT_ERROR, "findATChannel: not find usb wireless modem!\n");
			dial_error_occur(EXIT_DIAL_ABNORMAL);
			return ERROR;
		}
		sleep(2);
	}
	usleep(100*1000);
	return OK;
}

/**@brief         send the log to main process
 * @param[in]     int iOper: the operation id
                  char * pParam: the log information
 * @param[out]    none
 * @return        none
 */
void sendLog(int iOper, char * pParam)
{
	LOG_SMS *pSmsPara = NULL;
	LOG_CALL *pCallPara = NULL;
	int i = 0;
	int bNewLog = 0;
	int iLogLen = 0;

	switch(iOper)
	{
		case LOG_OPER_SMS:
			if ((pSmsPara = (LOG_SMS *)pParam) != NULL && strlen((char *)(pSmsPara->szPhoneNumber)) != 0)
			{
				bNewLog = TRUE;
				iLogLen = sizeof(LOG_SMS);
			}
			break;
		case LOG_OPER_CALL:
			if ((pCallPara = (LOG_CALL *)pParam) != NULL && strlen((char *)(pCallPara->szPhoneNumber)) != 0)
			{
				bNewLog = TRUE;
				iLogLen = sizeof(LOG_CALL);
			}
			break;
		case LOG_OPER_REBOOT:
			if ((pCallPara = (LOG_CALL *)pParam) != NULL && strlen((char *)(pCallPara->szPhoneNumber)) != 0)
			{
				bNewLog = TRUE;
				iLogLen = sizeof(LOG_CALL);
			}
			break;
		default:
			break;
	}
	if (bNewLog)
	{
		for (i = 0; i < MAX_DIALLOG_NUM; i++)
		{
			if (FALSE == shareMemParam->LogInfo[i].bHasLog)
			{
				bzero((char *)&shareMemParam->LogInfo[i], MAX_DIALLOG_LEN);
				shareMemParam->LogInfo[i].byOper = (UINT8)iOper;
				memcpy(shareMemParam->LogInfo[i].szParam, pParam, iLogLen);
				shareMemParam->LogInfo[i].bHasLog = TRUE;
				break;
			}
		}
	}
	return;
}

/**@brief         send the at command from other place
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
int atcmd_snd_other(void)
{
	int i = 0, j = 0;
	int retVal = ERROR;
	INT8 *p = NULL;
	int smsIndex = -1;
	char response[128];

	memset(response, 0, sizeof(response));

	if (bATComRcvd)
	{
		for (i = 0; i < MAX_SHM_ATCOM_NUM; i++)
		{
			if ((bATComRcvd & (1 << i)) == 0)
			{
				continue;
			}
			/* send AT command */
			if (strlen(shareMemParam->ATComBuf[i]) != 0)
			{
				/* query the networks operators' infomation
				if the modem has not dialded yet, it returns all the networks information the modem supports; 
				else, just returns the current network the modem uses */
				if (strstr(shareMemParam->ATComBuf[i], "cops") != NULL)		
				{	/* it needs about half minute to get the response */
					retVal = writeATCommand(atFd, "AT+COPS=?", "OK", (char*)NULL, 0, TRUE, 5000);
				}
				else if (strcmp(shareMemParam->ATComBuf[i], "list") == 0)
				{
					for (j = 0; j < smsNum; j++)
					{
						shareMemParam->smsList[j].index = sms_status[j].index;
						memcpy(shareMemParam->smsList[j].recvTime, sms_status[j].recvTime, 16);
					}
					shareMemParam->smsNums = smsNum;
				}
				else if ((p = strstr(shareMemParam->ATComBuf[i], "readsms"))  != NULL)
				{	/* readsms<smsIndex> */
					p = p + 7;
					smsIndex = atoi(p);		/* smsIndex */
					
					for (j = 0; j < smsNum; j++)
					{
						if (smsIndex != sms_status[j].index)
							continue;
						shareMemParam->smsReadStat &= ~(1 << smsIndex);
						shareMemParam->smsListContent.index = sms_status[j].index;
						memcpy(shareMemParam->smsListContent.msg, sms_status[j].msg, \
							sizeof(shareMemParam->smsListContent.msg));
						memcpy(shareMemParam->smsListContent.phoneNum, sms_status[j].phoneNum, \
							sizeof(shareMemParam->smsListContent.phoneNum));
					}
				}
				else		/* write the AT commands from other place */
				{
					if (strstr(shareMemParam->ATComBuf[i], "CMGR") != NULL
						|| strstr(shareMemParam->ATComBuf[i], "CLCK") != NULL
						|| strstr(shareMemParam->ATComBuf[i], "CPIN") != NULL
						|| strstr(shareMemParam->ATComBuf[i], "CPWD") != NULL)  /* fixed on 110125 */
					{
						writeATCommand(atFd, "ATE0", "OK", (char*)NULL, 0, TRUE, 3000);
					}

					if (strstr(shareMemParam->ATComBuf[i], "CGMI") != NULL
						|| strstr(shareMemParam->ATComBuf[i], "CGSN") != NULL
						|| strstr(shareMemParam->ATComBuf[i], "CGMR") != NULL
						|| strstr(shareMemParam->ATComBuf[i], "CIMI") != NULL
						|| strstr(shareMemParam->ATComBuf[i], "AT^HWVER") != NULL
						|| strstr(shareMemParam->ATComBuf[i], "AT^SN") != NULL)
					{
						lastRsp.bEnable = 1;
						if (writeATCommand(atFd, shareMemParam->ATComBuf[i], "OK", response, 128, TRUE, 1000) == OK)
						{
							lastRsp.bEnable = 0;
							atPrintf(response); 
							memcpy(shareMemParam->szRespString, response, 48);
						}
						lastRsp.bEnable = 0;
					}
					else
					{
						retVal = writeATCommand(atFd, shareMemParam->ATComBuf[i], "OK", (char*)NULL, 0, TRUE, 3000);
					}
					if (strstr(shareMemParam->ATComBuf[i], "CLCK") != NULL 
						||strstr(shareMemParam->ATComBuf[i], "CPIN") != NULL 
						||strstr(shareMemParam->ATComBuf[i], "CPWD") != NULL)
					{
						/* getPinInfo���������shareMemParam->curCommRet ��ֵǰ���Ա�֤ʣ�����ˢ����ȷ */
						memset(response, 0, sizeof(response));

						LTE4G_DEBUG(DEBUG_INFO, "send AT+CPIN\n");
						
						// ����AT+CPIN��ͨ��ָ����Է���ǰ���⣬��AT^CPIN����չָ��
						if (writeATCommand(atFd, "AT+CPIN?", "+CPIN:", response, 128, TRUE, 3000) == OK)
						{
							getPinInfo(response);

#if 0						// ��ָ����U6100��C5100�ж�δ֧�֣���ȥ���� yhw 2013-03-26
							if (writeATCommand(atFd, "AT^DRAP", "^DRAP:", response, 128, TRUE, 3000) == OK)
							{
								getPinTimes(response);
							}
#endif
						}
						else if (writeATCommand(atFd, "AT^CPIN?", "^CPIN:", response, 128, TRUE, 3000) == OK)
						{
							getPinInfo(response);
						}

						/* getPinLockStatus���������shareMemParam->curCommRet ��ֵǰ���Ա�֤PIN�˵���״̬ˢ����ȷ */
						memset(response, 0, sizeof(response));
						if (writeATCommand(atFd, "AT+CLCK=\"SC\",2", "+CLCK:", response, 128, TRUE, 1000) == OK)
						{
							shareMemParam->pinInfo.pinLockStatus = getPinLockStatus(response);
						}
						LTE4G_DEBUG(DEBUG_INFO, "CLCK: ADDR 3\n");
						if (retVal == OK)
						{
							retVal = 1;	/* pin manage excute OK */
						}

						shareMemParam->curCommRet = retVal;	/* set the return value of pin related function */
					}
					else if (strstr(shareMemParam->ATComBuf[i], "CFUN") != NULL)
					{
						/* some wireless modem need some time to wait for this command take effect */
						sleep(3);
					}
				}
				memset(shareMemParam->ATComBuf[i], 0, MAX_SHM_ATCOM_LEN);
				pthread_mutex_lock(&rilSem);
				bATComRcvd &= ~(1 << i);
				pthread_mutex_unlock(&rilSem);
			}

		}

		return 1;
	}

	return 0;
}

/**@brief         get the modem model
 * @param[in]     char * pModemName
 * @param[out]    none
 * @return        the modem model, see definition of "MODEL_IDX"
 */
int getModemModel(char * pModemName)
{
	int iModel = 0;
	unsigned int i = 0;

	if (pModemName == NULL)
	{
		LTE4G_DEBUG(DEBUG_INFO, "getModemModel: input param error\n");
		return 0;
	}

	for (i = 0; i < (sizeof(strModel)/sizeof(MODEM_MODEL)); i++)
	{
		if (strstr(pModemName, strModel[i].pModelStr))
		{
			iModel = strModel[i].iModelIdx;
			break;
		}
	}
	
	return iModel;
}

/**@brief        reregister network depends on the Sysinfo of srv_status ,srv_domain or sys_mode ,diald failed times
 * @param[in]    line ��Ҫ�������ַ���
 * @param[in]    ��
 * @param[out]   wirelessStat ���ص��豸��Ϣ 
 * @return       TRUE:1,FALSE:0
 */
static int mobile_reregister_network(void) 
{ 	
	PHONE_FUNCTION phone_function = CFUN_LPM_MODE; 
	BOOL current_mode_err = FALSE;
	static int service_restricted_times = 0;  
	static int loop_count = 1;
	static int cfun_count = 0; 
	
	/* 
	 * Checking current mobile network is OK in every 120 seconds, the following sutiation is abnormal:
	 * 1. current mobile mode is NONE
	 * 2. current mobile mode is 2G mode & dial fialed , such as GPRS
	 * 3. current signal is too low that causing dial fialed or not dialing.
	 * 4. add case sysinfo(customer issue):0 3 0 0 1 ,dial success but network is invalid
	 */ 
	if(6 == (loop_count++))  /* 120sec / 20sec that represents 20s one turn.  */
	{ 
		if(MODE_NONE == mobile_mode 
			|| (MODE_GPRS == mobile_mode && is_mobile_online())
			|| (mobile_signal <= 3 &&  is_mobile_online())
			|| (SRV_NO_SERVICE == mobile_srvStat && is_mobile_online()))
					
		{
			current_mode_err = TRUE;
 			LTE4G_DEBUG(DEBUG_INFO, "mobile_reregister_network:mode_state error\n");
			mobile_log_write("mode = %d, signal = %d srvStat = %d srvDomain = %d\n", 
						     mobile_mode, mobile_signal, mobile_srvStat, mobile_srvDomain); 
	    }
		else
		{		
			loop_count = 1;	/* count again when loop_count >= 6  */
			cfun_count = 0;
		}
	}
	 
	/**
	 * if the  srv_status is 0 or 1 (it represents no service or restricted services) 
	 * or srv_domain is 0 or 1 (it represents no service or CS service only)   
	 */  
	if(SRV_NO_SERVICE == mobile_srvStat
	   || SRV_RESTRICTED_SERVICE == mobile_srvStat 
	   || SRV_STATUS_NONE == mobile_srvDomain
	   || SRV_STATUS_CS == mobile_srvDomain)   	 
	{  	
		service_restricted_times++;	
		LTE4G_DEBUG(DEBUG_INFO, "mobile service_restricted_times[%d]\n", service_restricted_times);
		mobile_log_write("service_restricted_times[%d]\n", service_restricted_times);
	}
	else
	{
		service_restricted_times = 0;  /* once service is not restricted,count again */
	} 
	
	/* 20min/20s means about 60 times */
	if( service_restricted_times >= 60 
		|| get_continuous_dial_failed_times() > 20 
		|| current_mode_err)
  
	{
		LTE4G_DEBUG(DEBUG_INFO, 
			"mobile estricted_times:[%d], failed_times:[%d], mode_stat:[%d],cfun_count[%d].\n",
			service_restricted_times, get_continuous_dial_failed_times(), current_mode_err,cfun_count);

		mobile_log_write("restricted_times:[%d], failed_times:[%d], mode_stat:[%d],cfun_count[%d] net_search_num[%d].\n",
						service_restricted_times, 
						get_continuous_dial_failed_times(), 
						current_mode_err, 
						cfun_count, 
						shareMemParam->net_search_num);
		
		cfun_count++;
		shareMemParam->net_search_num++;

		/*all count again if execute reregister task */
		service_restricted_times = 0;
		loop_count = 1;
		current_mode_err = FALSE;

		/* ADD: seach net number limited 
		   cause times of erasing SIM card is limited 2017.6.23 */
		if(shareMemParam->net_search_num < 30) {
			
			/* do the task of reregistering mobile network */
			while(mobile_AT_set_phone_function(&phone_function, NULL) != OK)
			{
				pthread_testcancel();
				sleep(1);
			}
			sleep(1);
			phone_function = CFUN_ONLINE_MODE;
			while(mobile_AT_set_phone_function(&phone_function, NULL) != OK)
			{
				pthread_testcancel();
				sleep(1);
			}	
		}
		
	} 
	 
	/* AT+CFUN command has been excuted 5 times,but network not recover,try to Reset module */
	if(cfun_count >= 5) 
	{
		shareMemParam->net_search_num++;
		cfun_count = 0;
		service_restricted_times = 0;
		loop_count = 1;
		current_mode_err = FALSE; 

		if(shareMemParam->net_search_num < 30) {
			LTE4G_DEBUG(RT_ERROR, "mobile_reregister_network: reset module now ...\n");
			dial_error_occur(EXIT_DIAL_MODULERESET); 
			mobile_AT_reset_module(NULL, NULL);
		}	
		
	}
	/* return value must be ok unless AT failed ,it would be casted in a loop */
	return OK;
}


/**@brief       ���ɵ�ǰҪ���������APN
 * @param[in]    response	�����ַ�����ַ,���ΪNULL���÷���
 * @param[out]   ��
 * @return       OK,ERROR
 */
char* mobile_AT_get_def_APN(char* pcfgApn)
{
	char* apn = NULL;
	if(!pcfgApn){
		return NULL;
	}
	LTE4G_DEBUG(RT_ERROR, "mobile_AT_get_def_APN src: %s\n", pcfgApn);
	mobile_log_write("mobile_AT_get_def_APN src: %s\n", pcfgApn);
	
	if (strlen(pcfgApn) == 0){
		
		if(OPERATOR_CHINA_MOBILE == pDevDialParam->mobile_operator){
			apn = TDLTE_DFT_APN;
		}else if(OPERATOR_CHINA_TELECOM == pDevDialParam->mobile_operator){
			apn = FDDLTE_TELECOM_DFT_APN;
		}else{
			/* China unicom 3G ,4G APN are diffirent. if depend on switch meyhod,
				when operator is UNICOM and switch meyhod is AUTO, diald will be unsucessful*/
			if(MODE_FDDLTE == mobile_mode){ 
				if(M_LM91XX == shareMemParam->iModel){
					apn = FDDLTE_UNICOM_DFT_APN;
				}else{
					//U8300 series APN is 3gnet
					apn = WCDMA_DFT_APN;
				}
			}else if(MODE_WCDMA == mobile_mode){
				apn = WCDMA_DFT_APN;
			}
			else{
				//nothing to do.
			}
		}
	}else{
		apn = (char *)pcfgApn;
	}
	LTE4G_DEBUG(RT_ERROR, "mobile_AT_get_def_APN dst: %s\n", apn);
	mobile_log_write("mobile_AT_get_def_APN dst: %s\n", apn);
	return apn;
}


#endif /* WIRELESS_MODEM */


