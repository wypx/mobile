/**@file diald_log.c
 * @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 * @brief  
 * 
 * @author   luotang
 * @date     2016-10-20
 * @version  1.0
 * 
 * @note ��4Gģ����־��Ϣ��¼��flash��
 * @note History:        
 * @note     <author>   <time>    <version >   <desc>
 * @note  
 * @warning  
 */

#include "diald_log.h"
#include "dev_debug.h"

static int 		mobile_update_log_info(DialdLOG* ctx, int last_write_pos);
static int 		mobile_write_info_to_file(DialdLOG* ctx, const char *info, int len);
static void 	mobile_get_current_time(char *local_time, int len);
static char*	mobile_dupvprintf(const char *fmt, va_list ap);

static DialdLOG 	dialdLog; 
static DialdLOG* 	plog = &dialdLog;

static int mobile_update_log_info(DialdLOG* ctx, int last_write_pos)
{
	int 	ret = -1;
	char 	log_info[DIALD_LOG_HEAD_LEN];

	if(!ctx || last_write_pos < 0){
		return -1;
	}

	memset(log_info, 0, sizeof(log_info));
	
	ret = lseek(ctx->logfd, 0, SEEK_SET); 
	if(ret < 0){
		LTE4G_DEBUG(RT_ERROR, "lseek file start error:%s\n", strerror(errno));
		return -1;
	} 
	snprintf(log_info, DIALD_LOG_HEAD_LEN, DIALD_LOG_TITLE, last_write_pos);
	ret  = write(ctx->logfd, log_info, strlen(log_info)); 
	if(ret != strlen(log_info)){
		LTE4G_DEBUG(RT_ERROR, "write file header error:%s\n", strerror(errno));
		return -1;
	}
	return 0;
	
}
static int mobile_write_info_to_file(DialdLOG* ctx, const char *info, int len)
{ 
	
	int 	ret = -1;  
	int 	total_len = 0; 
	int 	last_write_pos = 0;
  	char 	read_buf[DIALD_LOG_HEAD_LEN]; 

	memset(read_buf, 0, sizeof(read_buf));
	
	if (!info || !ctx || ctx->logfd < 0 || len <= 0){
		LTE4G_DEBUG(RT_ERROR, "param is error\n");
		return -1;
	} 
	
	pthread_mutex_lock(&(ctx->mutex));
 
	total_len = lseek(ctx->logfd, 0, SEEK_END); 
	if(total_len < 0){
		LTE4G_DEBUG(RT_ERROR, "lseek total_len error:%s\n", strerror(errno));
		goto err;
	}
	else if(0 == total_len){
		/* write header info */
		ret = mobile_update_log_info(ctx, DIALD_LOG_HEAD_LEN);
		if(0 != ret){
			goto err;
		}
		total_len += DIALD_LOG_HEAD_LEN;
		ret = lseek(ctx->logfd, DIALD_LOG_HEAD_LEN, SEEK_SET);
		if (ret < 0)
		{
			LTE4G_DEBUG(RT_ERROR,"lseek log_head_len failed\n");
			goto err;
		}
	}
	else {
		ret = lseek(ctx->logfd, 0, SEEK_SET); /* jump to file start */
		if (ret < 0){
			LTE4G_DEBUG(RT_ERROR, "lseek file start error:%s\n", strerror(errno));
			goto err;
		}
		
		/* check whether the log file size > DIALD_LOG_FILE_SIZE, device maybe reboot*/
		ret = read(ctx->logfd, read_buf, DIALD_LOG_HEAD_LEN);
		if (ret < 0){ 
			LTE4G_DEBUG(RT_ERROR,"[%d][%s]read info failed(%d---%d)\n", __LINE__, __func__, ret, len);
			goto err;
		}

		sscanf(read_buf, "[4G_LOG_INFO:%d]", &last_write_pos); 	
		LTE4G_DEBUG(DEBUG_INFO, "log last_write_pos:%d\n", last_write_pos);
		
		if (last_write_pos + len > DIALD_LOG_FILE_SIZE){
			LTE4G_DEBUG(RT_ERROR, "4g write log roolback\n"); 
			last_write_pos = DIALD_LOG_HEAD_LEN;
		}
		ret = lseek(ctx->logfd, last_write_pos, SEEK_SET); /* Skip log header*/
		if (ret < 0){
			LTE4G_DEBUG(RT_ERROR, "lseek last_write_pos error:%s\n", strerror(errno));
			goto err;
		}
		total_len = last_write_pos;
	}
	
	ret = write(ctx->logfd, info, len); 
	if(ret != len){  
		LTE4G_DEBUG(RT_ERROR, "[%d][%s] write info failed(%d---%d)\n", __LINE__, __func__, ret, len); 
		goto err;
	}

	mobile_update_log_info(ctx, total_len + len);
	
	fsync(ctx->logfd);
	pthread_mutex_unlock(&(ctx->mutex));
	return 0;
	
err:
	fsync(ctx->logfd);
	pthread_mutex_unlock(&(ctx->mutex));
	return -1;
}

void mobile_get_current_time(char *local_time, int len)
{
	if(!local_time){
		return;
	}
	time_t cur_time = 0;
	struct tm *p_tm = NULL;

	time(&cur_time);
	p_tm = localtime(&cur_time);
	if(!p_tm){
		return;
	}
	snprintf(local_time, len, "[%d-%02d-%02d %02d:%02d:%02d]", p_tm->tm_year + 1900, p_tm->tm_mon + 1, 
			p_tm->tm_mday, p_tm->tm_hour, p_tm->tm_min, p_tm->tm_sec);
	return;
}


static char *mobile_dupvprintf(const char *fmt, va_list ap)
{
	char*	buf;
	char* 	prebuf;
    int len, size;

    buf = snewn(128, char);
	if(!buf){
		return NULL;
	}
    size = 128;

    while (1) {
#ifdef va_copy
	va_list aq;
	va_copy(aq, ap);
	len = vsnprintf(buf, size, fmt, aq);
	va_end(aq); 
#else
	len = vsnprintf(buf, size, fmt, ap);
#endif
	if (len >= 0 && len < size) { 
	    return buf;
	} else if (len > 0) { 
	    size = len + 1;
	} else {
	    /* This is the pre-C99 glibc error condition: <0 means the
	     * buffer wasn't big enough, so we enlarge it a bit and hope. */
	    size += 128;
	}

	/* 	If realloc failed, a null pointer is returned, and the memory 
	 *	block pointed to by argument buf is not deallocated(not free or move!!!). 
	 *	(it is still valid, and with its contents unchanged)
	 *	ref: http://www.cplusplus.com/reference/cstdlib/realloc/ 
	*/
	prebuf = buf;
	buf = sresize(buf, size, char);
	if(!buf){
		sfree(prebuf);
		return NULL;
	}

	}

}

int	mobile_log_init(void)
{
	char file_path[32];

	memset(file_path, 0, 32);
	memset(plog, 0, sizeof(DialdLOG));
	plog->logfd = -1;
	pthread_mutex_init(&(plog->mutex), NULL);

	snprintf(file_path, 32, "%s/%s.log", FLASH_LOG_DIR_NAME, "diald_info"); 
	
	plog->logfd = open(file_path, O_CREAT | O_RDWR, 0766);
	if (plog->logfd < 0){
		LTE4G_DEBUG(RT_ERROR, "[%d][%s]fail to open %s\n", __LINE__, __func__, file_path);
		return -1;
	} 
	return 0;

}
int mobile_log_write(const char* errfmt, ...)
{
	if(!errfmt)
	{
		LTE4G_DEBUG(RT_ERROR, "err fmt is error\n");
		return -1;
	}
	char 	local_time[MAX_TIME_LEN];
	char 	msg[MAX_DBGMSG_LEN];
	va_list ap; 		/* save arg list*/ 
	char*	data;		/* save the param */
	int 	time_len = 0;
	int 	data_len = 0;

	memset(msg, 0, MAX_DBGMSG_LEN);
	memset(local_time, 0, sizeof(local_time));	

	mobile_get_current_time(local_time, sizeof(local_time)); 
	
	va_start(ap, errfmt); /* arglist point to first arg, errfmt is the last arg */   
    data = mobile_dupvprintf(errfmt, ap);
    va_end(ap);   

	if(!data){
		return -1;
	}
	time_len = strlen(local_time);
	data_len = strlen(data);
	if(0 == time_len || 0 == data_len
		|| (time_len + data_len) > MAX_DBGMSG_LEN)
	{
		sfree(data);
		return -1;
	}	
	memcpy(msg, local_time, time_len);
	memcpy(msg + strlen(local_time), data, data_len);
	mobile_write_info_to_file(plog, msg, strlen(msg));
	
	sfree(data); 
	 
	return 0;
}