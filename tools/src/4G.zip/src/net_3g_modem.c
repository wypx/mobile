/**@file net_3g_modem.c
 * @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 * @brief  3Gģ����صĻ�������
 * 
 * @author   liuqi yanghongwen
 * @date     2012-11-19
 * @version  4.0
 * 
 * @note     ///Description here 
 * @note     History:        
 * @note     <author>   <time>    <version >   <desc>
 * @note     liuqi yanghongwen 2012/11/19 4.0 �����ļ�
 * @warning  
 */

#include <sys/time.h>
#include <sys/param.h>
#include <termios.h>
#include <ctype.h>
#include "dvr.h"
#include "dvrLogLib.h"
#include "Davinci/netconfig.h"
#include "net_3g_modem.h"
#include "dev_debug.h"

#include "Davinci/utility.h"
#include "capability/device_capa_interface.h"
#ifdef DB_PROCESS
#include "davinci_db_communicate.h"
#include "Db_uni_process.h"
#endif
/* ȫ�ֱ��� */
COMMUNICATION_PARAM		*comm_param = NULL;
SHM_PARAM				*shareMemParam = NULL;
static int g_shmid = 0;
#ifdef ALARMIN_DIAL
static int g_UpdateTime = 0;	/* �Զ�����ʱ����� */
#endif
//static UINT32 	lSmsSendStat[MAX_EXCEPTION_TYPE] = {0};
static struct MOBILE_SMS *pSmsList = NULL;
int g_sms_num = 0;
static int former_operator = 0;

#if defined(R2_PLAT)|| defined(E0_PLAT) || defined (R6_S2LM) || defined(G1_PLAT)
extern INT32 gpio_set_value(INT32 fd, UINT32 gpio, INT32 value);
#endif

/* �ⲿ���� */
IMPORT INT32 gNetConns;				/* Ԥ���ͻط��������ܺ� */

IMPORT STATUS writeDevParam(DEVICECONFIG *pDevCfg);
extern void initNetIf(NETWORK *pNetCfg);
extern INT32 save_4g_lte_config(void);
extern BOOL is_mobile_IPCAM(void);
extern int callSystemCmd(char *cmd);
extern BOOL is_upgrading(void);

#if defined(R2_PLAT)|| defined(E0_PLAT)
    #define MOBILE_PWEN_GPIO_NUM (7)
#endif 

#ifdef R6_S2LM
    #define MOBILE_PWEN_GPIO_NUM (136+4)
#endif 



/**@brief get current dialProcessStat by modem stat
 * @param[In]   NONE 
 * @return	DIAL_SUCCESS -  DIALING -- DISCONNECT
 */
DIAL_STAT mobile_get_dial_stat(void)
{ 
	if(NULL == shareMemParam)
	{
		return DIAL_SHM_ERROR;
	}
	UINT32 ret = shareMemParam->realMobileStat.dialProcessStat;
	UINT32 dialStat = DIAL_DISCONNECT;
	
	if(DIAL_KEEP_ONLINE == ret)	// dial success
	{
		dialStat = DIAL_SUCCESS;
	}
	else if((ret < DIAL_ENTER_DIAL) || (ret > DIAL_KEEP_ONLINE))// dial disconnect
	{
		dialStat = DIAL_DISCONNECT;
	}
	else														// dialing
	{
		dialStat = DIAL_DIALING;
	}
	return dialStat;

}

/**@brief ��⵱ǰ4G�����Ƿ�����
 * @param[In]	��
 * @return	TRUE: ����
 			FALSE: ������
 */
BOOL is_mobile_online(void)
{
	char ipAddr[20];

	memset(ipAddr, 0, sizeof(ipAddr));
	//ֻ�е�ǰ������4G���Ų�ȥ�жϵ�ǰ4G�����Ƿ���ã�����ֱ�ӷ���FALSE
	if((TRUE == pDevCfgParam->struDialCfg.byEnableMobile)
		&& (FALSE == pDevCfgParam->pppoePara.enablePPPoE))
	{
		if(get_ipaddr(PPP_INTERFACE, ipAddr, 20) != OK)
		{
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
	else
	{
		return FALSE;
	}
}
 

/**@brief		stop all the tasks related with Mobile module, it may spend about 10 seconds  
 * @param[in]  none
 * @param[out] none
 * @return	0: success; -1: failed  
 */
int stopMobileTask(void)
{

	LTE4G_DEBUG(DEBUG_INFO, "stop 3G task!\n");
	if (shareMemParam != NULL)
	{
		shareMemParam->initFinish = 0;
		shareMemParam->exitDial = 1;
		return OK;
	}

	return ERROR;
}

/**@brief		��ȡ�����ڴ��ָ��
 * @param[in] 	pdata �����ڴ�ָ��ĵ�ַ
 * @param[out] pdata �����ڴ�ָ��ĵ�ַ
 * @return	ok �ɹ�   ERROR ʧ��
 */
static int getSeg(COMMUNICATION_PARAM **pdata, DEVICECONFIG* pDevCfgParam)
{
	/* ȡ�ù����ڴ�key�������û�����ͽ���(IPC_CREAT) */
	if ((g_shmid = shmget(SHMKEY, sizeof(COMMUNICATION_PARAM), 0600|IFLAGS)) < 0)
	{
		if (errno == EEXIST)
		{
			g_shmid = shmget(SHMKEY, sizeof(COMMUNICATION_PARAM), 0600|IPC_CREAT);
			if (g_shmid < 0)
			{
				LTE4G_DEBUG(RT_ERROR, "shmget err1: 0x%x\n", errno);
				return ERROR;
			}
			LTE4G_DEBUG(DEBUG_INFO, "*** shmget ATTACH.\n");
		}
		else
		{
			LTE4G_DEBUG(RT_ERROR, "shmget err2: 0x%x\n", errno);
			return ERROR;
		}
	}
	else
	{
		// �������Ҫ����ʱ��ӡ�����������ڴ洴���ɹ�
		LTE4G_DEBUG(RT_ERROR, "\n*** shmget CREATE.\n");
		memset(shmat(g_shmid, 0, 0), 0, sizeof(SHM_PARAM));
	}

	
	LTE4G_DEBUG(DEBUG_INFO, "shmget finish\n");
	/* ȡ�ù����ڴ��ָ�� */
	if ((*pdata = (COMMUNICATION_PARAM *)(shmat(g_shmid, 0, 0))) == SHM_ERR)
	{
		LTE4G_DEBUG(RT_ERROR, "shmat err3: 0x%x\n", errno);
		return ERROR;
	}
	else
	{
		//��ȡ�����ڴ��ָ��֮�󣬽�ȫ�ֱ�������3G/4Gģ������Ҫ�õ��Ĳ�����ֵ���Ա�����3G/4G������ֱ�ӿɻ�ȡ����
		memcpy(&(*pdata)->enablePPPoE, &pDevCfgParam->pppoePara.enablePPPoE, 1);
		memcpy(&(*pdata)->struDialCfg, &pDevCfgParam->struDialCfg, sizeof(DIAL_CFG));
		memcpy(&(*pdata)->struSmsParam,&pDevCfgParam->struSmsParam, sizeof(SMS_PARAM));
		shareMemParam = &((*pdata)->shm_param);
		//�ڹ����ڴ��з�����һ������ǰ���ŵĲ���
		shareMemParam->sms_receipt_operation = pDevCfgParam->struSmsParam.sms_receipt_operation;
		//�豸����֮���ȼ�¼��һ�ε���Ӫ��
		former_operator = pDevCfgParam->struDialCfg.mobile_operator;
		shareMemParam->language = pDevCfgParam->language;
	}

	LTE4G_DEBUG(DEBUG_INFO, "getSeg finish\n");
	return OK;
}

/**@brief         copy the white list to the share memory;
 * @param[in]     pBuf :point to the white list content;
 * @param[out]    none former_operator
 * @return        none
 */
void shm_copy_whitelist(UINT8 * pBuf)
{
	if (shareMemParam != NULL && pBuf != NULL)
	{
		memcpy(shareMemParam->cellNumber, pBuf, sizeof(PHONE_CFG) * MAX_WHITELIST_NUM);
	}
	else
	{
		LTE4G_DEBUG(RT_ERROR, "input param error\n");
	}
	return;
}

/**@brief         check is number
 * @param[in]     point to the phone number;
 * @param[out]    none
 * @return        0:OK,-1:ERROR
 */
int mobile_check_is_num(char * pNum)
{
	UINT32 j=0;

	if(NULL == pNum)
	{
		LTE4G_DEBUG(RT_ERROR, "mobile_check_is_num: Input param NULL\n.");
		return ERROR;
	}
	
	if(*pNum)
	{
		for(j = 0; j < strlen(pNum); j++)
		{
			if((pNum[j]< '0') || (pNum[j]> '9'))
			{
				return ERROR;
			}
		}
	}

	return OK;
}


/**@brief         check the phone number is start with 86
 * @param[in]     point to the phone number;
 * @param[out]    none
 * @return        0:OK,-1:ERROR
 */
int mobile_check_phoneNum_is_startWith_86(char * pNum)
{
	char *phoneNum_start = "86";

	if(NULL == pNum)
	{
		LTE4G_DEBUG(RT_ERROR, "mobile_check_phoneNum_is_startWith_86: Input param NULL\n.");
		return ERROR;
	}

	for(; *pNum != '\0' && *phoneNum_start != '\0';pNum++, phoneNum_start++)
	{
		// Checking phone number is start with 86.
		if(*pNum != *phoneNum_start)
		{
			LTE4G_DEBUG(RT_ERROR, "phone len :13, not start with 86, number :\n",pNum);
			return ERROR;
		}
	}
	
	return OK;
} 

/**@brief         dial entry for dav process
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
void dial_entry(DEVICECONFIG* pDevCfgParam)
{
	if (ERROR == getSeg(&comm_param,pDevCfgParam))
	{
		LTE4G_DEBUG(RT_ERROR, "dial_entry:getSeg failure\n");
		return;
	}
	
#if defined(R2_PLAT)|| defined(E0_PLAT) ||  defined(R6_S2LM)
	/*
	* R2 and R6 platform soft restart will not cut the 4G module power , so we
	* should cut the power when device is power on.
	*/
	if(check_capa_support(FIRST_CHAN_NO, DEVCHK_NET_CAPA, NETWORK_4G_REBOOT_SUP))
	{
		int hikio_fd = -1;
		hikio_fd = hwif_get_io_handle(); /* ��ȡHIKIO������ */
		if (hikio_fd < 0)
		{
			LTE4G_DEBUG(RT_ERROR, "dial_entry: Get Hikio Fd failed\n");
			return;
		}
		
		LTE4G_DEBUG(RT_ERROR, "restart the 4G module\n");
		
		//��������4Gģ���gpio�ܽ�
		(void)gpio_set_value(hikio_fd, MOBILE_PWEN_GPIO_NUM, 0);
		//�ϵĵ�Դ����,оƬ���𺦷���,�µĵ�Դ����,��Ϊģ�鱣��10s(�����ݸ���ĵ���ʱ��),����2s����.
		sleep(10);
		(void)gpio_set_value(hikio_fd, MOBILE_PWEN_GPIO_NUM, 1);
		//ģ���ʼ����Ҫ17s���ң�20s�Ƚϱ���
		sleep(20);
	}
#endif

	

	/*��һ���µĽ���������3G/4G����*/
	(void)callSystemCmd("/home/diald &");
	
	// 3G/4G���ű������Զ����߿����߳�
	if (pthreadSpawn(NULL, COMMON_PRIO, 4096, net_mobile_manage, 0) != 0)
	{
		LTE4G_DEBUG(RT_ERROR, "net_mobile_manage fail, errno = 0x%x\n", errno);
	}

	return;
}

/**@brief        send sms to specified number
 * @param[in]    the number and the message content
 * @param[out]   none
 * @return       0: OK; -1: failed;;
 */
int sendSms(SEND_SMS *p_sendSms)
{
	if(p_sendSms == NULL)
	{
		LTE4G_DEBUG(RT_ERROR, "input param error\n");
		return ERROR;
	}
	
	if (shareMemParam != NULL)
	{
		if (strlen((char*)(shareMemParam->sendSmsParam.phoneNum)) == 0)
		{
			bzero(shareMemParam->sendSmsParam.phoneNum, MAX_PHONE_NUM_LEN);
			bzero(shareMemParam->sendSmsParam.msg, 140);
			memcpy(shareMemParam->sendSmsParam.phoneNum, p_sendSms->phoneNum, MAX_PHONE_NUM_LEN);
			memcpy(shareMemParam->sendSmsParam.msg, p_sendSms->msg, 140);
		}
		else
		{
			LTE4G_DEBUG(KEY_WARN, "SMS send busy, write back to smsList, wait ...\n");
			return -2;
		}
		return OK;
	}

	return ERROR;
} 

/**@brief        free smsList
 * @param[in]    none
 * @param[out]   none
 * @return       none
 */
void mobile_free_smsList(void)
{
	struct MOBILE_SMS *p = NULL;
	struct MOBILE_SMS *q = NULL;

	if(pSmsList == NULL)
	{
		LTE4G_DEBUG(RT_ERROR, "input param error\n");
		return;
	}
	p = pSmsList;
	
	while(p!=NULL)
	{
		q = p;
		p = p->next;
		SAFE_FREE(q);
		g_sms_num--;
	}
} 
/**@brief		  take and remove the first node of smsList
 * @param[in]    none
 * @param[out]   none
 * @return	  none
 */
struct MOBILE_SMS *mobile_take_smsList(void)
{
	struct MOBILE_SMS *p = NULL;

	if(pSmsList == NULL)
	{
		return NULL;
	}
	
	p = pSmsList;
	pSmsList = p->next;
	return p;
} 
/**@brief        ɾ�������ڴ�
 * @param[in]    pdata: ָ�����ڴ�
 * @param[out]   none
 * @return       none
 */
/* static BOOL delSeg(SHM_PARAM **pdata) */
/* { */
/* 	struct shmid_ds buf; */
/* 	 */
/* 	if(g_shmid<0 || pdata == NULL) */
/* 	{ */
/* 		LTE4G_DEBUG(RT_ERROR, "input param error\n"); */
/* 		return ERROR; */
/* 	} */
/* 	 */
/* 	if(0!=shmctl(g_shmid, IPC_STAT, &buf)) */
/* 	{ */
/* 		LTE4G_DEBUG(RT_ERROR, "shmctl IPC_STAT"); */
/* 	} */
/* 	 */
/* 	if(0!=shmdt(*pdata)) */
/* 	{ */
/* 		LTE4G_DEBUG(RT_ERROR, "shmdt"); */
/* 	} */
/* 	 */
/* 	if(0!=shmctl(g_shmid, IPC_RMID, &buf)) */
/* 	{ */
/* 		LTE4G_DEBUG(RT_ERROR, "shmctl IPC_RMID"); */
/* 	} */
/*  */
/* 	*pdata = NULL; */
/* 	return TRUE; */
/* } */

/**@brief		  remove the earlist message node from the list
 * @param[in]    none
 * @param[out]   none
 * @return	  none
 */
void mobile_delNode_smsList(void)
{
	struct MOBILE_SMS * p = NULL;
	
	p = pSmsList;
	if (p != NULL)
	{
		pSmsList = p->next;
		SAFE_FREE(p);
		g_sms_num--;
	}

	return;
}


/**@brief           add a node into smsList
 * @param[in]       p:�����͵Ķ���
 * @param[out]      none
 * @return          none
 */
void mobile_add_smsList(struct MOBILE_SMS *p)
{
	struct MOBILE_SMS *q = NULL;

	if(p == NULL)
	{
		LTE4G_DEBUG(RT_ERROR, "input param error\n");
		return;
	}
	
	p->next = NULL;
	g_sms_num++;
	if (pSmsList == NULL)
	{
		pSmsList = p;
		return;
	}

	q = pSmsList;
	while(q != NULL)
	{
		if(q->next == NULL)
		{
			break;
		}
		q = q->next;
	}
	if(q != NULL)
	{
		q->next = p;
	}
}


/**@brief        adds a message into the list
 * @param[in]    szPhoneNum:���ն��ŵĺ���
 * @param[in]    szContent:���ŵ�����
 * @param[out]   none
 * @return       OK/ERROR
 */
int mobile_add_sms(const char *szPhoneNum, const char *szContent)
{
	struct MOBILE_SMS *pNewSms = NULL;
	
	if (NULL == szPhoneNum || NULL == szContent || strlen(szContent) > MAX_SMS_LEN)
	{
		LTE4G_DEBUG(RT_ERROR, "input param error\n");
		return ERROR;
	}
	
	while (g_sms_num >= MAX_SMS_INLIST)
	{
		LTE4G_DEBUG(RT_ERROR, "SMS list overflow = %d\n",g_sms_num);
		mobile_delNode_smsList();
	}

	LTE4G_DEBUG(DEBUG_INFO, "Now SMS num in list = %d\n",g_sms_num);
	
	pNewSms = (struct MOBILE_SMS *)malloc(sizeof(struct MOBILE_SMS));
	if(pNewSms!=NULL)
	{
		bzero((char *)pNewSms, sizeof(struct MOBILE_SMS));
		memcpy(pNewSms->struSms.phoneNum, szPhoneNum, MAX_PHONE_NUM_LEN);
		strcpy((char*)(pNewSms->struSms.msg), szContent);
		mobile_add_smsList(pNewSms);
		return OK;
	}
	else
	{
		LTE4G_DEBUG(RT_ERROR, "malloc error\n");
		return ERROR;
	}
}
 
/**@brief		  Get phone number in white list.
 * @param[in]    white list sequence
 * @param[out]   none
 * @return	  phone number in white list.
 */
PHONE_CFG *get_whitelist_phoneNum(int num)
{
	if(num > MAX_WHITELIST_NUM || num < 0)
	{
		return NULL;
	}
	
	return &(pDevCfgParam->struSmsParam.phone[num]);
}

/**@brief         get log information from dial process, and record it
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
void getdialLog(void)
{
	int i = 0;
	int bNewLog = 0;
	UINT32 minorType = 0;	
	char szUserName[32] = {0};
	SMS_OPER * pSmsLog = NULL;
	CALL_OPER * pCallLog = NULL;
	LOG_OPERATION_INFO log_operation_info;
	char szParam[MAX_DIALLOG_LEN] = {0};

	if(shareMemParam == NULL)
	{
		LTE4G_DEBUG(RT_ERROR, "input param error\n");
		return;
	}

	for (i = 0; i < MAX_DIALLOG_NUM; i++)
	{
		if (shareMemParam->LogInfo[i].bHasLog == 1)
		{
			switch(shareMemParam->LogInfo[i].byOper)
			{
			case LOG_OPER_SMS:
				memcpy(szParam, shareMemParam->LogInfo[i].szParam, sizeof(SMS_OPER));
				minorType = MINOR_SMS_CONTROL;
				pSmsLog = (SMS_OPER *)szParam;
				memcpy(szUserName, pSmsLog->szPhoneNumber, sizeof(szUserName));
				bNewLog = 1;
				break;

			case LOG_OPER_CALL:
				memcpy(szParam, shareMemParam->LogInfo[i].szParam, sizeof(CALL_OPER));
				minorType = MINOR_CALL_ONLINE;
				pCallLog = (CALL_OPER *)szParam;
				memcpy(szUserName, pCallLog->szPhoneNumber, sizeof(szUserName));
				bNewLog = 1;
				break;
			case LOG_OPER_REBOOT:
				memcpy(szParam, shareMemParam->LogInfo[i].szParam, sizeof(CALL_OPER));
				minorType = MINOR_SMS_REBOOT;
				pCallLog = (CALL_OPER *)szParam;
				if(OK == mobile_check_phoneNum_is_startWith_86((INT8*)pCallLog->szPhoneNumber))
				{
					//Phone number start with "+"
					memcpy(szUserName, (char*)&(pCallLog->szPhoneNumber[2]), 
						MIN(sizeof(szUserName) - 2, strlen((char *)&(pCallLog->szPhoneNumber[2]))));
				}
				else
				{
					memcpy(szUserName, pCallLog->szPhoneNumber, sizeof(szUserName));
				}
				bNewLog = 1;
				break;
			default:
				break;
			}
			shareMemParam->LogInfo[i].bHasLog = 0;
		}

		if (bNewLog)
		{
			// д��־��Ϣ
			memset(&log_operation_info, 0, sizeof(LOG_OPERATION_INFO));			
			memcpy(log_operation_info.usrname, szUserName, sizeof(log_operation_info.usrname));
			write_operation_log(MAJOR_OPERATION, minorType, &log_operation_info, NULL);
			bNewLog = 0;
		}
	}

	return;
}

/**@brief         ����������ӿ�
 * @param[in]     cmd:��������
 * @param[out]    none
 * @return        OK:0,ERROR:-1
 */
UINT32 process_sms_cmd(UINT8 cmd)
{
	if(cmd >= MAX_SMS_CMD)
	{
		LTE4G_DEBUG(RT_ERROR, "process_sms_cmd param error, cmd = %d\n", cmd);
		return ERROR;
	}	

	switch(cmd)
	{
		case SMS_CMD_ARM:
		
			// ����
			(void)UniNetIF_SetArmStatus(1, 0);
			break;

		case SMS_CMD_DISARM:
		
			// ����
			(void)UniNetIF_SetArmStatus(0, 0);
			break;

		/* �˴���������������������� */

		default:
			LTE4G_DEBUG(RT_ERROR, "process_sms_cmd failed, cmd = %d\n", cmd);
			break;
	}

	return OK;
}

int getNameByPid(pid_t pid, char* task_name){

	if(pid <= 0 || !task_name){
		return ERROR;
	}
    char proc_pid_path[32];
    char buf[32];
	FILE* fp = NULL;

	memset(proc_pid_path, 0, sizeof(proc_pid_path));
	memset(buf, 0, sizeof(buf));
	
    sprintf(proc_pid_path, "/proc/%d/status", pid);
    fp = fopen(proc_pid_path, "r");
    if(NULL != fp){
		/**
		 ��ȡһ��,�ж��Ƿ���diald����
		 # cat /proc/357/status 
		 Name:   diald
		*/
        if(NULL == fgets(buf, 32, fp)){
            fclose(fp);
			return ERROR;
    	}
	    fclose(fp);
	    sscanf(buf, "%*s %s", task_name);
    }else{
		return -2;
	}
	return OK;
}

int mobile_check_diald_exist(SHM_PARAM* shareMemParam){
	
	#define DIALD_NAME "diald"
	
	int ret = ERROR;
	char process_name[32];
	memset(process_name, 0, sizeof(process_name));

	//pid������ֱ�ӷ��ش���,���ڼ���Ƿ���diald����
	ret = getNameByPid(shareMemParam->pid, process_name);
	if(-2 == ret){ 
		LTE4G_DEBUG(RT_ERROR, "getNameByPid Error, diald not alive, restart!\n");
		return ERROR;
	}else if(OK == ret){
		if(0 == memcmp(DIALD_NAME, process_name, strlen(DIALD_NAME))){
			LTE4G_DEBUG(RT_ERROR, "diald is alive now\n");
		}else{
			LTE4G_DEBUG(RT_ERROR, "diald not alive, need to restart\n");
			return ERROR;
		}
	}
	return OK;
}


/**@brief         3G networks task
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
void net_mobile_manage(void)
{
	struct MOBILE_SMS *pCurSms=NULL;	// �ڲ�����: [�绰���� + ������Ϣ] + [ָ����һ�����ŵ�ָ��]
	
	setPthreadName("ipc_4g_manage");	
	pSmsList = NULL;						// ָ�������������ͷ���
	BOOL start_now = FALSE;
	BOOL reboot_after_upgrade = FALSE;

	struct   tm *ptm; 
	time_t   t	= 0; 	
	int 	 h  = 0; 
	int 	 m  = 0;
	int		 d  = 0;
	
	LTE4G_DEBUG(DEBUG_INFO, "\n net_mobile_manage start... \n");

	while(1)
	{
		if(shareMemParam->usb_power_reset)
		{
			mobile_usb_power_reset();
			shareMemParam->usb_power_reset = FALSE;
		}
		//4Gʹ�ܵ������,�ж��Ƿ���û��,����ģ���Ҳ���,����SIM��û�ź�,��д�쳣
		if (pDevCfgParam->struDialCfg.byEnableMobile){
			t   =   time(NULL); 
			ptm  =   localtime(&t); 
			h    =   ptm->tm_hour;              
			m    =   ptm->tm_min;

			if(d != ptm->tm_mday)
			{
				shareMemParam->net_search_num = 0;
				d = ptm->tm_mday;
			}
			do{
				if((h != 0) || (m > 30)){// 00:00 -00:30���
					break;
				}
				//4G �����������Ϊ���������˳��Ͳ���Ҫ����
				if(shareMemParam->realMobileStat.sys_sim_status == SIM_NOTEXIST){
					LTE4G_DEBUG(RT_ERROR, "Diald Stat SIM_NOTEXIST\n");
					//	break;
				}
				if(OK != mobile_check_diald_exist(shareMemParam)){		
					(void)callSystemCmd("/home/diald &");
				}
				sleep(1);
			}while(0);
		}
		
		// sending the sms. we take only 1 messeage per time
		pCurSms=mobile_take_smsList();	//���е�һ���������Ž�㲢����֮

		if(pCurSms!=NULL)
		{
			LTE4G_DEBUG(DEBUG_INFO, "send a sms to whiteList\n");
			if(0 != sendSms(&(pCurSms->struSms)))	//sendSms: ������Ͷ��ſ����������ڴ�
			{
				// send failed, make him still the first node
				// ����ʧ�ܣ���[Ԥ������] �Ż�[������������]��
				pCurSms->next = pSmsList;
				pSmsList = pCurSms;		//ע: pSmsListΪ�����Ͷ�������ͷ���

				// ���ŷ��ͷ�æ��˯��2�룬��ֹƵ����ӡ��ʾ��Ϣ
				sleep(2);
			}
			else
			{
				// send ok
				SAFE_FREE(pCurSms);
				g_sms_num--;
			}
		}
	
		// ͳһ3G������Davince���̵����ԣ�3G�������ź����ж�
		shareMemParam->language = pDevCfgParam->language;

		// �ж��Ƿ�����Ҫ�����Ķ�������
		if(shareMemParam->sms_cmd != SMS_CMD_NONE)
		{
			// ���������
			process_sms_cmd(shareMemParam->sms_cmd);

			// ���ִ����Ķ�������
			shareMemParam->sms_cmd = SMS_CMD_NONE;
		}

		//������ֵ�ǰ����Ӫ�̺���һ�εĲ�һ������4G�����л�Բ��ŵĲ���������գ���������������±������ݿ�
		if(former_operator != comm_param->struDialCfg.mobile_operator 
			||shareMemParam->sms_receipt_operation != pDevCfgParam->struSmsParam.sms_receipt_operation) //������������仯���򱣴����ݿ⣬����Ҫ�������ݿ�
		{
			pthreadMutexLock(&g_param_mutexsem, WAIT_FOREVER);
			memcpy(&pDevCfgParam->struDialCfg, &comm_param->struDialCfg, sizeof(DIAL_CFG));
			pDevCfgParam->struSmsParam.sms_receipt_operation = shareMemParam->sms_receipt_operation;
			#ifdef DB_PROCESS
			(void)db_send_data_to_database(EN_DB_SAVE_4G_LTE_CONFIG, NULL);
			#else
			save_4g_lte_config();
			#endif
			pthreadMutexUnlock(&g_param_mutexsem);
			former_operator = comm_param->struDialCfg.mobile_operator;
		}

		/* ��ѯ��־��Ϣ��д��־ */
		getdialLog();

		//��¼�Ƿ�������,Ĭ�Ͽؼ������������
		if(reboot_after_upgrade != TRUE)
		{
			 reboot_after_upgrade = is_upgrading();
		}
		//�ȼ�¼��־���ٲ�ѯ�Ƿ���Ҫ����
		if(TRUE == shareMemParam->is_need_reboot) 
		{
			//����Ҫ����֮���ٽ���������ѭ�����������յ�����պ���Ҫ�������Ӷ�������־����Ϣû�м�¼��
			if(FALSE == start_now)
			{
				start_now = TRUE;
				continue;
			}
			else
			{
				while(UniNetIF_CanbeReboot() != TRUE )
				{
					sleep(1);
				}
				if(FALSE == reboot_after_upgrade)
				{
					UniNetIF_RebootDev(FALSE, 0); 
				}
			}
		}

		//usleep(40 * 1000);
		sleep(1);
	}

}
 
/**@brief         check the phone number is legal. 
 * @param[in]     point to the phone number;
 * @param[out]    none
 * @return        0:OK,-1:ERROR
 */
int check_is_legal_phoneNum(char * p_phone_num)
{
	int len = 0;
	int ret = ERROR;
	
	if(NULL == p_phone_num)
	{
		LTE4G_DEBUG(RT_ERROR, "check_is_legal_phoneNum: Input Argument error!\n");
		return ERROR;
	}

	len = strlen(p_phone_num);

	//Ŀǰ���볤��֧�֣�11λ��13λ(��86��ͷ)��14λ(��+86��ͷ)
	switch(len)
	{
		case 11:
			ret = mobile_check_is_num(p_phone_num);
			break;
		case 13:
			ret = mobile_check_phoneNum_is_startWith_86(p_phone_num);
			break;
		case 14:
			if(p_phone_num[0] != '+')
			{
				ret = ERROR;
			}
			else
			{
				ret = mobile_check_phoneNum_is_startWith_86(p_phone_num+ 1);
			}

			break;
		default:
			LTE4G_DEBUG(RT_ERROR, "The length of phone number error, %d \n", len);
			return ERROR;
	}

	if(ret != OK)
	{
		LTE4G_DEBUG(RT_ERROR, "check_is_legal_phoneNum: illegal phone num: %s \n", p_phone_num);
	}
	
	return ret ;
}

#define HAL_CTRL_USB_POWER  _IOW(HIKIO_IOC_MAGIC, 20, unsigned int *)

UINT32 mobile_usb_power_reset(void)
{  
	//������ʱ���ӿ�,5.4.16 R2��ʹ��
#if 0
	LTE4G_DEBUG(RT_ERROR, "USB_POWER_RESET start...\n");
	int hikio_tmp_fd = -1;
	unsigned int tmp = 0;
	int ret = -1;
	hikio_tmp_fd = hwif_get_io_handle();	/* ��ȡHIKIO������ */
	if (hikio_tmp_fd < 0){
		LTE4G_DEBUG(RT_ERROR, "Get Hikio Fd failed.\n");
		return ERROR ;
	}			
	ret = ioctl(hikio_tmp_fd, HAL_CTRL_USB_POWER, &tmp);/*0 �ضϵ�Դ */
	if(ret < 0)
		LTE4G_DEBUG(RT_ERROR,"HAL_CTRL_USB_POWER off error: %d \n", ret);
	sleep(10);
	tmp = 1;
	ret = ioctl(hikio_tmp_fd, HAL_CTRL_USB_POWER, &tmp);/*1 �򿪵�Դ */
	if(ret < 0)
		LTE4G_DEBUG(RT_ERROR,"HAL_CTRL_USB_POWER on error:%d\n", ret);

	LTE4G_DEBUG(RT_ERROR, "USB_POWER_RESET end...\n");
#endif	
	return OK;
}

 
