/**@file net_3g_modem.h
 * @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 * @brief  
 * 
 * @author   liuqi yanghongwen
 * @date     2012-11-19
 * @version  4.0
 * 
 * @note ///Description here
 * @note History:        
 * @note     <author>   <time>    <version >   <desc>
 * @note  liuqi yanghongwen 2012/11/19 4.0 �����ļ�
 * @warning  
 */

#ifndef _NET_3G_MODEM_H_
#define _NET_3G_MODEM_H_ 

#include <sys/wait.h>
#include <sys/sysinfo.h>
#include "netcommand.h"
#include "unihardwareif.h"
#include "dvrNet.h"
#include "netprocItf.h"
#include <pthread.h>
#include <sys/prctl.h>
#include "configTypes.h"
#include <sys/shm.h>

 
#define MAX_SMS_LEN	140

 /* ����״̬ */
#define SMSSTAT_NOCHANGE_ALLREAD		0
#define SMSSTAT_NOCHANGE_SOMEREAD		3
#define SMSSTAT_CHANGE_ALLREAD			1
#define SMSSTAT_CHANGE_SOMEREAD			4
#define SMSSTAT_CHANGE_NEWSMS			2

/* ���ŷ��ͽ�� */
#define SMS_SEND_OK 0x06	///< ���ŷ��ͳɹ�
#define SMS_SEND_ER 0x18	///< ���ŷ���ʧ��

/* �û�����ħ���� */
#define USER_SMS_H 0x1e;
#define USER_SMS_L 0x0d;


 /* PIN��״̬ */
#define PIN_EXCUTE_OK			1
#define PIN_EXCUTE_FAILED		-1
#define PIN_EXCUTE_INCORRECT	-2
#define PIN_EXCUTE_OVERTIME		-3
#define PIN_EXCUTE_PINLENZERO	-4
#define PIN_EXCUTE_NEWPINZERO	-5
 
#define EXIT_DIAL_TASK			255
#define WAIT_MANUAL_RESTART		254

//#define MAX_IPCHANNUM 			32		///< ���IPC��
#define MAX_VER_LEN 			48		///< �汾��Ϣ��󳤶�

#define MIN_EXCEPTION	HARDDISKFULL_EXCEPTION
#define MAX_EXCEPTION	(MAX_EXCEPTION_TYPE - 1)

#define NET_HEAD_MIGIC		0xd7c9cEc4	///< ע���ͷħ���֣��ַ���"WIND" 
#define NET_HEAD_VER		0x01		///< ע��汾�ţ�V0.1 

#define MAX_PIN_LEN 12					///< ���PIN�볤��



#ifndef IMPORT
#define IMPORT	extern
#endif

#ifndef min
#define min(a, b) ((a) > (b) ? (b) : (a))
#endif

#define LTE4G_DEBUG(level, arg...) dev_debug(level, MOD_NETFUN_MOBILE, ##arg)

#if 0
/**@brief ʵʱģʽ
 */
typedef enum
{
	/* evdo */
	RMODE_CDMA1X = 12,			///< CDMA 1x
	RMODE_EVDO = 14,			///< EVDO
	RMODE_CDMAHYBRID = 18,		///< CDMA HYBRID
	/* wcdma */
	RMODE_GSM = 21,				///< GSM
	RMODE_GPRS = 22,			///< GPRS
	RMODE_EDGE = 23,			///< EDGE
	RMODE_WCDMA = 24,			///< WCDMA
	RMODE_HSDPA = 25,			///< HSDPA
	RMODE_HSUPA = 26,			///< HSUPA
	RMODE_HSPA = 27,			///< HSPA
	/* tdscdma */
	RMODE_TGSM = 31,			///< GSM
	RMODE_TGPRS = 32,			///< GPRS
	RMODE_TEDGE = 33,			///< EDGE
	RMODE_TDSCDMA = 34,			///< TDSCDMA
	RMODE_TDHSDPA = 35,			///< TD-HSDPA
	RMODE_TDHSUPA = 36,			///< TD-HSUPA
	RMODE_TDHSPA = 37			///< TD-HSPA
}REAL_MODE;
#endif

/**@brief UIM ����Ϣ
 */
typedef enum
{
	UIM_UNKNOWN = 0,	///< δ֪ 
	UIM_VALID = 1,		///< ��Ч 
	UIM_NOVALID = 4,	///< ��Ч 
	UIM_ROAM = 11,		///< ���� 
	UIM_NOEXIST = 255	///< �޿�
}UIM_INFO;

/**@brief PPPD����У�鷽ʽ
 */
typedef enum
{
	VERIFY_AUTO = 0,	///< �Զ�У�鷽ʽ 
	VERIFY_CHAP = 1,	///< CHAPУ�鷽ʽ 
	VERIFY_PAP = 2,		///< PAPУ�鷽ʽ
}PPPD_VERIFY;

/**@brief PIN��״̬
 */
typedef enum
{
	PIN_ENABLE = 1,
	PIN_DISABLE = 2,
	PIN_VERIFY = 3,
	PUK_VERIFY = 4,
	PIN_CHANGE = 5
}PIN_CMD;


/**@brief UIM��ʹ��ģʽ״̬
 */
typedef enum
{
	MODEM_USE_OK = 0,			///< UIM card has found
	MODEM_USE_PPPOEOPEN = 1,	///< PPPoE is enabled
	MODEM_USE_NOTFIND = 2,		///< not find the wireless modem
	MODEM_USE_INITING = 3,		///< UIM card unknow
	MODEM_USE_NOUIM = 4			///< no UIM card
}MODEM_USE;


/**@brief ƽ̨��Ϣ
 */
typedef enum
{
	PLATFORM_NET3G = 0,
	PLATFORM_EHOME = 1,
	PLATFORM_OTHER = 2,
}PLATFORM_TYPE;

/**@brief ƽ̨ѡ������
 */
typedef struct
{
	UINT8	byPlatForm;				///< choose which platform to use
	UINT8	res[3];
	IPADDR_PARAM_T struIp;
	UINT32 nPort;
	char	szPuid[NAME_LEN];		///< pu id
	char	szPasswd[PASSWD_LEN];	///< password
	/* other platform parameters can be added here */
}MENU_PLATFORM_CFG;


/**@brief ����������
 */
typedef struct
{
	PHONE_CFG phone[MAX_WHITELIST_NUM];
	UINT8 bEnableSmsAlarm;
	UINT8 res[3];
	
}MENU_3G_WHITELIST_CFG;


/**@brief ģʽ�汾��Ϣ
 */
typedef struct
{
	char szManufacturer[MAX_VER_LEN];	///< manufacturer
	char szImeiNum[MAX_VER_LEN];		///< IMEI number */
	char szFirmVer[MAX_VER_LEN];		///< softversion */
	char szImsiNum[MAX_VER_LEN];		///< IMSI number */
	char szModemName[MAX_VER_LEN];		///< modem name */
	char szHardVer[MAX_VER_LEN];		///< hardware version */
	char szHardSn[MAX_VER_LEN];			///< hardware sn */
}MODEM_VERSION;

/**@brief �쳣��Ϣ�ṹ
 */
typedef struct
{
	UINT8		deviceName[NAME_LEN];	///< �豸����
	UINT32		iExceptionType;			///< �쳣����	
	time_t		iEventTime;				///< �쳣����ʱ��
}NET3G_SMS_EXCEPTINFO;

/**@brief �����������
 */
struct MOBILE_SMS
{
	SEND_SMS struSms;
	struct MOBILE_SMS *next;
};

/**@brief �ṹͷ�����ýṹ
 */
typedef struct
{
	UINT16 nLength;		///< �ṹ����
	UINT8 byVersion;	///< �ߵ�4λ�ֱ�����ߵͰ汾���������ݰ汾�ͳ��Ƚ�����չ����ͬ�İ汾�ĳ��Ƚ�������
	UINT8 byRes;
}NET_STRUCTHEAD;

/**@brief COMMAND & RESPONSE Header 
 */
typedef struct
{
	UINT32  iLength;		///< total length
	UINT8   ifVer;			///< version: 90 -- new interface/60 -- old interface/30--3g interface
	UINT8   ipVer;			///< 1: IPv6, 0: IPv4
	UINT8   byRetVal;		///< just used in RESPONSE
	UINT8   byCmdType;		///< ���λ��ʾ�������ͣ�REQUEST(0)��RESPONSE(1)������7λ����
	UINT32 iCheckSum;		///< checksum 
	UINT32 iNetCmd;			///< command
	UINT32 clientIp;		///< clinet IP address
	int	    iUserID;		///< User ID or Device ID 
	UINT8 sMacAddr[MACADDR_LEN];
	UINT8 res3[2];
#ifdef SUPPORT_IPV6_PUSHSDK
	struct in6_addr clientIp6;
#endif
}NET_3GCMD_HEADER_T;


/**@brief ����״̬��ȡ�����ýṹ
 */
typedef struct
{
	NET_3GCMD_HEADER_T struHeader;
	UINT8 byConnNum;		///< the index of the wireless modem
	UINT8 byNetType;		///< specify which networks type��0: auto; 1: CDMA; 2: EVDO; 3: WCDMA; 4: TD-SCDMA
	UINT8 res[6];
}NET_3GCMD_GET_DIAL_CFG_T;


/**@brief PIN��״̬�����ýṹ
 */
typedef struct
{
	NET_STRUCTHEAD struHead;
	UINT8 byStatus;		///< PIN status, defination see enum: PIN_READY
	UINT8 byPinTimes;	///< remain input PIN times
	UINT8 byPukTimes;	///< remain input PUK times	
	UINT8 bEnableLock;	///< now the PIN locking function is enabled or not: 0, not enabled lock; 1, lock enabled
	UINT8 byRes[4];
}PIN_STATUS;


/**@brief PIN����������ýṹ
 */
typedef struct
{
	NET_STRUCTHEAD struHead;
	UINT8 byPinCmd;						///< PIN command, defination see enum: PIN_CMD
	UINT8 byRes1[3];
	UINT8 byPinCode[MAX_PIN_LEN];		///< pin/puk code
	UINT8 byNewPinCode[MAX_PIN_LEN];	///< new pin code
	UINT8 byRes2[16];
}PIN_OPER;


/**@brief PIN��״̬��Ӧ�����ýṹ
 */
typedef struct
{
	NETRET_HEADER struHeader;
	PIN_STATUS struPinStatus;
}NET_3GCMD_PIN_STATUS_T;


/**@brief Զ��PIN����������ýṹ
 */
typedef struct
{
	NET_3GCMD_HEADER_T struHeader;
	PIN_OPER struPinCmd;
}NET_3GCMD_PINCMD_T;


/**@brief ���Ų��������ýṹ
 */
typedef struct
{
    NET_STRUCTHEAD struHead;
    UINT8 byEnableSmsAlarm;
    UINT8 byRes1[7];
    PHONE_CFG phone[MAX_WHITELIST_NUM];
    UINT8 byRes2[32];
}NET_3GCMD_SMS_PARAM_T;

/**@brief ���ö��Ų��������ýṹ
 */
typedef struct
{
    NETRET_HEADER struHeader;
    NET_3GCMD_SMS_PARAM_T struSms;
}NET_3GCMD_SMS_CFG_T;

/**@brief �����б������ýṹ
 */
typedef struct
{
	NET_STRUCTHEAD struHead;
	UINT32 iSmsNum;					///< ��������
	UINT8 byRes[8];
}NET_SMSLISTINFO;

/**@brief ʱ������ýṹ
 */
typedef struct
{
	UINT16 nYear;
	UINT8 byMonth;
	UINT8 byDay;
	UINT8 byHour;
	UINT8 byMin;
	UINT8 bySec;
	UINT8 byRes;
}NET_3GCMD_TIME_T;


/**@brief �����б����������ýṹ
 */
typedef struct
{
	UINT32 iSmsIdx;					///< �������
	UINT8 byStatus;					///< ����״̬
	UINT8 byRes[7];
	NET_3GCMD_TIME_T struRcvtime;	///< ����ʱ��
}NET_3GCMD_SMSPARAM_T;

/**@brief ����״̬�б����������ýṹ
 */
typedef struct
{
	NETRET_HEADER struHeader;
	NET_SMSLISTINFO smsListInfo;
	NET_3GCMD_SMSPARAM_T struSmsNetSend[MAX_SMSLIST_NUM];
}SMS_LIST_STAT;

/**@brief ����ʱ������ýṹ
 */
typedef struct
{
	NET_3GCMD_HEADER_T struHeader;
	NET_3GCMD_TIME_T struStartTime;
	NET_3GCMD_TIME_T struStopTime;
}NET_3GCMD_GET_SMSLIST_T;



/**@brief ������ŵ����ýṹ
 */
typedef struct
{
	NET_3GCMD_HEADER_T struHeader;
	UINT32 iSmsIdx;				///< �������
}NET_3GCMD_SMSCONTENT_T;

/**@brief �������ݵ����ýṹ
 */
typedef struct
{
	NET_STRUCTHEAD struHead;
	UINT8 szPhoneNum[MAX_PHONE_NUM_LEN];		///< �ֻ���
	UINT8 szSmsContent[SMS_CONTENT_LENGTH];	///< ��������
}NET_SMSCONTENT_INFO;

/**@brief �������ݻ�Ӧ�����ýṹ
 */
typedef struct
{
	NETRET_HEADER struHeader;
	NET_SMSCONTENT_INFO struSmsContent;
}NET_3GCMD_SMSCONTENT_RESP_T;


/**@brief ���Ͷ��ŵ����ýṹ
 */
typedef struct
{
	NET_3GCMD_HEADER_T struHeader;
	UINT8 szPhoneNum[MAX_PHONE_NUM_LEN];
	UINT8 szMsg[SMS_CONTENT_LENGTH];
}NET_3GCMD_SMS_SEND_T;

typedef enum
{
	M_U7500		= 1,
	M_C7500		= 2,
	M_U8300		= 3,
	M_LM91XX	= 4,
	M_HUAWEI_3G	= 5,
	M_HUAWEI_4G	= 6,
	M_UNKNOWN,
}MODEL_IDX;

#define SHMKEY		(key_t)0x100
#define IFLAGS		(IPC_CREAT | IPC_EXCL)
#define SHM_ERR		((COMMUNICATION_PARAM *)-1)


unsigned long tickGet(void);
int addAtcomToBuf(char * line);
int startMobileTask(void);
int stopMobileTask(void);

BOOL getDialStatus(void);
 
void resumeDial(void);
void pauseDial(void); 
void shm_copy_whitelist(UINT8 * pBuf);
void net_mobile_manage(void);
void dial_entry(DEVICECONFIG* pDevCfgParam);
int getModemVer(MODEM_VERSION * pModemVer);
int mobile_check_phone_num(char * pNum);
int get_sms_send_result();
int clean_sms_send_result();
int net_is_phone_num(char * p_phone_num);

// 3Gͳһ�ӿ�
UINT32 net_3g_get_whitelist(NET_3GCMD_SMS_PARAM_T *p_whitelist);
UINT32 net_3g_set_whitelist(NET_3GCMD_SMS_PARAM_T *p_whitelist);
UINT32 net_3g_get_smslist(NET_3GCMD_TIME_T *p_start_time, NET_3GCMD_TIME_T *p_stop_time, NET_3GCMD_SMSPARAM_T *p_sms_list_stat);
UINT32 net_3g_recv_sms(int index, SMS_LIST_2 * p_sms);
UINT32 net_3g_send_sms(SEND_SMS * pSendSms);
UINT32 net_3g_get_pinstat(PIN_STATUS * p_pin_stat);
UINT32 net_3g_set_pin(PIN_OPER *p_pin_cmd);
UINT32 net_3g_connect();
UINT32 mobile_network_disconnect();
UINT32 mobile_get_modeInfo(MODEM_VERSION *mode_info);
UINT32 mobile_usb_power_reset(void);


 
#endif	/* #ifndef _NET_3G_MODEM_H_ */

