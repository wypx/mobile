#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <string.h>
#include "hik_mod_oper.h"


/**@fn            filename2modname
 * @brief         convert the filename which contains "/" and "." to module name
 * @param[in]     const char *filename: point to the filename buffer
                  int len: the length of filename buffer                  
 * @param[out]    char *modname: point to the modem name buffer
 * @return        none
 */
static inline void filename2modname(const char *filename, int len, char *modname)
{
	int i;
	char *afterslash = NULL;

	if (modname == NULL || filename == NULL)
	{
		DBG_PRT_HIK(("modname or filename null\n"));
		return;
	}

	afterslash = strrchr(filename, '/');
	if (!afterslash)
	{
		afterslash = (char *)filename;
	}
	else
	{
		afterslash++;
	}
	/* Convert to underscores, stop at first . */
	for (i = 0; afterslash[i] && afterslash[i] != '.' && i < (len - 1); i++)
	{
		if (afterslash[i] == '-')
		{
			modname[i] = '_';
		}
		else
		{
			modname[i] = afterslash[i];
		}
	}
	modname[i] = '\0';
	return;
}

/**@fn            hik_rmmod
 * @brief         rmmod
 * @param[in]     char * module_name: the point to the module name buffer
                  int mode: MODE of rmmod operation
 * @param[out]    none
 * @return        -1: error; 0: ok
 */
int hik_rmmod(char * module_name, int mode)
{
	unsigned int flags = O_NONBLOCK|O_EXCL;
	long int lRet;
	char szName[128] = {0};
	int iFileLen = 0;

	if (module_name == NULL)
	{		
		DBG_PRT_HIK(("filename null\n"));
		return -1;
	}
	iFileLen = strlen(module_name);
	if (iFileLen >= 128 || iFileLen == 0)
	{
		DBG_PRT_HIK(("filename length error: %d\n", iFileLen));
		return -1;
	}

	if((mode & RMMOD_MODE_WAIT))	// --wait
	{
		flags &= ~O_NONBLOCK;
	}
	if((mode & RMMOD_MODE_FORCE))	// --force
	{
		flags |= O_TRUNC;
	}

	filename2modname(module_name, iFileLen, szName);
	lRet = syscall(__NR_delete_module, szName, flags);
	if (lRet != 0)
	{
		DBG_PRT_HIK(("cannot rmmod %s: 0x%x\n", module_name, errno));
		return -1;
	}
	return 0;
}

/**@fn            hik_insmod
 * @brief         insmod
 * @param[in]     char * module_name: the point to the module name buffer
 * @param[out]    none
 * @return        -1: error; 0: ok
 */
int hik_insmod(char * module_name)
{
	int fd;
	struct stat st;
	unsigned long len;
	void *map = NULL;
	int iRet = -1;
	long int lRet;
	char option[2] = {0};

	if (module_name == NULL)
	{		
		DBG_PRT_HIK(("filename null\n"));
		return -1;
	}
	fd = open(module_name, O_RDONLY, 0);
	if (fd == -1)
	{
		DBG_PRT_HIK(("open %s failed: 0x%x\n", module_name, errno));
		return -1;
	}
	iRet = fstat(fd, &st);
	if (iRet == -1)
	{
		close(fd);		
		DBG_PRT_HIK(("fstat %s failed: 0x%x\n", module_name, errno));
		return -1;
	}

	len = st.st_size;
	map = mmap(NULL, len, PROT_READ, MAP_PRIVATE, fd, 0);
	if (map == MAP_FAILED)
	{
		close(fd);		
		DBG_PRT_HIK(("cannot mmap %s: 0x%x\n", module_name, errno));
		return -1;
	}
	strcpy(option, " ");
	lRet = syscall(__NR_init_module, map, len, option);
	if (lRet != 0)
	{
		munmap(map, len);
		close(fd);		
		DBG_PRT_HIK(("cannot insert %s: 0x%x (%li)\n", module_name, errno, lRet));
		return -1;
	}
	munmap(map, len);
	close(fd);

	return 0;
}
#if 0
int main(int argc, char ** argv)
{
	hik_insmod(argv[1]);
	hik_rmmod(argv[1], RMMOD_MODE_NONE);
	return 0;
}
#endif
