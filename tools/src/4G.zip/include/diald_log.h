/**@file diald_log.h
 * @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 * @brief  
 * 
 * @author   luotang
 * @date     2016-10-20
 * @version  1.0
 * 
 * @note ��4Gģ����־��Ϣ��¼��flash��
 * @note History:        
 * @note     <author>   <time>    <version >   <desc>
 * @note  
 * @warning  
 */
#ifndef _DIALD_LOG_MSG_
#define _DIALD_LOG_MSG_ 
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h> 
#include <fcntl.h>
#include <stdlib.h>    
#include <stdarg.h>
#include <time.h>
#include <sys/stat.h>
#include <pthread.h>
 
/* ���Ժ� */
#define LTE4G_DEBUG(level, arg...) dev_debug(level, MOD_NETFUN_MOBILE, ##arg) 
 
#if defined(R6_S2LM) || defined(G1_PLAT) ||defined (AM_S2) ||defined(H0_PLAT)
#define FLASH_LOG_DIR_NAME		"/config"
#elif defined(DM385) ||defined(DM8127) ||defined (R7_HI3516A) ||defined(G0_HI3516D) ||defined(E0_PLAT) ||(defined R2_PLAT)||defined(E3_PLAT) 
#define FLASH_LOG_DIR_NAME		"/devinfo"
#elif defined(H1_PLAT)||defined(H3_PLAT)
#define FLASH_LOG_DIR_NAME		"/davinci"
#endif 

#define DIALD_LOG_TITLE	 "[4G_LOG_INFO:%d]\n"
#define DIALD_LOG_FILE_SIZE (2 * 1024) 
#define DIALD_LOG_HEAD_LEN 	32   /* ��־��Ϣͷ���� */
 
#define	MAX_TIME_LEN 	32
#define MAX_DBGMSG_LEN 256 	 

 typedef enum { 
 	L_CLOSED, 
	L_OPENING, 
	L_OPEN, 
	L_ERROR 
 } Logstat;
/* log session to file stuff ... */
typedef struct dialdlog_t
{
	int		logfd;  
	Logstat	stat;
	pthread_mutex_t mutex;  
}DialdLOG;

#define snew(type) ((type *)malloc(sizeof(type)))
#define snewn(n, type) ((type *)malloc((n) * sizeof(type)))
#define sresize(ptr, n, type)                                         \
    ((type *)realloc(sizeof((type *)0 == (ptr)) ? (ptr) : (ptr),      \
                     (n) * sizeof(type)))
#define sfree(ptr) do { \
		if ((ptr) != NULL) { \
			free((ptr)); \
			(ptr) = NULL;} \
		} while(0) 

int	mobile_log_init(void);
int mobile_log_write(const char* errfmt, ...);

#endif

