#ifndef _HIK_MOD_OPER_H
#define _HIK_MOD_OPER_H

#ifndef DBG_PRT_HIK
#if 1
#define DBG_PRT_HIK(x)	printf x;
#else
#define DBG_PRT_HIK(x)
#endif
#endif

#define RMMOD_MODE_NONE     0x0
#define RMMOD_MODE_WAIT     0x1
#define RMMOD_MODE_FORCE    0x2

extern int hik_insmod(char * module_name);
extern int hik_rmmod(char * module_name, int mode);

#endif

