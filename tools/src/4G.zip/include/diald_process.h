#ifndef _DIALD_PROCESS_H_
#define _DIALD_PROCESS_H_

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>

#include "atcmd_handle.h"
#include "diald_main.h"
#include "dev_debug.h"

#define LTE4G_DEBUG(level, arg...) dev_debug(level, MOD_NETFUN_MOBILE, ##arg)
extern SHM_PARAM *shareMemParam;

typedef struct
{
	int modem_ppp_pid;
	BOOL modem_ppp_failed;
	char modem_ppp_name[32];
	char modem_ppp_pwd[32];
	char modem_ppp_telephone[32];
	int failed_times;
	int total_failed_times;
}PPP_PARAM;


#define modem_ppp_pid 		(ppp_param.modem_ppp_pid)
#define modem_ppp_failed  	(ppp_param.modem_ppp_failed)
#define modem_ppp_name		(ppp_param.modem_ppp_name)
#define modem_ppp_pwd		(ppp_param.modem_ppp_pwd)
#define modem_ppp_telephone	(ppp_param.modem_ppp_telephone)
#define failedTimes			(ppp_param.failed_times)
#define totalfailedTimes	(ppp_param.total_failed_times)		// �����ܹ����ֵĲ��Ų��ɹ�����

/* some fileds of sysinfo or sysinfoex */
/* get and set modem stat this way later */
#define mobile_dialStat		(shareMemParam->realMobileStat.dialProcessStat)
#define mobile_mode			(shareMemParam->realMobileStat.mode)
#define mobile_regStat		(shareMemParam->realMobileStat.regStatus)
#define mobile_reg2gInfo	(shareMemParam->realMobileStat.reg2gInfo)
#define mobile_reg3gInfo	(shareMemParam->realMobileStat.reg3gInfo)
#define mobile_reg4gInfo	(shareMemParam->realMobileStat.reg4gInfo)
#define mobile_signal		(shareMemParam->realMobileStat.signal)
#define mobile_sysCfg		(shareMemParam->realMobileStat.syscfg)
#define mobile_simStat		(shareMemParam->realMobileStat.sys_sim_status)
#define mobile_srvStat		(shareMemParam->realMobileStat.sys_srv_status)
#define mobile_srvDomain	(shareMemParam->realMobileStat.sys_srv_domain)

void initDial(void);
void resumeDial(void);
void pauseDial(void);
int  modem_finiPPP();

extern void dial_error_occur(int iCode);

/*��������*/

/**@brief         ��ȡģ��״̬
 * @param[in]     none
 * @param[out]    none
 * @return        MODEM_DIAL_STAT
 */
static inline MODEM_DIAL_STAT mobile_get_modem_stat(void)
{
	if(shareMemParam != NULL)
	{
		return mobile_dialStat;
	}
	else
	{
		return DIAL_SHMEM_ERROR;
	}
}


/**@brief         ����ģ��״̬
 * @param[in]     none
 * @param[out]    none
 * @return        none
 */
static inline void mobile_set_modem_stat(MODEM_DIAL_STAT currdialStat)
{
	if(shareMemParam != NULL)
	{
 		mobile_dialStat = currdialStat;
	}
} 

#endif /* _DIAL_H_ */

