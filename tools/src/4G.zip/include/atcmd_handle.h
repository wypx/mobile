#ifndef _ATCHANNEL_H_
#define _ATCHANNEL_H_

#include <sys/shm.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <pthread.h>
#include <sys/time.h>
#include <ctype.h>
#include <termios.h>
#include "pdu.h"
#include "lstLib.h"
#include <sys/ioctl.h>

#include "3g_4g_base.h"
#include "diald_main.h"
#include "dev_debug.h"

#define LTE4G_DEBUG(level, arg...) dev_debug(level, MOD_NETFUN_MOBILE, ##arg)

#define DEV_4G_USB        "/dev/ttyUSB1"  

#define MODULE_DONT_WORK	1
#define MODULE_NOT_EXIST	2

#define EP_TTYUSB		0		/* ttyUSB0~ttyUSB5 */
#define EP_TTYACM		1		/* ttyACM0~ttyACM2 */

#define LANGUAGE_CHN_SIMPL		2		/* ��������		*/

/*�ڷ���AT+CMEE ATָ��ʱ���ش�����Ϣ����*/
#define SIM_NOT_INSERTED		-10	//û�в���SIM��
#define SIM_PIN_REQUIRED		-11	//��ҪSIM����PIN��
#define SIM_PUK_REQUIRED		-12	//��ҪSIM����PUK��
#define SIM_FAILURE				-13	//SIM������
#define SIM_BUSY				-14	//SIM��æ
#define SIM_WRONG 				-15	//SIM������
#define INCORRECT_PASSWD		-16	//������Ч
#define SIM_PIN2_REQUIRED		-17	//��ҪSIM����PIN2��
#define SIM_PUK2_REQUIRED		-18	//��ҪSIM����PUK2��
#define MEMORY_FULL				-20	//�洢����


/* ���ŷ��ͽ�� */
#define SMS_SEND_OK 0x06	///< ���ŷ��ͳɹ�
#define SMS_SEND_ER 0x18	///< ���ŷ���ʧ��

typedef enum
{
	M_U7500		= 1,
	M_C7500		= 2,
	M_U8300		= 3,
	M_LM91XX	= 4,
	M_HUAWEI_3G	= 5,
	M_HUAWEI_4G	= 6,
	M_UNKNOWN,
}MODEL_IDX;


#define MAX_SENDSMS_ONCE	10

#define NET3G_DIAL_DBG(level, arg...) dev_debug(level, MOD_NETFUN_3G, ##arg)



typedef struct
{
	BOOL		used;				/*�Ƿ���ʹ��*/
	LIST		atList;				/*at��Ӧ��*/
}AT_Response;

typedef struct
{
	NODE		node;
	char*		atResponse;
}AT_RESPONSE_NODE;

typedef struct
{
	UINT32		stat;
	UINT8		l_alpha_oper[32];
	UINT8		s_alpha_oper[32];
	UINT8		num_oper[16];
	UINT32		rat;
}COPS_INFO;

#define RESP_LEN    256
typedef struct
{
	UINT32		bEnable;
	char		szResp[RESP_LEN];
}LAST_RESP_T;

typedef struct 
{
	char oldcode[16];
	char newcode[16];
}RENEW_PINCODE;


void lstAdd(LIST *pList, NODE *pNode);
int lstCount(LIST *pList);
void lstDelete(LIST *pList,NODE *pNode);
NODE *lstFirst(LIST *pList);
void lstInsert(LIST *pList,NODE *pPrev,NODE *pNode);
NODE *lstNext(NODE *pNode);
void lstFree(LIST *pList);
int get_ipaddr(char * interface_name,char * ip,int len);
//t get_dns(char* dns1, char* dns2);
int SetSerialBaud(int fd,int speed);
int SetSerialRawMode(int fd);
//int sysClkRateGet(void);
unsigned long tickGet(void);
void smsBubbleSort(int listNums);
void at_cleanup(void *arg);
void initATChannel(void);
void releaseATChannel(void);
int ATSendSMS(char * phoneNum, char * msg);
int writeline(int fd, const char *s);
void pinInit(void);
void funInit(void);
void FindSysInfo(void);
void sysinfoInit(void);
void modemInit(void);
void sendLog(int iOper, char * pParam);
int atcmd_snd_other(void);
int getModemModel(char * pModemName);
int writeATCommand(int fd, const char *s, const char* startString, char* fullString,int fullLen, BOOL breakWhileError, int waitTick);

#endif /* _ATCHANNEL_H_ */
