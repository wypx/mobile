/**@file net_3g_app.c
 * @note HangZhou Hikvision Digital Technology Co., Ltd. All Right Reserved.
 * @brief  3G/4G���̲���������ͷ�ļ�
 * 
 * @author   xusen
 * @date     2014-2-25
 * @version  V1.0.0
 * 
 * @note ///Description here 
 * @note History:        
 * @note     <author>   <time>    <version >   <desc>
 * @note  
 * @warning  
 */
 
#ifndef _DIALD_MAIN_H_
#define _DIALD_MAIN_H_

#include <sys/shm.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/mount.h>
#include <pthread.h>
#include <sys/wait.h>
#include <net/route.h>

#include "atcmd_handle.h"
#include "diald_process.h"
#include "hik_mod_oper.h"
#include "dev_debug.h"

#define LTE4G_DEBUG(level, arg...) dev_debug(level, MOD_NETFUN_MOBILE, ##arg)

#define LOCAL_INTERFACE		"eth0"
#define PPP_INTERFACE		"ppp0"

#define SHMKEY		(key_t)0x100
#define IFLAGS		(IPC_CREAT | IPC_EXCL)
#define SHM_ERR		((COMMUNICATION_PARAM *)-1)

#ifndef MS_SILENT
#define MS_SILENT 32768
#endif

// �ⲿ���ýӿ�
extern int initPPP(void);

// �ڲ�����ӿ�
unsigned int check_sum_16(UINT16 *pBuf, int len);
int del_gateway(void);
void dial_exit(int iExitCode);
int dial_release(void);
void dial_handle_error(int iErrCode);
int mobile_get_dial_error(void);
void dial_error_occur(int iCode);

#endif  /*_DIALD_MAIN_H_*/
