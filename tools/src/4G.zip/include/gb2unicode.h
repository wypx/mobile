/*
 * gb2unicode.h
 *
 *  Created on: 2009-3-13
 *      Author: dell
 */

#ifndef GB2UNICODE_H_
#define GB2UNICODE_H_
int strUnicode2GB(const unsigned char *strSourcer, char *strDest, int n);
int strGB2Unicode(const char *str, unsigned char *dst, int n);
#endif /* GB2UNICODE_H_ */
