ttcp
====

Test TCP, from: http://en.wikipedia.org/wiki/Ttcp