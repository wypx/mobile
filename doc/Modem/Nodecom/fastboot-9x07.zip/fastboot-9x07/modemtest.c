#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include "mu_api.h"
#include "mops.h"

#define TEST_VERSION   "2016_09_08_0.0.1"

void usage()
{
    printf("backup\n");
    printf("restore\n");
    printf("dload\n");
    printf("loadhex hexfile\n");
    printf("loadehex ehexfile\n");
    printf("flash ptn partition.mbn ptn.mbn\n");
}
int main(int argc, char** argv)
{
    FILE* fp = NULL;
    int  diag_fd;
    struct stat fstatus;
    
    char buf[80];
    memset(&buf,0,sizeof(buf));
    getcwd(buf,sizeof(buf));
    printf("current working directory:%s, TEST_VERSION:%s\n", buf, TEST_VERSION);
    memset(&file_update,0,sizeof(file_update));
    sprintf(file_update.uplog,"%s/uplog", buf);

    if(argc > 1)
    {
        if(strcmp(argv[1], "backup") == 0)
        {
            back_up_nv("/dev/ttyUSB2", "/dev/ttyUSB0");
        }
        else if(strcmp(argv[1], "restore") == 0)
        {
            mu_restore_nv("/dev/ttyUSB2", "/dev/ttyUSB0");
        }
        else if(strcmp(argv[1], "dload") == 0)
        {
            send_offlin_cmd("/dev/ttyUSB0");
            dload_switch_cmd("/dev/ttyUSB0");
        }
        else if(strcmp(argv[1], "loadhex") == 0)
        {
            if(argc == 3)
            {
                if((stat(argv[2], &fstatus) == 0) && (fp = fopen(argv[2], "rb")))
                {
                    diag_fd = mu_opencom("/dev/ttyUSB0");
                    if(diag_fd < 0)
                    {
                        printf("open diagnosetic port failed.\n");
                        fclose(fp);
                        return -1;
                    }
                    HexDownload(diag_fd, fp, fstatus.st_size, 0, NULL);
                    fclose(fp);
                    close(diag_fd);
                }
            }
            else
            {
                usage();
            }
        }
        else if(strcmp(argv[1], "loadehex") == 0)
        {
            if(argc == 3)
            {
                if((stat(argv[2], &fstatus) == 0) && (fp = fopen(argv[2], "rb")))
                {
                    diag_fd = mu_opencom("/dev/ttyUSB0");
                    if(diag_fd < 0)
                    {
                        printf("open diagnosetic port failed.\n");
                        fclose(fp);
                        return -1;
                    }
                    HexDownload(diag_fd, fp, fstatus.st_size, 1, NULL);
                    fclose(fp);
                    close(diag_fd);
                }
            }
            else
            {
                usage();
            }
        }
        else if(strcmp(argv[1], "flash") == 0)
        {
            if(argc == 5)
            {
                diag_fd = mu_opencom("/dev/ttyUSB0");
                if(diag_fd < 0)
                {
                    printf("open diagnosetic port failed.\n");
                    return -1;
                }
                if((stat(argv[3], &fstatus) == 0) && (fp = fopen(argv[3], "rb")))
                {
                    if(dload_partition_table_download(diag_fd, fp, fstatus.st_size, NULL) != 0)
                    {
                        printf("load partition failed\n");
                    }
                    fclose(fp);
                }
                if((stat(argv[4], &fstatus) == 0) && (fp = fopen(argv[4], "rb")))
                {
                    dload_image(diag_fd, fp, fstatus.st_size, argv[2], NULL);
                    fclose(fp);
                }
                close(diag_fd);
            }
            else
            {
                usage();
            }
        }
        else if(strcmp(argv[1], "reset") == 0)
        {
            diag_fd = mu_opencom("/dev/ttyUSB0");
            if(diag_fd < 0)
            {
                printf("open diagnosetic port failed.\n");
                return -1;
            }
            reset_cmd(diag_fd);
            close(diag_fd);
        }
        else if(strcmp(argv[1], "dump") == 0)
        {
            diag_fd = mu_opencom("/dev/ttyUSB0");
            if(diag_fd < 0)
            {
                printf("open diagnosetic port failed.\n");
                return -1;
            }
//<!-- add NODECOM MDM9x07 FEATURE by caogang@20160908
#ifdef _NODECOM_MDM9x07_FEATURE
            if (argc==3)
            {
                set_sahara_dump_path(argv[2]);

                boot_sahara_handle_hello(diag_fd);
                boot_sahara_handle_no_cmd_id(diag_fd);
                boot_sahara_handle_hello(diag_fd);
                boot_sahara_handle_hello_resp(diag_fd);
                boot_sahara_handle_memory_debug(diag_fd);
                boot_sahara_handle_memory_read_packet(diag_fd);
                boot_sahara_handle_memory_read_packet_resp(diag_fd);
                boot_sahara_handle_dump_mem(diag_fd);
                printf("dload dump mem finished, please see %s.\n", argv[2]);
            }
#else
            dump_mem(diag_fd);
#endif //#ifdef _NODECOM_MDM9x07_FEATURE
//end -->
            close(diag_fd);
        }
    }
    else
    {
        usage();
    }
    return 0;
}
