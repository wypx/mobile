#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <byteswap.h>
#include <signal.h>
#include <termios.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <stdarg.h>
//to test by caogang
#include <endian.h>

#include "fastboot.h"
#include "mu_api.h"
#include "mops.h"


#define UPGRADE_VERSION   "2016_04_07_0.0.2"

#define FIRMWARE_MASK 0x12345678
#define MIN(a,b) (((a)>(b))?(b):(a))

//to test by caogang
//#   define myntohl(x)	bswap_32 (x)
//#   define myntohs(x)	bswap_16 (x)

#if __BYTE_ORDER == __BIG_ENDIAN
#define myntohl(x)	bswap_32 (x)
#define myntohs(x)	bswap_16 (x)
#define myhtonl(x)	bswap_32 (x)
#define myhtons(x)	bswap_16 (x)
#else
#if __BYTE_ORDER == __LITTLE_ENDIAN
#define myntohl(x)        (x)
#define myntohs(x)        (x)
#define myhtonl(x)        (x)
#define myhtons(x)        (x)
#endif
#endif

//struct file_info_st file_info;
//struct file_update_info file_update;

//#define SIMULATE_MODE 1
int back_up_nv(char* at_interface, char* diag_interface);
int mu_restore_nv(char* at_interface, char* diag_interface);
int resolve_nv_list_file(const char* image_data, int len, char* name);

struct header_info_t
{
    unsigned int mask;
    unsigned int crc;
    unsigned int len;
    char version[128];
};

struct image_info_t
{
    char ptn[16];
    unsigned int flag;
    int offset;
    int length;
};
static usb_handle *usb = 0;
//#define PAGE_SIZE 2048
#define PAGE_SIZE 4096

char buff[PAGE_SIZE];
#ifdef _NODECOM_MDM9x25_FEATURE
#define BLOCK_SIZE (2112*5120) //one page contains 2048 data and bad block management 64
char data[BLOCK_SIZE];
#else
char data[PAGE_SIZE];
#endif
int bexit = 0;

#ifdef _NODECOM_MDM9x25_FEATURE
void die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    LOG_ERR(fmt, ap);
    va_end(ap);
}    
#endif

int resolve_nv_list_file(const char* image_data, int len, char* name)
{
    int fd = -1;
    int res;
    char resolve_nv_list_name[256];
    memset(resolve_nv_list_name, 0, sizeof(resolve_nv_list_name));


    if (NULL == name)
        return -1;

    sprintf(resolve_nv_list_name,"%s%s_list", file_info.tmppath,name);
	
    fd = open(resolve_nv_list_name, O_CREAT | O_RDWR | O_APPEND);
    if (fd < 0)
    {
        return -1;
    }
    
    if((res=write(fd,image_data,len))!=len)
    {
        close(fd);
        return -1;
    }

    close(fd);
    return 0;
}

static int open_at(char *atport)
{
    int fd;
    if(NULL == atport)
    {
        return -1;
    }
    fd = open(atport, O_RDWR|O_NOCTTY|O_NDELAY);
    return fd;
}
static int close_at(int fd)
{
    return close(fd);
}
static int set_at(int fd, int baud, int databits, int stopbits, int parity)
{
    int baudrate;
    struct termios newtio;

    switch (baud)
    {
        case 300:
            baudrate = B300;
            break;
        case 600:
            baudrate = B600;
            break;
        case 1200:
            baudrate = B1200;
            break;
        case 2400:
            baudrate = B2400;
            break;
        case 4800:
            baudrate = B4800;
            break;
        case 9600:
            baudrate = B9600;
            break;
        case 19200:
            baudrate = B19200;
            break;
        case 38400:
            baudrate = B38400;
            break;
        default :
            baudrate = B9600;
            break;
    }

    tcgetattr(fd, &newtio);
    //bzero(&newtio, sizeof(newtio));
    memset(&newtio,0,sizeof(newtio));

    newtio.c_cflag &= ~CSIZE;

    switch (databits)
    {
        case 7:
            newtio.c_cflag |= CS7;
            break;
        case 8:
            newtio.c_cflag |= CS8;
            break;
        default:
            newtio.c_cflag |= CS8;
            break;
    }

    switch (parity)
    {
        case 'n':
        case 'N':
            newtio.c_cflag &= ~PARENB;
            newtio.c_iflag &= ~INPCK;
            break;
        case 'o':
        case 'O':
            newtio.c_cflag |= (PARODD | PARENB);
            newtio.c_iflag |= INPCK;
            break;
        case 'e':
        case 'E':
            newtio.c_cflag |= PARENB;
            newtio.c_cflag &= ~PARODD;
            newtio.c_iflag |= INPCK;
            break;
        case 'S':
        case 's':
            newtio.c_cflag &= ~PARENB;
            newtio.c_cflag &= ~CSTOPB;
            break;
        default:
            newtio.c_cflag &= ~PARENB;
            newtio.c_iflag &= ~INPCK;
            break;
    }

    switch (stopbits)
    {
        case 1:
            newtio.c_cflag &= ~CSTOPB;
            break;
        case 2:
            newtio.c_cflag |= CSTOPB;
            break;
        default:
            newtio.c_cflag &= ~CSTOPB;
            break;
    }

    newtio.c_cc[VTIME] = 0;
    newtio.c_cc[VMIN] = 0;
    newtio.c_cflag   |=   (CLOCAL | CREAD);
    newtio.c_oflag   = OPOST;
    newtio.c_iflag   = 0;//&= ~(IXON | IXOFF | IXANY);
    cfsetispeed(&newtio, baudrate);
    cfsetospeed(&newtio, baudrate);
    tcflush(fd, TCIFLUSH);

    if (tcsetattr(fd,TCSANOW, &newtio) != 0)
    {
        return -1;
    }

    return 0;
}
static int at_read_port(int fd, char *buff, size_t size)
{
    int rc = 0;
    fd_set readfd;
    struct timeval tv;

    tv.tv_sec = 1;
    tv.tv_usec = 0;
    if(NULL == buff)
    {
        return -1;
    }
    //while(0 == rc)
    {
        FD_ZERO(&readfd);
        FD_SET(fd, &readfd);
        rc = select(fd + 1, &readfd, NULL, NULL, &tv);
        tv.tv_sec = 5;
        tv.tv_usec = 0;
    }
    if(rc > 0)
    {
        if(FD_ISSET(fd, &readfd))
        {
            return read(fd, buff, size);
        }
        else
        {
            return -1;
        }
    }
    else if(0 == rc)
    {
        return 0;
    }
    else
    {
        return -1;
    }
}
static int at_write_port(int fd, char *buff, size_t len)
{
    if(NULL == buff)
    {
        return -1;
    }
    LOG_DBG("%s\n", buff);
    return write(fd, buff, len);
}
int match_fastboot(usb_ifc_info *info)
{
//to test by caogang
    LOG_DBG("info->dev_vendor=%04X\n", info->dev_vendor);
    LOG_DBG("info->ifc_class=%04X\n", info->ifc_class);
    LOG_DBG("info->ifc_subclass=%04X\n", info->ifc_subclass);
    LOG_DBG("info->dev_product=%04X\n", info->dev_product);
//to test by caogang
//    if(info->dev_vendor != 0x1c9e)
    if(info->dev_vendor != 0x18D1)
        return -1;
    if(info->ifc_class != 0xff) return -1;
    if(info->ifc_subclass != 0x42) return -1;
    if(info->ifc_protocol != 0x03) return -1;
    return 0;
}

usb_handle *open_device(void)
{
#ifndef SIMULATE_MODE
    usb_handle *usb = 0;

    usb = usb_open(match_fastboot);
    return usb;
#else
    LOG_DBG("open_device\n");
#endif
}

int backup_nvinfo()
{
    return back_up_nv(file_info.at_inface, file_info.diagnose_inface);
}

int restore_nvinfo()
{
    return mu_restore_nv(file_info.at_inface, file_info.diagnose_inface);
}

int fastboot_download_header(int len)
{
    LOG_DBG("fastboot_download_header %d\n", len);
#ifndef SIMULATE_MODE
    if(fb_download_header(usb, len) < 0)
    {
        return -1;
    }
#endif
    return 0;
}
int fastboot_download(const char* image_data, int len)
{
#ifndef SIMULATE_MODE
    if(fb_download_dataonly(usb, image_data, len) < 0)
    {
        return -1;
    }
#else
    LOG_DBG("fastboot_download %d\n", len);
#endif
    return 0;
}
int fastboot_download_finish(const char* image_data, int len)
{
    LOG_DBG("fastboot_download_finish %d\n", len);
#ifndef SIMULATE_MODE
    if(fb_download_datafinish(usb, image_data, len) < 0)
    {
        return -1;
    }
#endif
    return 0;
}
int fastboot_flash(const char* ptn)
{
    LOG_DBG("fastboot_flash %s\n", ptn);
#ifndef SIMULATE_MODE
    char cmd[64];
    
    sprintf(cmd, "flash:%s", ptn);
    if(fb_command(usb, cmd) < 0)
    {
        LOG_ERR("fastboot_flash error:%s\n", fb_get_error());
        return -1;
    }
#endif
    return 0;
}
int fastboot_reboot()
{
    LOG_DBG("fastboot_reboot\n");
#ifndef SIMULATE_MODE
    char cmd[64];
    int fd = -1;

    sprintf(cmd, "reboot");
    while(1)
    {
        fb_command(usb, cmd);
        usb_close(usb);
        sleep(5);
        usb = open_device();
        if(usb)
        {
            usb_close(usb);
        }
        else
        {
            break;
        }
    }
    while(1)
    {
        fd = open_at(file_info.at_inface);
        if(fd >= 0)
        {
            close_at(fd);
            fd = -1;
        }
        else
        {
            LOG_DBG("check at interface failed\n");
            sleep(2);
            continue;
        }
        fd = open_at(file_info.diagnose_inface);
        if(fd >= 0)
        {
            close_at(fd);
            fd = -1;
        }
        else
        {
            LOG_DBG("check diag interface failed\n");
            sleep(2);
            continue;
        }
        break;
    }

#endif
    return 0;
}

usb_handle *switch_to_fastboot()
{
    int fd = -1;
    char cmd[128];
    char data[128];
    memset(cmd, 0, sizeof(cmd));
    memset(data, 0, sizeof(data));
    sprintf(cmd, "%s", "AT+SYSCMD=sys_reboot bootloader\r");

    while(1)
    {
        //fd = open_at(file_info.at_inface);
        fd = mu_opencom(file_info.at_inface);
        if(fd >=0)
        {
            int rc = 0;
            //set_at(fd, 115200/*9600*/, 8, 1, 'n');
            //rc = at_write_port(fd, cmd, strlen(cmd));
            if(exec_at(fd, cmd, data, sizeof(data)) < 0)
            {
                close_at(fd);
                fd = -1;
                sleep(2);
                continue;
            }
            LOG_DBG("rcv:%s\n", data);

            LOG_DBG("at_write_port return %s rc:%d\n", file_info.at_inface, rc);
            close_at(fd);
            fd = -1;
            sleep(2);
        }
        else
        {
            LOG_DBG("check fastboot device\n");
            usb = open_device();
            if(usb != NULL)
            {
                return usb;
            }
            sleep(2);
        }
    }
    return NULL;
}
void sig_fun(int sig)
{
    LOG_DBG("got sig %d\n", sig);
    bexit = 1;
    fclose(stdin);
}
int f_read(const char *path, void *buffer, int max)
{
    int f;
    int n;

    if ((f = open(path, O_RDONLY)) < 0) return -1;
    n = read(f, buffer, max);
    close(f);
    return n;
}

int f_read_string(const char *path, char *buffer, int max)
{
    if (max <= 0) return -1;
    int n = f_read(path, buffer, max - 1);
    buffer[(n > 0) ? n : 0] = 0;
    return n;
}

char *psname(int pid, char *buffer, int maxlen)
{
    char buf[512];
    char path[64];
    char *p;

    if (maxlen <= 0) return NULL;
    *buffer = 0;
    sprintf(path, "/proc/%d/stat", pid);
    if ((f_read_string(path, buf, sizeof(buf)) > 4) && ((p = strrchr(buf, ')')) != NULL)) 
    {
        *p = 0;
        if (((p = strchr(buf, '(')) != NULL) && (atoi(buf) == pid)) 
        {
            strncpy(buffer, p + 1, maxlen);
        }
    }
    return buffer;
}

static int _pidof(const char *name, pid_t** pids)
{
    const char *p;
    char *e;
    DIR *dir;
    struct dirent *de;
    pid_t i;
    int count;
    char buf[256];

    count = 0;
    *pids = NULL;

    if ((p = strchr(name, '/')) != NULL) name = p + 1;

    if ((dir = opendir("/proc")) != NULL) 
    {
        while ((de = readdir(dir)) != NULL) 
        {
            i = strtol(de->d_name, &e, 10);
            if (*e != 0) continue;
            if (strcmp(name, psname(i, buf, sizeof(buf))) == 0) 
            {
                if ((*pids = realloc(*pids, sizeof(pid_t) * (count + 1))) == NULL) 
                {
                    return -1;
                }
                (*pids)[count++] = i;
            }
        }
    }
    closedir(dir);
    return count;
}

int lc_killall(const char *name, int sig)
{
    pid_t *pids;
    int i;
    int r;

    if ((i = _pidof(name, &pids)) > 0) 
    {
        r = 0;
        do 
        {
            r |= kill(pids[--i], sig);
        } 
        while (i > 0);
        free(pids);
        return r;
    }
    return -2;
}


/********************************************************************************
 *
 *         Name:  lc_killall_tk
 *  Description:  kill process by name 
 *        Parms:  name --- process name
 *       Return:
 *        Notes:
 ********************************************************************************/

void lc_killall_tk(const char *name)
{
    int n;

    if (lc_killall(name, SIGTERM) == 0) 
    {
        n = 5;
        while ((lc_killall(name, 0) == 0) && (n-- > 0)) 
        {
            LOG_DBG("%s: waiting name=%s n=%d\n", __FUNCTION__, name, n);
            sleep(1);
        }
        if (n < 0) 
        {
            n = 5;
            while ((lc_killall(name, SIGKILL) == 0) && (n-- > 0)) 
            {
                LOG_DBG("%s: SIGKILL name=%s n=%d\n", __FUNCTION__, name, n);
                sleep(2);
            }
        }
    }
}

int main(int argc, char** argv)
{
    //to test by caogang
    FILE* pimage_file = NULL;
    int count = 0;
    int firmware_offset = 0;
    int readed = 0;
    int fd_diagnose = -1;
    int hex_run = 0;
    struct header_info_t* pfirmware = NULL;
    struct image_info_t* index = NULL;
    int result = 0;
#ifdef _NODECOM_MDM9x25_FEATURE
    int num;
#endif

    system("busybox ls /dev/ttyUSB*");
    memset(&file_info,0,sizeof(file_info));


    switch (argc){
        case 7:
        {
            strcpy(file_info.imagefile,argv[1]);
            strcpy(file_info.tmppath,argv[2]);
            strcpy(file_info.at_inface,argv[3]);
            strcpy(file_info.diagnose_inface,argv[4]);
            file_info.bNV = *argv[5] - '0';
            strcpy(file_info.version_t,argv[6]);
            break;
        }
        case 6:
        {
            strcpy(file_info.imagefile,argv[1]);
            strcpy(file_info.tmppath,argv[2]);
            strcpy(file_info.at_inface,argv[3]);
            strcpy(file_info.diagnose_inface,argv[4]);
			file_info.bNV = *argv[5] - '0';
            strcpy(file_info.version_t,"9x15");
            break;
        }
        case 5:
        {
            strcpy(file_info.imagefile,argv[1]);
            strcpy(file_info.tmppath,argv[2]);
            strcpy(file_info.at_inface,argv[3]);
            strcpy(file_info.diagnose_inface,argv[4]);
            file_info.bNV=1;
            strcpy(file_info.version_t,"9x15");
            break;
        }
        case 4:
        {
            strcpy(file_info.imagefile,argv[1]);
            strcpy(file_info.tmppath,argv[2]);
            strcpy(file_info.at_inface,argv[3]);
            strcpy(file_info.diagnose_inface,"/dev/ttyUSB0");
            file_info.bNV=1;
            strcpy(file_info.version_t,"9x15");
            break;
        }
        case 3:
        {
            strcpy(file_info.imagefile,argv[1]);
            strcpy(file_info.tmppath,argv[2]);
            strcpy(file_info.at_inface,"/dev/ttyUSB2");
            strcpy(file_info.diagnose_inface,"/dev/ttyUSB0");
            file_info.bNV=1;
            strcpy(file_info.version_t,"9x15");
            break;
        }
        case 2:
        {
            strcpy(file_info.imagefile,argv[1]);
            system("busybox mkdir data");
            strcpy(file_info.tmppath,"data/");
            strcpy(file_info.at_inface,"/dev/ttyUSB2");
            strcpy(file_info.diagnose_inface,"/dev/ttyUSB0");
            file_info.bNV=1;
            strcpy(file_info.version_t,"9x15");
            break;
        }
        default:
        {
            strcpy(file_info.version_t,"9x15");
            file_info.bNV=1;
            strcpy(file_info.diagnose_inface,"/dev/ttyUSB0");
            strcpy(file_info.at_inface,"/dev/ttyUSB2");
            system("busybox mkdir data");
            strcpy(file_info.tmppath,"data/");
            strcpy(file_info.imagefile,"firmware.bin");
            break;
        }
    }

    memset(&file_update,0,sizeof(file_update)); 
    sprintf(file_update.uplog,"%suplog", file_info.tmppath);
    sprintf(file_update.uplog2,"%suplog", file_info.tmppath);
    sprintf(file_update.nv_low_list,"%snv_low_list", file_info.tmppath);
    sprintf(file_update.nv_high_list,"%snv_high_list", file_info.tmppath);
    sprintf(file_update.nvfile,"%snvfile", file_info.tmppath);
    sprintf(file_update.nvfile2,"%snvfile2", file_info.tmppath);
    sprintf(file_update.highnv,"%shighnv", file_info.tmppath);
    sprintf(file_update.highnv2,"%shighnv2", file_info.tmppath);
    sprintf(file_update.modem_info,"%smodem_info", file_info.tmppath);
    sprintf(file_update.modem_info2,"%smodem_info2", file_info.tmppath); 

    LOG_DBG("=>>%s && %s \n", file_info.imagefile, file_info.tmppath);       

    LOG_DBG("enter modem upgrade\n");

    signal(SIGTERM, sig_fun);
    signal(SIGPIPE, sig_fun);

    //to test by caogang
    //count = fread(buff, 1, sizeof(buff), stdin);
    pimage_file = fopen(file_info.imagefile, "r");

    count = fread(buff, 1, sizeof(buff), pimage_file);

    if(count < sizeof(buff))
    {
        LOG_ERR("read firmware header failed\n");
        result = -1;
        goto error;  
    }
    firmware_offset = count;
    pfirmware = (struct header_info_t*)buff;

    LOG_DBG("upgrade version: %s, firmware version %s\n", UPGRADE_VERSION, pfirmware->version);

    //index page
	index = (struct image_info_t*)(pfirmware+1);
    pfirmware->mask = myntohl(pfirmware->mask);

    if(pfirmware->mask != FIRMWARE_MASK)
    {
        LOG_ERR("firmware mask not match, pfirmware->mask=%04X\n", pfirmware->mask);
        result = -2;
        goto error;
    }
//    system("stop ril-daemon");
//    system("killall pppd");
//to test by caogang
//    lc_killall_tk("lc_mm");
    lc_killall_tk("udhcpc");
    lc_killall_tk("hostproxyd");

    if(check_dload_mode(file_info.diagnose_inface) == 1)
    {
        fd_diagnose = mu_opencom(file_info.diagnose_inface);
        if(fd_diagnose < 0)
        {
            result = -3;
            goto error;
        }
        while(index->ptn[0] != '\0' && index->flag != 0)
        {
            index->offset = myntohl(index->offset);
            index->length = myntohl(index->length);
            LOG_DBG("firmware offset %d\n", firmware_offset);
            LOG_DBG("image %s offset %d len %d\n", index->ptn, index->offset, index->length);
            while(index->offset > firmware_offset)
            {
                count = MIN(sizeof(data), (index->offset - firmware_offset));

                //to test by caogang
                //readed = fread(data, 1, count, stdin);
                readed = fread(data, 1, count, pimage_file);

                if(count != readed)
                {
                    LOG_ERR("skip data failed ptn %s firmware offset %d image offset %d need %d real %d\n",index->ptn, firmware_offset, index->offset, count, readed);
                    result = -4;
                    goto error;
                }
                firmware_offset += readed;
            }
            if(strcmp(index->ptn, "hex") == 0)
            {
                readed = 0;
                if(HexDownload(fd_diagnose, stdin, index->length, 0, &readed) == 0)
                {
                    LOG_DBG("hex run ok\n");
                    hex_run = 1;
                }
                else
                {
                    LOG_DBG("hex run failed\n");
                }
                firmware_offset += readed;
            }
            else if(strcmp(index->ptn, "ehex") == 0)
            {
                if(!hex_run)
                {
                    readed = 0;
                    if(HexDownload(fd_diagnose, stdin, index->length, 1, &readed) == 0)
                    {
                        LOG_DBG("ehex run ok\n");
                        hex_run = 1;
                        firmware_offset += readed;
                    }
                    else 
                    {
                        LOG_DBG("ehex run failed\n");
                        firmware_offset += readed;
                        result = -5;
                        goto error;
                    }
                }
            }
            else if(strcmp(index->ptn, "partition") == 0)
            {
                readed = 0;
                if(dload_partition_table_download(fd_diagnose, stdin, index->length, &readed) == 0)
                {
                    LOG_DBG("load partition ok\n");
                    firmware_offset += readed;
                }
                else
                {
                    LOG_DBG("load partition failed\n");
                    firmware_offset += readed;
                    result = -6;
                    goto error;
                }
            }
            else if(hex_run)
            {
                readed = 0;
                if(dload_image(fd_diagnose, stdin, index->length, index->ptn, &readed) == 0)
                {
                    LOG_DBG("ptn %s upgrade ok\n", index->ptn);
                }
                else
                {
                    LOG_DBG("ptn %s upgrade failed\n", index->ptn);
                }
                firmware_offset += readed;
            }
            else
            {
                LOG_DBG("no hex file download\n");
                result = -7;
                goto error;
            }

            index++;
        }
        if(reset_cmd(fd_diagnose) != 0)
        {
            LOG_DBG("reset failed\n");
            result = -8;
            goto error;
        }
        close(fd_diagnose);
    }
    else
    {
        LOG_DBG("begin backup nv\n");

/////////////////////////////////////////////////
//to test by caogang
        while(index->ptn[0] != '\0')
        {
            if(strcmp(index->ptn, "hex") == 0 || strcmp(index->ptn, "ehex") == 0 || strcmp(index->ptn, "partition") == 0)
            {
                index++;
                continue;
            }
		
            if (0 == strcmp(index->ptn, "nv_high") || 0 == strcmp(index->ptn, "nv_low"))
            {
                index->offset = myntohl(index->offset);
                index->length = myntohl(index->length);
                LOG_DBG("firmware offset %d\n", firmware_offset);
                LOG_DBG("image %s offset %d len %d\n", index->ptn, index->offset, index->length);

                while(index->offset > firmware_offset)
                {
                    count = MIN(sizeof(data), (index->offset - firmware_offset));
                    readed = fread(data, 1, count, pimage_file);
                    if(count != readed)
                    {
                        LOG_ERR("skip data failed ptn %s firmware offset %d image offset %d need %d real %d\n",index->ptn, firmware_offset, index->offset, count, readed);
                        result = -10;
                        goto error;
                    }
                    firmware_offset += readed;
                }
                while(index->length > 0 && bexit == 0)
                {
                    count = MIN(sizeof(data), index->length);
                    readed = fread(data, 1, count, pimage_file);
                    if(count != readed)
                    {
                        LOG_ERR("read data failed ptn %s need %d real %d\n",index->ptn, count, readed);
                        bexit = 1;
                        break;
                    }
                    firmware_offset += readed;
                    index->length -= readed;
                    if(index->length > 0)
                    {
                        if(resolve_nv_list_file(data, readed, index->ptn) != 0)
                        {
                            LOG_ERR("resolve nv list file failed ptn %s len %d\n", index->ptn, readed);
                            result = -12;
                            goto error;
                        }
                    }
                    else
                    {
                        if(resolve_nv_list_file(data, readed, index->ptn) != 0)
                        {
                            LOG_ERR("finish download data failed ptn %s len %d\n", index->ptn, readed);
                            result = -13;
                            goto error;
                        }
                    }
                }
                if(bexit)
                {
                    LOG_ERR("bexit ptn %s len %d\n", index->ptn, index->length);
                    while(index->length > 0)
                    {
                        count = MIN(sizeof(data), index->length);
                        index->length -= count;
                        if(index->length > 0)
                        {
                            if(resolve_nv_list_file(data, count, index->ptn) != 0)
                            {
                                LOG_ERR("resolve nv list file failed ptn %s len %d\n", index->ptn, count);
                                result = -14;
                                goto error;
                            }
                        }
                        else
                        {
                            if(resolve_nv_list_file(data, count, index->ptn) != 0)
                            {
                                LOG_ERR("finish download data failed ptn %s len %d\n", index->ptn, count);
                                result = -15;
                                goto error;
                            }
                        }
                    }
                    result = -16;
                    goto error;
                }
                index++;
            }
            else
            {
                LOG_DBG("resolve nv end image %s offset %d len %d\n", index->ptn, index->offset, index->length);
                break;
            }
        }
////////////////////////////////////////////////
        LOG_DBG("file_info.bNV = %d\n", file_info.bNV);
        if (1 == file_info.bNV)
        {
            if(backup_nvinfo() < 0)
            {
                result = -17;
                goto error;
                LOG_ERR("backup_nvinfo failed\n");
            }   
        }
    }
    LOG_DBG("begin switch to fastboot\n");
    usb = switch_to_fastboot();

#ifndef SIMULATE_MODE
    if(usb == NULL)
    {
        LOG_ERR("switch to fastboot failed\n");
        result = -9;
        goto error;
    }
#endif
    LOG_DBG("download firmware and flash\n");
    while(index->ptn[0] != '\0')
    {
        if(strcmp(index->ptn, "hex") == 0 || strcmp(index->ptn, "ehex") == 0 || strcmp(index->ptn, "partition") == 0)
        {
            index++;
            continue;
        }

        index->offset = myntohl(index->offset);
        index->length = myntohl(index->length);
        LOG_DBG("firmware offset %d\n", firmware_offset);
        LOG_DBG("image %s offset %d len %d\n", index->ptn, index->offset, index->length);

        while(index->offset > firmware_offset)
        {
            
            count = MIN(sizeof(data), (index->offset - firmware_offset));
            
            //to test by caogang
            //readed = fread(data, 1, count, stdin);
            readed = fread(data, 1, count, pimage_file);

            if(count != readed)
            {
                LOG_ERR("skip data failed ptn %s firmware offset %d image offset %d need %d real %d\n",index->ptn, firmware_offset, index->offset, count, readed);
                result = -10;
                goto error;
            }
            firmware_offset += readed;
        }
#ifdef _NODECOM_MDM9x25_FEATURE
        num = 0;
        while(index->length > 0 && bexit == 0)
        {
            count = MIN(sizeof(data), index->length);
            
            //to test by caogang
            //readed = fread(data, 1, count, sidin);
            readed = fread(data, 1, count, pimage_file);

            if(count != readed)
            {
                LOG_ERR("read data failed ptn %s need %d real %d\n",index->ptn, count, readed);
                bexit = 1;
                break;
            }
            firmware_offset += readed;
            index->length -= readed;
           
            fb_queue_mflash(index->ptn, data, count, num);
            fb_execute_queue(usb);
            num++;
        }        
#else
        if(fastboot_download_header(index->length) != 0)
        {
            LOG_ERR("download header failed ptn %s len %d\n", index->ptn, index->length);
            result = -11;
            goto error;
        }
        while(index->length > 0 && bexit == 0)
        {
            count = MIN(sizeof(data), index->length);

            //to test by caogang
            //readed = fread(data, 1, count, stdin);
            readed = fread(data, 1, count, pimage_file);

            if(count != readed)
            {
                LOG_ERR("read data failed ptn %s need %d real %d\n",index->ptn, count, readed);
                bexit = 1;
                break;
            }
            firmware_offset += readed;
            index->length -= readed;
            if(index->length > 0)
            {
                if(fastboot_download(data, readed) != 0)
                {
                    LOG_ERR("download data failed ptn %s len %d\n", index->ptn, readed);
                    result = -12;
                    goto error;
                }
            }
            else
            {
                if(fastboot_download_finish(data, readed) != 0)
                {
                    LOG_ERR("finish download data failed ptn %s len %d\n", index->ptn, readed);
                    result = -13;
                    goto error;
                }
            }
        }
        if(bexit)
        {
            LOG_ERR("bexit ptn %s len %d\n", index->ptn, index->length);
            while(index->length > 0)
            {
                count = MIN(sizeof(data), index->length);
                index->length -= count;
                if(index->length > 0)
                {
                    if(fastboot_download(data, count) != 0)
                    {
                        LOG_ERR("download data failed ptn %s len %d\n", index->ptn, count);
                        result = -14;
                        goto error;
                    }
                }
                else
                {
                    if(fastboot_download_finish(data, count) != 0)
                    {
                        LOG_ERR("finish download data failed ptn %s len %d\n", index->ptn, count);
                        result = -15;
                        goto error;
                    }
                }
            }
            result = -16;
            goto error;
        }
        if(fastboot_flash(index->ptn) < 0)
        {
            LOG_ERR("flash failed %s\n", index->ptn);
            result = -17;
            goto error;
        }
#endif        
        index++;
    }
    LOG_DBG("begin reboot to normal\n");
    if(fastboot_reboot() < 0)
    {
        LOG_ERR("reboot failed\n");
        result = -18;
        goto error;
    }
    LOG_DBG("begin restore nv\n");
//to test by caogang
    if (1 == file_info.bNV)
    {
        if(restore_nvinfo() < 0)
        {
            LOG_ERR("restore nv failed\n");
            result = -19;
            goto error;
        }
    }
    LOG_DBG("upgrade success!\n");
error:
    LOG_DBG("goto here:%d\n", result);

    if(result < 0)
         LOG_DBG("upgrade failed!\n");

#ifndef SIMULATE_MODE
    if(fd_diagnose >= 0)
    {
        close(fd_diagnose);
    }
    if(usb)
    {
        usb_close(usb);
    }
#endif
    
    //to test by caogang
    if (NULL != pimage_file)
    {
        fclose(pimage_file);
    }

    //system("reboot");
    return result;
}
