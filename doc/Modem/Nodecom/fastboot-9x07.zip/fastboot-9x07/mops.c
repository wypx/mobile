#include <stdio.h>      
#include <stdlib.h>     
#include <unistd.h>     
#include <sys/types.h>  
#include <sys/stat.h>   
#include <fcntl.h>      
#include <termios.h>    
#include <errno.h>      
#include <string.h>       
#include <sys/wait.h>
#include <time.h>
#include <sys/time.h>
#include <byteswap.h>
#include "nv.c"
#include "mu_api.h"
#define MIN(a,b) (((a)>(b))?(b):(a))
#define MAX_RETRY_TIMES 5
#define HEX_BUFFER_LEN (0x03F9)
#define FLASH_TX_LOAD_LEN 1024
#define cprintf(fmt, args...) do { \
    FILE *fp = fopen(file_update.uplog, "a"); \
    if (fp) { \
        fprintf(fp, fmt, ## args); \
        fclose(fp); \
    } \
} while (0)

//to test by caogang
#define  NV_LOW_LIST_PATH file_update.nv_low_list
#define  NV_HIGH_LIST_PATH file_update.nv_high_list


void cprintf_hex(const unsigned char *buf, int buf_size)
{
    int  i,j;
    int  total_size = 0;
    int line_cout = buf_size>>4;
    if((buf_size&0x0000000f)!=0)
        line_cout++;
    cprintf("\nhex len %d:\n", buf_size);
    for(i=0;i<line_cout;i++)
    {
        cprintf("\n%x:",total_size);
        for(j=0;j<16;j++)
        {
            total_size++;
            cprintf("%02hhX ",buf[(i<<4)+j]);
            if(((i<<4)+1+j)==buf_size)
            {
                cprintf("\n");
                return;
            }
        }
    }  
}




int get_item(char* file, int id, char* data, size_t size)
{
    int fd = -1;
    int itemid;
    int readed;
    int len;
    int found = 0;
    fd = open(file, O_RDONLY);
    if(fd >= 0)
    {
        while(1)
        {
            readed = read(fd, (char*)&itemid, sizeof(itemid));
            if(readed != sizeof(itemid))
            {
                goto END;
            }
            readed = read(fd, (char*)&len, sizeof(len));
            if(readed != sizeof(len))
            {
                goto END;
            }
            
            if(itemid == id)
            {
                if(len > size-1)
                {
                    goto END;
                }
                readed = read(fd, data, len);
                if(readed != len)
                {
                    goto END;
                }
                data[len] = 0;
                found = 1;
                break;
            }
            else
            {
                if(lseek(fd, len, SEEK_CUR) < 0)
                {
                    goto END;
                }
            }
        }
    }
END:
    if(fd >= 0)
    {
        close(fd);
    }
    if(found)
    {
        return 0;
    }
    else
    {
        return -1;
    }
}
int read_sn(int at_fd, int file_fd)
{
    char * cmdstr = "AT+LCTSN=0,5\r";
    char data[128];
    char sn[32];
    int len;
    char *ptr = NULL;
    int id;
    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, cmdstr, data, sizeof(data)) < 0)
    {
        cprintf("exec at failed\n");
        goto END;
    }
    memset(sn, 0, sizeof(sn));
    cprintf("rcv:%s\n", data);
    if((ptr = strstr(data, "+LCTSN:")) && (sscanf(ptr, "+LCTSN:\"%[^\"]", sn) == 1))
    {
        write(file_fd, "LCSN", 4);
        len = strlen(sn);
        write(file_fd, &len, sizeof(len));
        write(file_fd, sn, len);
        return 0;
    }
    else
    {
        cprintf("no sn found\n");
        goto END;
    }
END:
    memcpy(&id, "LCSN", 4);
    if(get_item(file_update.modem_info2, id, sn, sizeof(sn)) < 0)
    {
        cprintf("check LCSN failed\n");
        return -1;
    }
    write(file_fd, "LCSN", 4);
    len = strlen(sn);
    write(file_fd, &len, sizeof(len));
    write(file_fd, sn, len);
    return 0;
}

int read_imei(int at_fd, int file_fd)
{
    char *cmdstr = "AT+LCTSN=0,7\r";
    char data[128];
    char imei[32];
    int len;
    char *ptr = NULL;
    int id;
    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, cmdstr, data, sizeof(data)) < 0)
    {
        cprintf("exec at failed\n");
        goto END;
    }
    memset(imei, 0, sizeof(imei));
    cprintf("rcv:%s\n", data);
    if((ptr = strstr(data, "+LCTSN:")) && (sscanf(ptr, "+LCTSN:\"%[^\"]", imei) == 1))
    {
        write(file_fd, "IMEI", 4);
        len = strlen(imei);
        write(file_fd, &len, sizeof(len));
        write(file_fd, imei, len);
        return 0;
    }
    else
    {
        cprintf("no imei found\n");
        goto END;
    }
END:
    memcpy(&id, "IMEI", 4);
    if(get_item(file_update.modem_info2, id, imei, sizeof(imei)) < 0)
    {
        cprintf("check IMEI failed\n");
        return -1;
    }
    write(file_fd, "IMEI", 4);
    len = strlen(imei);
    write(file_fd, &len, sizeof(len));
    write(file_fd, imei, len);
    return 0;
}
int read_testinf(int at_fd, int file_fd)
{
    char *cmdstr = "AT+TESTINF2=?\r";
    char data[128];
    char testinf[128];
    int len;
    char *ptr = NULL;
    int id;
    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, cmdstr, data, sizeof(data)) < 0)
    {
        cprintf("exec at failed\n");
        goto END;
    }
    memset(testinf, 0, sizeof(testinf));
    cprintf("rcv:%s\n", data);
    if((ptr = strstr(data, "+TESTINF2:")) && (sscanf(ptr, "+TESTINF2:\"%[^\"]", testinf) == 1))
    {
        write(file_fd, "TEST", 4);
        len = strlen(testinf);
        write(file_fd, &len, sizeof(len));
        write(file_fd, testinf, len);
        return 0;
    }
    else
    {
        cprintf("no test found\n");
        goto END;
    }
END:
    memcpy(&id, "TEST", 4);
    if(get_item("file_update.modem_info2", id, testinf, sizeof(testinf)) < 0)
    {
        cprintf("check Test failed\n");
        return -1;
    }
    write(file_fd, "TEST", 4);
    len = strlen(testinf);
    write(file_fd, &len, sizeof(len));
    write(file_fd, testinf, len);
    return 0;
}

int BackupInfo(int at_fd)
{
    int file_fd = -1;
    char cmd[256];
    file_fd = open(file_update.modem_info, O_WRONLY | O_CREAT | O_TRUNC);
    if(file_fd < 0)
    {
        cprintf("open modem_info failed\n");
        return -1;
    }
    if(read_sn(at_fd, file_fd) < 0)
    {
        cprintf("read_sn failed\n");
    }
    if(read_imei(at_fd, file_fd) < 0)
    {
        cprintf("read_imei failed\n");
    }
    if(read_testinf(at_fd, file_fd) < 0)
    {
        cprintf("read_testinf failed\n");
    }
    close(file_fd);
    sprintf(cmd,"busybox mv %s %s", file_update.modem_info, file_update.modem_info2); 
    system(cmd);
//    cprintf("read_testinf %s\n", cmd);
    return 0;
}


int read_high_nv(char* file, unsigned short id, unsigned char* data, size_t size)
{
    int fd = -1;
    unsigned short itemid;
    unsigned short len;
    int readed;
    int found = 0;
    fd = open(file, O_RDONLY);
    if(fd >= 0)
    {
        while(1)
        {
            readed = read(fd, (char*)&itemid, sizeof(itemid));
            if(readed != sizeof(itemid))
            {
                goto END;
            }
//to test by caogang			
//            itemid = bswap_16(itemid);
            readed = read(fd, (char*)&len, sizeof(len));
            if(readed != sizeof(len))
            {
                goto END;
            }
//to test by caogang			
//            len = bswap_16(len);

            if(itemid == id)
            {
                if(len + sizeof(itemid) + sizeof(len) > size)
                {
                    goto END;
                }
                readed = read(fd, data + sizeof(itemid) + sizeof(len), len);
                if(readed != len)
                {
                    goto END;
                }
                data[0] = (const unsigned char)(itemid & 0XFF);
                data[1] = (const unsigned char)((itemid>>8)&0XFF);
                data[2] = (const unsigned char)(len & 0XFF);
                data[3] = (const unsigned char)((len>>8)&0XFF);
                found = 1;
                break;
            }
            else
            {
                if(lseek(fd, NODECOM_MODEM_NV_SIZE, SEEK_CUR) < 0)
                {
                    goto END;
                }
            }
        }
    }
END:
    if(fd >= 0)
    {
        close(fd);
    }
    if(found)
    {
        return len;
    }
    else
    {
        return -1;
    }
}
int read_nv(char* file, unsigned short id, unsigned char* data, size_t size)
{
    int fd = -1;
    unsigned short itemid;
    int readed;
    int found = 0;
    if(size < NODECOM_MODEM_NV_SIZE + sizeof(itemid))
    {
        return -1;
    }
    fd = open(file, O_RDONLY);
    if(fd >= 0)
    {
        while(1)
        {
            readed = read(fd, (char*)&itemid, sizeof(itemid));
            if(readed != sizeof(itemid))
            {
                goto END;
            }
//test by caogang			
//            itemid = bswap_16(itemid);

            if(itemid == id)
            {
                readed = read(fd, data + sizeof(itemid), NODECOM_MODEM_NV_SIZE);
                if(readed != NODECOM_MODEM_NV_SIZE)
                {
                    goto END;
                }
                data[0] = (const unsigned char)(itemid & 0XFF);
                data[1] = (const unsigned char)((itemid>>8)&0XFF);
                found = 1;
                break;
            }
            else
            {
                if(lseek(fd, NODECOM_MODEM_NV_SIZE, SEEK_CUR) < 0)
                {
                    goto END;
                }
            }
        }
    }
END:
    if(fd >= 0)
    {
        close(fd);
    }
    if(found)
    {
        return NODECOM_MODEM_NV_SIZE+2;
    }
    else
    {
        return -1;
    }
}
int Read_NV_ITEM(char* diagnose_interface,char* backup_file)
{
    FILE* fp_nv = NULL;
    int nLen;
    unsigned char rcv_buf[NODECOM_MODEM_NV_SIZE+32];
    int i = 0;
//to test by caogang
    FILE* fp_nv_list = NULL;
	unsigned char buff_nv_list[256];

    int diag_fd = mu_opencom(diagnose_interface);

    if(diag_fd < 0)
    {
        cprintf("open diagnosetic port %s failed.\n",diagnose_interface);
        return -1;
    }

    if((fp_nv = fopen(backup_file, "w" )) == NULL)
    {
        cprintf("failed open backupfile %s\n", backup_file);
        close(diag_fd);
        return -1;
    }
    
//to test by caogang
    if((fp_nv_list = fopen(NV_LOW_LIST_PATH, "r")) == NULL)
	{
        cprintf("failed open nvlist %s\n", NV_LOW_LIST_PATH);
        fclose(fp_nv);
        close(diag_fd);
        return -1;
	}

    memset(buff_nv_list, 0, sizeof(buff_nv_list));
    //for(i = 0;nvids[i] != -1;i++)
	while(NULL != fgets(buff_nv_list, sizeof(buff_nv_list), fp_nv_list))
    {
	    char buff_index[256];
	    int index = 0;
		memset(buff_index,0,sizeof(buff_index));
        while(index<strlen(buff_nv_list))
		{
            if( '\r' != buff_nv_list[index]  || 
			'\n' != buff_nv_list[index] || 
			' ' != buff_nv_list[index])
			{
                buff_index[index] = buff_nv_list[index];
			}
            index++;
		}
        memset(buff_nv_list,0,sizeof(buff_nv_list));

        index = atoi(buff_index);
		cprintf("func:%s Ready Backup NV(%d)\n",__func__, index);

		if (-1 == index)
		{		    
            break;
		}
        nLen = read_nv_item(diag_fd, index, rcv_buf, sizeof(rcv_buf));

        if(nLen == 0)
        {
		   continue;
        }
		else if (nLen > 0)
		{		
            cprintf("func:%s NV(%d) backup NV OK\n",__func__,index);
		}
        else
        {
            nLen = read_nv(file_update.nvfile2, (unsigned short)index, rcv_buf, sizeof(rcv_buf));
            if(nLen >=0)
            {
                cprintf("nv %d using old\n",index);
            }
        }
        if(nLen >=0)
        {
            if (!fwrite(rcv_buf, nLen, 1, fp_nv))
            {
                fclose (fp_nv);
                close(diag_fd);
				fclose (fp_nv_list);
                return -1;
            }
        }
    }
    fclose(fp_nv);
    close(diag_fd);
	fclose(fp_nv_list);
    return 0;
}
int Read_High_NV_ITEM(char* diagnose_interface,char* backup_file)
{
    int i = 0;
    int fp_record;
    int nLen;
    unsigned char rcv_buf[0x1000];
    int diag_fd;

//to test by caogang
    FILE* fp_nv_list = NULL;
	unsigned char buff_nv_list[256];

    if(NULL==diagnose_interface)
    {
        cprintf("invalid diag interface name %s\n",diagnose_interface);
        return -1;
    }
    diag_fd = mu_opencom(diagnose_interface);

    if(diag_fd < 0)
    {
        cprintf("open diagnosetic port %s failed.\n",diagnose_interface);
        return -1;
    }
    if((fp_record = open(backup_file, O_RDWR | O_CREAT)) < 0)
    {
        cprintf("failed open backupfile %s\n",backup_file);
        close(diag_fd);
        return -1;
    }

//to test by caogang
    if((fp_nv_list = fopen(NV_HIGH_LIST_PATH, "r")) == NULL)
	{
        cprintf("failed open nvlist %s\n", NV_HIGH_LIST_PATH);
        close (fp_record);
        close(diag_fd);
        return -1;
	}

    memset(buff_nv_list, 0, sizeof(buff_nv_list));
	//for(i = 0;modem_high_nv[i] != -1;i++)
	while(NULL != fgets(buff_nv_list, sizeof(buff_nv_list), fp_nv_list))
    {
	    char buff_index[256];
	    int index = 0;
		memset(buff_index,0,sizeof(buff_index));
        while(index<strlen(buff_nv_list))
		{
            if( '\r' != buff_nv_list[index]  || 
			'\n' != buff_nv_list[index] || 
			' ' != buff_nv_list[index])
			{
                buff_index[index] = buff_nv_list[index];
			}
            index++;
		}
        memset(buff_nv_list,0,sizeof(buff_nv_list));

        index = atoi(buff_index);
		cprintf("func:%s Ready Backup High NV(%d)\n",__func__, index);

		if (-1 == index)
		{		    
            break;
		}

        nLen = read_high_nv_item(diag_fd, index, rcv_buf, sizeof(rcv_buf));
        if(nLen >= 0)
        {
            cprintf("func:%s high NV(%d) backup NV OK\n",__func__, index);
        }
        else
        {
            nLen = read_high_nv(file_update.highnv2, (unsigned short)index, rcv_buf, sizeof(rcv_buf));
            if(nLen >= 0)
            {
                cprintf("nv %d using old\n", index);
            }
        }
        if(nLen >= 0)
        {
            if(!write(fp_record, rcv_buf, nLen))
            {
                close (fp_record);
                close(diag_fd);
			    fclose(fp_nv_list);
                return -1;
            }
        }
    }

    close(diag_fd);
    close(fp_record);
	fclose(fp_nv_list);
    return 0;
}
int Write_High_NV_ITEM(char* diagnose_interface, char* backup_file)
{
    int fp_record = -1;
    unsigned short nv_id = 0;
    unsigned short nv_data_size = 0;
    unsigned char rcv_buf[0x1000];

    int diag_fd = mu_opencom(diagnose_interface);

    if(diag_fd < 0)
    {
        cprintf("open diagnosetic port %s failed.\n", diagnose_interface);
        return -1;
    }

    if((fp_record = open(backup_file, O_RDWR)) < 0)
    {
        cprintf("failed open backupfile %s\n", backup_file);
        close(diag_fd);
        return -1;
    }
   
    memset(&nv_id, 0, sizeof(nv_id));
    while(read(fp_record, &nv_id, sizeof(nv_id)) == sizeof(nv_id))
    {
//to test by caogang	
//        nv_id = bswap_16(nv_id);
        memset(&nv_data_size, 0, sizeof(nv_data_size));
        if(read(fp_record, &nv_data_size, sizeof(nv_data_size)) != sizeof(nv_data_size))
        {
            cprintf("read NV data length failed \n");
            break;
        }
//to test by caogang		
//        nv_data_size = bswap_16(nv_data_size);
        cprintf("to restore NV id=%u nv_data_len=%u\n", nv_id, nv_data_size);
        if(nv_data_size > sizeof(rcv_buf))
        {
            cprintf("nv size too big\n");
            break;
        }
        if(read(fp_record, rcv_buf, nv_data_size) != nv_data_size)
        {
            cprintf("read NV data failed \n");
            break;
        }

        if(write_high_nv_item(diag_fd, nv_id, rcv_buf, nv_data_size) < 0)
        {
            cprintf("write_high_nv_item failed \n");
        }
		else
		{
            cprintf("func:%s restore NV No%d OK\n",__func__, nv_id);
		}
    }

    close(fp_record);
    close(diag_fd);
    cprintf("restore high nv finish\n");
    return 0;
}
int Write_NV_ITEM(char* diagnose_interface, char* backup_file)
{
    struct stat stat_buf;
    int blockcount = 0;
    int blocksize = NODECOM_MODEM_NV_SIZE + 2;
    FILE* fp_nv = NULL;
    int i = 0;
    unsigned char rcv_buf[NODECOM_MODEM_NV_SIZE + 32];

    int diag_fd = mu_opencom(diagnose_interface);

    if(diag_fd < 0)
    {
        cprintf("open diagnosetic port %s failed.\n",diagnose_interface);
        return -1;
    }
    if(stat(backup_file, &stat_buf) == 0)
    {
        blockcount = stat_buf.st_size/blocksize;
        cprintf("block count= %d\n", blockcount);
    }
 
    if((fp_nv = fopen(backup_file, "rb")) == NULL)
    {
        cprintf("open nv_bak file err\n");
        close(diag_fd);
        return -1;
    }
    for(i = 0;i < blockcount;i++)
    {
        memset(rcv_buf, 0, sizeof(rcv_buf));
        if (blocksize != fread (rcv_buf, 1, blocksize, fp_nv))
        {  
            cprintf("read size ==%d failed.\n", blocksize);
            close(diag_fd);
            return -1;
        }
        //cprintf("restore NV No : %d\n", i);
        if(write_nv_item(diag_fd, rcv_buf, blocksize) < 0)
        {
            cprintf("restore NV No%d : failed\n",i);
        }
		else
		{
            cprintf("func:%s restore NV No%d : OK\n",__func__, i);
		}
    }
    fclose(fp_nv);
    close(diag_fd);
	cprintf("restore nv finish\n");
    return 0;
}
int back_up_nv(char* at_interface, char* diag_interface)
{
    int at_fd = -1;
    int status;
    char cmd[256];
    at_fd = mu_opencom(at_interface);
    if(at_fd <= 0)
    {
        cprintf("open at port %s failed,at fd=%d\n", at_interface, at_fd);
        return -1;
    }
//    cprintf("open at port successful.\n");
    if(change_mode(at_fd, 5) < 0)
    {
        cprintf("change mode failed\n");
    }
    status = BackupInfo(at_fd);
    if(status < 0)
    {
        cprintf("call BackupInfo failed %d.\n", status);
        //close(at_fd);
        //return -1;
    }

    status = Read_NV_ITEM(diag_interface, file_update.nvfile);
    if(status < 0)
    {
        cprintf("call Read_NV_ITEM failed %d.\n",status);
        /*
        if(check_nv_file("file_update.nvfile2") < 0)
        {
            //close(at_fd);
            //return -1;
        }
        */
    }
    else
    {
        cprintf("bakup normal nv items successful.\n");
        sprintf(cmd,"busybox mv %s %s", file_update.nvfile,file_update.nvfile2);
        system(cmd);
    }

 status = Read_High_NV_ITEM(diag_interface, file_update.highnv);
    if(status<0)
    {
        cprintf("call Read_HIGH_NV_ITEM failed %d.\n",status);
        /*
        if(check_highnv_file("file_update.highnv2") < 0)
        {
            //close(at_fd);
            //return -1;
        }
        */
    }
    else
    {
        cprintf("bakup HIGH_nv items successful.\n");
        sprintf(cmd,"busybox mv %s %s", file_update.highnv,file_update.highnv2);
        system(cmd);
    }

    close(at_fd);
    return 0;
}
int RestoreInfo(int fd_at)
{
    char data[128];
    char cmdstr[128];
    int id;
    memcpy(&id, "LCSN", 4);
    memset(data, 0, sizeof(data));
    if(get_item(file_update.modem_info2, id, data, sizeof(data)) < 0)
    {
        cprintf("Get SN failed\n");
    }
    else
    {
        sprintf(cmdstr, "AT+LCTSN=1,5,\"%s\"\r", data);
        memset(data, 0, sizeof(data));
        if(exec_at(fd_at, cmdstr, data, sizeof(data)) < 0)
        {
            cprintf("Restore SN at failed\n");
        }
        else
        {
            if(strstr(data, "OK\r"))
            {
                cprintf("Restore SN OK\n");
            }
            else
            {
                cprintf("Restore SN failed\n");
            }
        }
    }
    memcpy(&id, "IMEI", 4);
    memset(data, 0, sizeof(data));
    if(get_item(file_update.modem_info2, id, data, sizeof(data)) < 0)
    {
        cprintf("Get IMEI failed\n");
    }
    else
    {
        sprintf(cmdstr, "AT+LCTSN=1,7,\"%s\"\r", data);
        memset(data, 0, sizeof(data));
        if(exec_at(fd_at, cmdstr, data, sizeof(data)) < 0)
        {
            cprintf("Restore IMEI at failed\n");
        }
        else
        {
            if(strstr(data, "OK\r"))
            {
                cprintf("Restore IMEI OK\n");
            }
            else
            {
                cprintf("Restore IMEI failed\n");
            }
        }
    }
    memcpy(&id, "TEST", 4);
    memset(data, 0, sizeof(data));
    if(get_item(file_update.modem_info2, id, data, sizeof(data)) < 0)
    {
        cprintf("Get TEST failed\n");
    }
    else
    {
        sprintf(cmdstr, "AT+TESTINF2=\"%s\"\r", data);
        memset(data, 0, sizeof(data));
        if(exec_at(fd_at, cmdstr, data, sizeof(data)) < 0)
        {
            cprintf("Restore TEST at failed\n");
        }
        else
        {
            if(strstr(data, "OK\r"))
            {
                cprintf("Restore TEST OK\n");
            }
            else
            {
                cprintf("Restore TEST failed\n");
            }
        }
    }

    return 0;
}
int mu_restore_nv(char* at_interface, char* diag_interface)
{    
    int at_fd = -1;
    int status = 0;
    char data[128];

    at_fd = mu_opencom(at_interface);
    if(at_fd <= 0)
    {
        cprintf("open at port %s failed,at fd=%d\n", at_interface, at_fd);
        return -1;
    }
    if(change_mode(at_fd, 5) < 0)
    {
        cprintf("change mode failed\n");
    }

    status = Write_High_NV_ITEM(diag_interface,file_update.highnv2);
    if(status<0)
    {
        cprintf("call Write_High_NV_ITEM failed %d.\n",status);
        //close(at_fd);
        //return -1;
    }
    else
    {
        cprintf("high nv restored successful.\n");
    }  

    status = Write_NV_ITEM(diag_interface, file_update.nvfile2);
    if(status < 0)
    {
        cprintf("call Write_NV_ITEM failed %d.\n",status);
        //close(at_fd);
        //return -1;
    }
    else
    {
        cprintf("nv restored successful.\n");
    }  

    status = RestoreInfo(at_fd);
    if(status < 0)
    {
        cprintf("call BackupInfo failed %d.\n",status);
        //close(at_fd);
        //return -1;
    }
    if(change_mode(at_fd, 1) < 0)
    {
        cprintf("change mode failed\n");
    }

    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, "ATE0\r", data, sizeof(data)) < 0 || strstr(data, "OK\r") == NULL)
    {
        cprintf("ATE0 failed\n");
    }
    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, "AT+URCIND=1\r", data, sizeof(data)) < 0 || strstr(data, "OK\r") == NULL)
    {
        cprintf("AT+URCIND=1 failed\n");
    }
    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, "AT+NWTYPEIND=1\r", data, sizeof(data)) < 0 || strstr(data, "OK\r") == NULL)
    {
        cprintf("AT+NWTYPEIND=1 failed\n");
    }
    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, "AT+PSDIALIND=1\r", data, sizeof(data)) < 0 || strstr(data, "OK\r") == NULL)
    {
        cprintf("AT+PSDIALIND=1 failed\n");
    }
    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, "AT+SIGNALIND=1\r", data, sizeof(data)) < 0 || strstr(data, "OK\r") == NULL)
    {
        cprintf("AT+SIGNALIND=1 failed\n");
    }

    close(at_fd);
    return 0;
}
