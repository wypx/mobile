#!/bin/bash

echo "Cao Gang"
echo "==========================================="
echo "* start compile !"
echo "==========================================="

echo $LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/test/work/fastboot

export LC_GENERL_INCLUDE_DIR=.
export LC_LIB_DIR=.

export _NODECOM_MDM9x07_FEATURE=yes

export CROSS_COMPILE = 
export CC = ${CROSS_COMPILE}gcc

rm -rf ./bin
mkdir -p ./bin
make -f Makefile clean
make -f Makefile 
make -f Makefile install

