#ifndef __MU_API_H
#define __MU_API_H
#define NODECOM_MODEM_NV_SIZE 128
struct mem_info_t
{
    unsigned char save;
    unsigned int base;
    unsigned int len;
    char name[32];
    char path[64];
    struct mem_info_t* next;
};


struct file_info_st 
{
    char version_t[128];
    unsigned int bNV;
    char diagnose_inface[128];
    char at_inface[128];
    char tmppath[256];
    char imagefile[256];
};

struct file_update_info
{
    char uplog[256];
    char uplog2[256];
    char nv_low_list[256];
    char nv_high_list[256];
    char nvfile[256];
    char nvfile2[256];
    char highnv[256];
    char highnv2[256];
    char modem_info[256];
    char modem_info2[256];
};

struct file_info_st file_info;
struct file_update_info file_update;

int exec_at(int fd_at,char* strATCommand, char* strRec, size_t size);
int read_nv_item(int diag_fd, int nvid, unsigned char* buf, int size);
int read_high_nv_item(int diag_fd, int nvid, unsigned char* buf, int size);
int write_high_nv_item(int diag_fd, int nv_id, unsigned char* buf, int nv_data_size);
int write_nv_item(int diag_fd, unsigned char* buf, int nv_data_size);
int check_dload_mode(char* diagnose_interface);
int reset_cmd(int fd_diagnose);
int dload_partition_table_download(int fd_diagnose, FILE* fileToBeChecked, int length, int* readed);
int dload_image(int fd_diagnose, FILE* fileToBeChecked, int length, char* ptn, int* readed);
int HexDownload(int fd_diagnose, FILE* fileToBeChecked, int length, int ehex, int* readed);
int dload_switch_cmd(char* diagnose_interface);
int send_offlin_cmd(char* diagnose_interface);
int change_mode(int at_fd, int mode);
int mu_opencom(char* diagnose_interface);
struct mem_info_t* get_mem_info(int fd_diagnose);
int get_mem(int fd_diagnose, struct mem_info_t* info);
int get_mem_gz(int fd_diagnose, struct mem_info_t* info);
int dump_mem(int fd_diagnose);
//<!-- add NODECOM MDM9x07 FEATURE by caogang@20160908
#ifdef _NODECOM_MDM9x07_FEATURE
#define DLOAD_DEBUG_STRLEN_BYTES 20
#define NUM_REGIONS 26
/*debug structure for regular 32 bits ram dump */
typedef struct 
{
  char save_pref;
  unsigned int mem_base;
  unsigned int length;
  char desc[DLOAD_DEBUG_STRLEN_BYTES];
  char filename[DLOAD_DEBUG_STRLEN_BYTES];
} dload_debug_type;
int boot_sahara_handle_no_cmd_id(int fd_diagnose);
int boot_sahara_handle_hello(int fd_diagnose);
int boot_sahara_handle_hello_resp(int fd_diagnose);
int boot_sahara_handle_memory_debug(int fd_diagnose);
int boot_sahara_handle_memory_read_packet(int fd_diagnose);
int boot_sahara_handle_memory_read_packet_resp(int fd_diagnose);
int sahara_get_mem_gz(int fd_diagnose, dload_debug_type* info);
int sahara_get_ddr_mem_gz(int fd_diagnose, char* filename, int length, int append);
int boot_sahara_handle_dump_mem(int fd_diagnose);
int boot_sahara_handle_cmd_switch_mode(int fd_diagnose, int mode);
int set_sahara_dump_path(char *file_path);
#endif //#ifdef _NODECOM_MDM9x07_FEATURE
//end -->
#endif
