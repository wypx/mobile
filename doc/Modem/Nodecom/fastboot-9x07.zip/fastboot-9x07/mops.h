#ifndef __MOPS_H__
#define __MOPS_H__
int back_up_nv(char* at_interface, char* diag_interface);
int mu_restore_nv(char* at_interface, char* diag_interface);
#endif
