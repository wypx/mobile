#include <stdio.h>      
#include <stdlib.h>     
#include <unistd.h>     
#include <sys/types.h>  
#include <sys/stat.h>   
#include <fcntl.h>      
#include <termios.h>    
#include <errno.h>      
#include <string.h>       
#include <sys/wait.h>
#include <time.h>
#include <sys/time.h>
#include <byteswap.h>
#include "dloaddef.h"
#include "zlib.h"
#include "mu_api.h"
#define MIN(a,b) (((a)>(b))?(b):(a))
#define MAX_RETRY_TIMES 5
#define HEX_BUFFER_LEN (0x03F9)
#define FLASH_TX_LOAD_LEN 1024
#define cprintf(fmt, args...) do { \
    FILE *fp = fopen(file_update.uplog, "a"); \
    if (fp) { \
        fprintf(fp, fmt, ## args); \
        fclose(fp); \
    } \
} while (0)


//to test by caogang
typedef enum
{
    Request_OK,
    InterNal_DMSS_use,
    Unrecognizable_command,
    Memory_is_full,
    Command_failed,
    Not_active,
    Bad_command,
    Item_readonly,
    Item_not_defined,
    Free_memory_exhausfed,
    Internal_use
} NV_state;

static void cprintf_hex(const unsigned char *buf, int buf_size)
{
    int  i,j;
    int  total_size = 0;
    int line_cout = buf_size>>4;
    if((buf_size&0x0000000f)!=0)
        line_cout++;
    cprintf("\nhex len %d:\n", buf_size);
    for(i=0;i<line_cout;i++)
    {
        cprintf("\n%x:",total_size);
        for(j=0;j<16;j++)
        {
            total_size++;
            cprintf("%02hhX ",buf[(i<<4)+j]);
            if(((i<<4)+1+j)==buf_size)
            {
                cprintf("\n");
                return;
            }
        }
    }  
}

static void SetTermios(struct termios * p,word uBaudRate)
{
    cfsetispeed(p, uBaudRate);  
    cfsetospeed(p, uBaudRate);   
    p->c_cflag &= ~CSIZE; 
    p->c_cflag |= CS8;

    p->c_cflag |= ~CS8; 
    p->c_cflag &= ~CSTOPB;        //stop bit 1
    p->c_cflag &= ~PARENB;        //no check
    p->c_iflag = 0;//(INPCK | ISTRIP | IGNPAR);//IGNPAR | IUCLC | IXON | IGNCR;p->c_oflag |= 0;
    p->c_lflag = 0;//&= ~(ICANON | ECHO | ECHOE | ISIG);//ICANON;
    
    p->c_lflag  &= ~(ICANON | ECHO | ECHOE | ISIG);  /*Input*/
    p->c_oflag  &= ~OPOST;   /*Output*/
    
    p->c_cc[VINTR] = 0;
    p->c_cc[VQUIT] = 0;
    p->c_cc[VERASE] = 0;
    p->c_cc[VKILL] = 0;
    p->c_cc[VEOF] = 0;
    p->c_cc[VTIME] = 1;
    p->c_cc[VMIN] = 0;
    p->c_cc[VSWTC] = 0;
    p->c_cc[VSTART] = 0;
    p->c_cc[VSTOP] = 0;
    p->c_cc[VSUSP] = 0;
    p->c_cc[VEOL] = 0;
    p->c_cc[VREPRINT] = 0;
    p->c_cc[VDISCARD] = 0;
    p->c_cc[VWERASE] = 0;
    p->c_cc[VLNEXT] = 0;
    p->c_cc[VEOL2] = 0;
}
__attribute((visibility("default")))int mu_opencom(char* diagnose_interface)
{
    int fd;
    fd = open(diagnose_interface,O_RDWR | O_NOCTTY /*| O_NDELAY |O_NONBLOCK*/ );
    if( fd == -1 )
    {
        cprintf("open_port:Unable to open %s -",diagnose_interface);
        return -1;
    }
    else 
    {
        cprintf("open %s -successfully!\n", diagnose_interface);
    }

    struct termios  newio;
      
    /* Get the current optinos for the port ...*/
    tcgetattr(fd,&newio);
    tcflush(fd, TCIOFLUSH);
    SetTermios(&newio,B115200);
    tcflush(fd, TCIFLUSH);
    /* Set the new options for the port ... */
    tcsetattr(fd,TCSANOW,&newio);
    return fd;
}
int WriteToComPort(int fd_diagnose, const unsigned char *data, const unsigned int dwdBlockSize)
{
    int dwdTotalBytesSent = 0;

    tcflush(fd_diagnose, TCIFLUSH);//flush the com port before wriete to com
    
    dwdTotalBytesSent = write(fd_diagnose,data,dwdBlockSize);

    if(dwdTotalBytesSent < 0)
    {
        dwdTotalBytesSent = 0;
        cprintf("Could not write to COMM port\n");   
    }

    return dwdTotalBytesSent;
}
static int ReadComPort(int fd_diagnose, unsigned char *data, const unsigned int dwdBlockSize)
{
    int fs_sel;
    fd_set fs_read;
    struct timeval tv_timeout;
    tv_timeout.tv_sec = 5;
    tv_timeout.tv_usec = 0;
    FD_ZERO(&fs_read);
    FD_SET(fd_diagnose,&fs_read);
    if((fs_sel = select(fd_diagnose+1, &fs_read, NULL, NULL, &tv_timeout)) > 0)
    {
        if(FD_ISSET(fd_diagnose,&fs_read))
        {
            int nRead;
            nRead = read(fd_diagnose, data, dwdBlockSize);
            return nRead;
        }
        else
        {
            cprintf("FD_ISSET <=0 \n");
        }
    }
    else if(fs_sel == 0)
    {
        cprintf("\ntime out 10s\n");
        return 0;
    }
    cprintf("\nerror\n");
    return -1;
}
static int ReadComPortWait(int fd_diagnose, unsigned char *data, const unsigned int dwdBlockSize)
{
    int fs_sel;
    int nRead = 0;
    int index = 0;
    unsigned int alllen;
    fd_set fs_read;
    struct timeval tv_timeout;
    tv_timeout.tv_sec = 5;
    tv_timeout.tv_usec = 0;
    alllen = dwdBlockSize;
    while(alllen > 0)
    {
        FD_ZERO(&fs_read);
        FD_SET(fd_diagnose,&fs_read);
        if((fs_sel = select(fd_diagnose+1, &fs_read, NULL, NULL, &tv_timeout)) > 0)
        {
            if(FD_ISSET(fd_diagnose,&fs_read))
            {
                nRead = read(fd_diagnose, data+index, alllen);
                if(nRead > 0)
                {
                    alllen -= nRead;
                    index += nRead;
                    if(alllen != 0)
                    {
                        cprintf("read again %d %u %u\n", nRead, alllen, dwdBlockSize);
                    }
                }
            }
            else
            {
                cprintf("FD_ISSET <=0 \n");
            }
        }
        else if(fs_sel == 0)
        {
            cprintf("\ntime out\n");
            break;
        }
        else
        {
            cprintf("\nread error\n");
            break;
        }
    }
    return index;
}

//to test by caogang
int rec_NV_state(int nFlag, int index, byte* buf, int nlen)
{
//    char strMsg[256];
//	memset(strMsg,0,sizeof(strMsg));
//    if (nFlag == 0)
//	{
//	    sprintf(strMsg, "R[%d]", index);
//	}
//	else if (nFlag == 1)
//	{
//        sprintf(strMsg, "W[%d]", index);
//	}
	int ret = Bad_command;
	cprintf("func: %s buf[%d]:%04X, buf[%d]%04X\n", __func__, nlen-3, buf[nlen-3], nlen-4, buf[nlen-4]);
    switch (buf[nlen-3])
    {
      case Request_OK:
           ret = Request_OK;//0
           break;
      case InterNal_DMSS_use:
           ret = InterNal_DMSS_use;//1
           break;
      case Unrecognizable_command:
           ret = Unrecognizable_command;//2
           break;
      case Memory_is_full:
           ret = Memory_is_full;//3
           break;
      case Command_failed:
           ret = Command_failed;//4
           break;
      case Not_active:
           ret = Not_active;//5
           break;
      case Bad_command:
           ret = Bad_command;//6
           break;
      case Item_readonly:
           ret = Item_readonly;//7
           break;
      case Item_not_defined:
           ret = Item_not_defined;//8
           break;
      case Free_memory_exhausfed:
           ret = Free_memory_exhausfed;//9
           break;
      case Internal_use://10
           ret = Internal_use;
           break;
      default:
           ret = 100;
           break;
    }
    //==========================================================================
    if (ret == Request_OK)
    {
        switch (buf[nlen-4])
        {
          case Request_OK:              
               ret = Request_OK;//0
               break;
          case InterNal_DMSS_use:
               ret = InterNal_DMSS_use;//1
               break;
          case Unrecognizable_command:
               ret = Unrecognizable_command;//2
               break;
          case Memory_is_full:
               ret = Memory_is_full;//3
               break;
          case Command_failed:
               ret = Command_failed;//4
               break;
          case Not_active:
               ret = Not_active;//5
               break;
         case Bad_command:
               ret = Bad_command;//6
               break;
          case Item_readonly:
               ret = Item_readonly;//7
               break;
          case Item_not_defined:
               ret = Item_not_defined;//8
               break;
          case Free_memory_exhausfed:
               ret = Free_memory_exhausfed;//9
               break;
          case Internal_use://10
               ret = Internal_use;
               break;
          default:
               ret = 100;
               break;
        }
    }
    return ret;
}

int rcv_ack_packet_Backup_Restore(int fd_diagnose, unsigned char *buf, size_t size, unsigned char flagbyte)
{
    enum
    {
        HDLC_HUNT_FOR_FLAG,
        HDLC_GOT_FLAG,
        HDLC_GATHER,
        HDLC_PACKET_RCVD
    } state;
    unsigned char chr;
    word  len = 0;
    word  crc = CRC_16_L_SEED;
    int NumRxBytes = 0;
    cprintf("\nrcv:");
    for (state = HDLC_GATHER; state != HDLC_PACKET_RCVD;) 
    { 
        NumRxBytes = ReadComPort(fd_diagnose, &chr, 1); 
        if (NumRxBytes != 1)
        {
            return -1;
        }
        cprintf("%02hhx ", chr);

        switch(state)
        {
        case HDLC_HUNT_FOR_FLAG:
        {
            if (chr == flagbyte)
            {
                state = HDLC_GOT_FLAG;
            }
        }
        case HDLC_GOT_FLAG:
        {
            if (chr == ASYNC_HDLC_FLAG)
            {
                break;
            }
            else
            {
                len = 0;
                crc = CRC_16_L_SEED;
                state = HDLC_GATHER;
            }
        }
        case HDLC_GATHER:
        {
            if (chr == ASYNC_HDLC_FLAG)
            {
                if (len < MIN_PACKET_LEN)
                {
                    state = HDLC_HUNT_FOR_FLAG;
                    return NAK_EARLY_END; 
                }
                else if (crc != CRC_16_L_OK_NEG)
                {
                    state = HDLC_HUNT_FOR_FLAG;
                    return NAK_INVALID_FCS;
                }
                else
                {
                    state = HDLC_PACKET_RCVD;
                }
                break;
            }

            if (chr == ASYNC_HDLC_ESC)
            {
                chr = (unsigned char)(~CMD_ACK);

                NumRxBytes = ReadComPort(fd_diagnose, &chr, 1);

                if(NumRxBytes != 1)
                {
                    return -1;
                }
                cprintf("%02hhx ",chr);
                chr ^= ASYNC_HDLC_ESC_MASK;
            }

            if (len >= size)
            {
                return NAK_TOO_LARGE;
            }
            else
            {
                buf[len++] = (byte) chr;
                crc = (word)CRC_16_L_STEP(crc, (word) chr);
            }
        break;
        }
        default:
        {
            state = HDLC_HUNT_FOR_FLAG;
            break;
        }
        }
    }
    cprintf("\n");

    return len;
}

int rcv_ack_packet_no_head(int fd_diagnose, unsigned char *buf, size_t size)
{
    enum
    {
        HDLC_GATHER,
        HDLC_PACKET_RCVD
    } state;
    unsigned char chr;
    word  len = 0;
    word  crc = CRC_16_L_SEED;
    int NumRxBytes = 0;
    cprintf("\nrcv:");
    for (state = HDLC_GATHER; state != HDLC_PACKET_RCVD;) 
    { 
        NumRxBytes = ReadComPort(fd_diagnose, &chr, 1); 
        if (NumRxBytes != 1)
        {
            return -1;
        }
        cprintf("%02hhx ", chr);

        switch(state)
        {
            case HDLC_GATHER:
            {
                if (chr == ASYNC_HDLC_FLAG)
                {
                    if (len < MIN_PACKET_LEN)
                    {
                        return NAK_EARLY_END; 
                    }
                    else if (crc != CRC_16_L_OK_NEG)
                    {
                        return -1;
                    }
                    else
                    {
                        state = HDLC_PACKET_RCVD;
                    }
                    break;
                }

                if (chr == ASYNC_HDLC_ESC)
                {
                    NumRxBytes = ReadComPort(fd_diagnose, &chr, 1);
                    if(NumRxBytes != 1)
                    {
                        return -1;
                    }
                    cprintf("%02hhx ",chr);
                    chr ^= ASYNC_HDLC_ESC_MASK;
                }

                if (len >= size)
                {
                    return -1;
                }
                else
                {
                    buf[len++] = (byte) chr;
                    crc = (word)CRC_16_L_STEP(crc, (word) chr);
                }
                break;
            }
            default:
            {
                break;
            }
        }
    }
    cprintf("\n");
    if(state == HDLC_PACKET_RCVD)
    {
        return len;
    }
    return -1;
}
__attribute((visibility("default")))int exec_at(int fd_at,char* strATCommand, char* strRec, size_t size)
{
    int rc = 0;
    int readed = 0;
    int used = 0;
    fd_set readfd;
    struct timeval tv;

    tv.tv_sec = 5;
    tv.tv_usec = 0;

    tcflush(fd_at, TCIFLUSH);

    if(write(fd_at, strATCommand, strlen(strATCommand)) < 0)
    {
        cprintf("Could not send command %s to serial port, %s, %d\n", strATCommand,__FUNCTION__, __LINE__);
    }
    cprintf("send command %s\n",strATCommand);
    
    FD_ZERO(&readfd);
    FD_SET(fd_at, &readfd);
    while(used < size-1)
    {
        rc = select(fd_at + 1, &readfd, NULL, NULL, &tv);
        if(rc > 0)
        {
            if(FD_ISSET(fd_at, &readfd))
            {
                readed = read(fd_at, strRec+used, size-used-1);
                if(readed > 0)
                {
                    used += readed;
                    cprintf("at rcv: %d %s\n", used, strRec);
                    if(strstr(strRec, "OK\r"))
                    {
                        strRec[used] = 0;
                        return used;
                    }
                    else if(strstr(strRec, "ERROR\r"))
                    {
                        strRec[used] = 0;
                        return used;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                return -1;
            }
        }
        else if(0 == rc)
        {
            return 0;
        }
    }

    return -1;
}

__attribute((visibility("default")))int change_mode(int at_fd, int mode)
{
    char cmdstr[16];
    char data[128];
    sprintf(cmdstr, "AT+CFUN=%d\r", mode);
    memset(data, 0, sizeof(data));
    if(exec_at(at_fd, cmdstr, data, sizeof(data)) < 0)
    {
        cprintf("exec at failed\n");
        return -1;
    }
    cprintf("rcv:%s\n", data);
    if(strstr(data, "OK\r"))
    {
        return 0;
    }
    cprintf("change mode failed\n");
    return -1;
}

int transmit_packet(int fd_diagnose, pkt_buffer_type  *pkt)
{
    unsigned char tr[4096];
    int NumTxBytes = 0;  

    tr[0] = ASYNC_HDLC_FLAG;

    memcpy(&tr[1], pkt->buf, (pkt->length + 1));
    //cprintf_hex(tr, pkt->length+2);
    NumTxBytes = WriteToComPort(fd_diagnose,(unsigned char *)tr, (pkt->length + 2));
    return NumTxBytes;
}
static int transmit_packet_no_leading_flag(int fd_diagnose, pkt_buffer_type  *pkt) 
{
    unsigned char* data = (unsigned char*) pkt->buf;
    //cprintf_hex(data, pkt->length + 1);

    return WriteToComPort(fd_diagnose, data, (pkt->length + 1)); 
 
}
void add_byte_to_packet(pkt_buffer_type  *pkt, const byte val)
{

    if (pkt->broken != FALSE)   /* If the packet is broken already, */
    {
        cprintf("already broken.\n");
        return;                  /* Don't do anything. */
    }
       /* Check if the byte needs escaping for transparency. */
    if (val == ASYNC_HDLC_FLAG || val == ASYNC_HDLC_ESC)
    {
        /* Check for an impending overflow. */
        if (pkt->length+2+ROOM_FOR_CRC+ROOM_FOR_FLAG >= MAX_RESPONSE_LEN)
        {
            pkt->broken = TRUE;     /* Overflow.  Mark this packet broken. */
            return;
        }

        /* No overflow.  Escape the byte into the buffer. */
        pkt->buf[pkt->length++] = ASYNC_HDLC_ESC;
        pkt->buf[pkt->length++] = val ^ (byte)ASYNC_HDLC_ESC_MASK;//0x5d or 0x5e
    }

    else     /* Byte doesn't need escaping. */
    {
        /* Check for an impending overflow. */
        if (pkt->length+1+ROOM_FOR_CRC+ROOM_FOR_FLAG >= MAX_RESPONSE_LEN)
        {
            pkt->broken = TRUE;     /* Overflow.  Mark this packet broken. */
            return;
        }
        /* No overflow.  Place the byte into the buffer. */
        pkt->buf[pkt->length++] = val;
    }
}
void finish_building_packet(pkt_buffer_type  *pkt)
{
    unsigned int  crc;
    /* Cyclic Redundancy Check for the packet we've built. */

    int  i;
    /* Index for scanning through the packet, computing the CRC. */

    if (pkt->broken == FALSE)
    {
    /* Compute the CRC for all the bytes in the packet. */
        crc = CRC_16_L_SEED;
        for (i=0; i < pkt->length; i++)
        {
            /* According to the DMSS Download Protocol ICD, the CRC should only
            * be run over the raw data, not the escaped data, so since we
            * escaped the data as we built it, we have to back out any escapes
            * and uncomplement the escaped value back to its original value */
            if (pkt->buf[i] != ASYNC_HDLC_ESC)
            {
                crc = CRC_16_L_STEP(crc, (word) pkt->buf[i]);
            }
            else
            {
                i++;
                crc = CRC_16_L_STEP(crc, (word)(pkt->buf[i] ^ (byte)ASYNC_HDLC_ESC_MASK));
            }
        }
        crc ^= CRC_16_L_SEED;
        /* Add the CRC to the packet */
        ADD_CRC_TO_PACKET(*pkt,crc);  
        /* Add a flag to the packet.This can't use the regular
        add_byte_to_packet() function because it's a flag. */
        pkt->buf[pkt->length] = ASYNC_HDLC_FLAG;  
                                              
    }
    else
    {        
        (void) memcpy((void*)pkt->buf, rsp_nak_invalid_len,
             sizeof(rsp_nak_invalid_len));    /* Substitute a NAK */
    }

}

int rcv_ack_packet_with_head(int fd_diagnose, unsigned char *buf, size_t size)  
{
    enum
    {
        HDLC_HUNT_FOR_FLAG,
        HDLC_GATHER,
        HDLC_PACKET_RCVD
    } state;
    unsigned char chr;
    word  len = 0;
    word  crc = 0;
    int NumRxBytes = 0;
    cprintf("\nrcv:");
    for (state = HDLC_HUNT_FOR_FLAG; state != HDLC_PACKET_RCVD;) 
    { 
        NumRxBytes = ReadComPort(fd_diagnose, &chr, 1); 
        if (NumRxBytes != 1)
        {
            return -1;
        }
        cprintf("%02hhx ", chr);

        switch(state)
        {
            case HDLC_HUNT_FOR_FLAG:
            {
                if (chr == ASYNC_HDLC_FLAG)
                {
                    state = HDLC_GATHER;
                    len = 0;
                    crc = CRC_16_L_SEED;
                    state = HDLC_GATHER;
                }
                break;
            }
            case HDLC_GATHER:
            {
                if (chr == ASYNC_HDLC_FLAG)
                {
                    if (len < MIN_PACKET_LEN)
                    {
                        return NAK_EARLY_END; 
                    }
                    else if (crc != CRC_16_L_OK_NEG)
                    {
                        return -1;
                    }
                    else
                    {
                        state = HDLC_PACKET_RCVD;
                    }
                    break;
                }

                if (chr == ASYNC_HDLC_ESC)
                {
                    NumRxBytes = ReadComPort(fd_diagnose, &chr, 1);
                    if(NumRxBytes != 1)
                    {
                        return -1;
                    }
                    cprintf("%02hhx ",chr);
                    chr ^= ASYNC_HDLC_ESC_MASK;
                }

                if (len >= size)
                {
                    return -1;
                }
                else
                {
                    buf[len++] = (byte) chr;
                    crc = (word)CRC_16_L_STEP(crc, (word) chr);
                }
                break;
            }
            default:
            {
                break;
            }
        }
    }
    cprintf("\n");
    if(state == HDLC_PACKET_RCVD)
    {
        return len;
    }
    return -1;
}
__attribute((visibility("default")))int read_nv_item(int diag_fd, int nvid, unsigned char* buf, int size)
{
    pkt_buffer_type params_buf;
    int nTry = 0;
    int nLen;
    unsigned char rcv_buf[MAX_PACKET_LEN];
    int j = 0;

    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x26);
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(nvid & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((nvid>>8) & 0XFF));
    for(j = 0;j < NODECOM_MODEM_NV_SIZE;j++)
    {
        ADD_BYTE_TO_PACKET(params_buf, 0x00);
    }

//    ADD_BYTE_TO_PACKET(params_buf, 0x00);
//    ADD_BYTE_TO_PACKET(params_buf, 0x00);

//to test by caogang
    ADD_BYTE_TO_PACKET(params_buf, 0xCC);
    ADD_BYTE_TO_PACKET(params_buf, 0xCC);

    FINISH_BUILDING_PACKET(params_buf);

//    nTry = 0;
//    do
//    {
//        tcflush(diag_fd, TCIOFLUSH);
//        transmit_packet_no_leading_flag(diag_fd, &params_buf);
//        memset(rcv_buf, 0, sizeof(rcv_buf));
//        nLen = rcv_ack_packet_no_head(diag_fd, rcv_buf, sizeof(rcv_buf));
//        if(nLen != 135 || rcv_buf[0] != 0X26 || rcv_buf[nLen - 3] != 0x00 || rcv_buf[nLen - 4] != 0x00)
//        {
//            cprintf("read nv %d failed %02hhx %02hhx\n", nvid, rcv_buf[nLen - 3], rcv_buf[nLen - 4]);
//            if(rcv_buf[nLen - 3] == 0x00 && rcv_buf[nLen - 4] == 0x05)
//            {
//                cprintf("nv %d inactive\n", nvid);
//                break;
//            }
//            sleep(1);
//            continue;
//        }
//        if(size <  nLen - 5)
//        {
//            cprintf("nv %d size %d not enough %d\n", nvid, size, nLen);
//           break;
//        }
//        memcpy(buf, rcv_buf+1, nLen - 5);
//        return (nLen - 5);
//        
//    }while(nTry++ < 5);
//    return -1;

//to test by caogang
#if 1
    nTry = 0;
    do
    {
        tcflush(diag_fd, TCIOFLUSH);
        transmit_packet_no_leading_flag(diag_fd, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        nLen = rcv_ack_packet_Backup_Restore(diag_fd, rcv_buf, sizeof(rcv_buf),0x27);

        nTry ++;
        if (nTry == 99)
        {
            cprintf("func:%s line:%d  %d:Fail to backup NV\n", __func__, __LINE__, nvid);
            return -1;
        }
        if (nTry >=2)
        {
            usleep(500*1000);
        }
    }
    while(rcv_buf[0] != 0x26 && nTry < 500);

    int ret = (int)rec_NV_state(0, nvid, rcv_buf, nLen);
    if (Request_OK == ret)
    {
        cprintf("func:%s line:%d backup NV:%d OK\n", __func__, __LINE__, nvid);
        if(size <  nLen - 5)
        {
            cprintf("nv %d size %d not enough %d\n", nvid, size, nLen);
            return -1;
        }
        memcpy(buf, rcv_buf+1, nLen - 5);
        return (nLen - 5);
    }
    else if (Not_active == ret || Bad_command == ret)
    {
        return 0;
    }

    return -1;
#endif	
}
__attribute((visibility("default")))int read_high_nv_item(int diag_fd, int nvid, unsigned char* buf, int size)
{
    pkt_buffer_type params_buf;
    int nTry;
    int nLen;
    unsigned short nv_len;
    unsigned char rcv_buf[MAX_PACKET_LEN];

    memset(&params_buf,0,sizeof(params_buf));
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x4b);
    ADD_BYTE_TO_PACKET(params_buf, 0x0B);
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(36 & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((36>>8)&0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(604 & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((604>>8)&0XFF));
    ADD_BYTE_TO_PACKET(params_buf, 0x00);
    ADD_BYTE_TO_PACKET(params_buf, 0x00);
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(144 & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((144>>8)&0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(nvid & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((nvid>>8)&0XFF));

    FINISH_BUILDING_PACKET(params_buf);
   
    nTry = 0;
    do
    {
        tcflush(diag_fd, TCIOFLUSH);
        transmit_packet_no_leading_flag(diag_fd, &params_buf);
        nLen = rcv_ack_packet_no_head(diag_fd, rcv_buf, sizeof(rcv_buf));
        if(nLen < 12 || rcv_buf[10] != 0x00 || rcv_buf[11] != 0x00 || rcv_buf[0] != 0x4b)
        {
            cprintf("backup %d failed %d\n", nvid, nLen);
            cprintf("%02hhx %02hhx %02hhx\n", rcv_buf[0], rcv_buf[10], rcv_buf[11]);
            if(rcv_buf[10] == 0x04 && rcv_buf[11] == 0x00)
            {
                cprintf("nv %d inactive\n", nvid);
                break;
            }
            sleep(1);
            continue;
        }
        else
        {
            memcpy(&nv_len, rcv_buf + 14, sizeof(nv_len));
//to test by caogang            
			//nv_len = bswap_16(nv_len);
            nLen = (int)nv_len;
            if(size < 4 + nLen)
            {
                cprintf("nv %d size %d not enough %d\n", nvid, size, nLen);
                break;
            }
            memcpy(buf, rcv_buf + 12, 4 + nLen);
            return (4 + nLen);
        }
    }while(nTry++ < 5);

    return -1;
}
__attribute((visibility("default")))int write_high_nv_item(int diag_fd, int nv_id, unsigned char* buf, int nv_data_size)
{
    pkt_buffer_type params_buf;
    int i = 0;
    int nTry;
    int nLen;
    unsigned char rcv_buf[MAX_PACKET_LEN];

    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x4b);
    ADD_BYTE_TO_PACKET(params_buf, 0x0B);
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(36 & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((36>>8)&0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(605 & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((605>>8)&0XFF));
    ADD_BYTE_TO_PACKET(params_buf, 0x00);
    ADD_BYTE_TO_PACKET(params_buf, 0x00);
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(14 & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((14>>8)&0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(nv_id & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((nv_id>>8)&0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)(nv_data_size & 0XFF));
    ADD_BYTE_TO_PACKET(params_buf, (const unsigned char)((nv_data_size>>8)&0XFF));

    for(i = 0;i < nv_data_size;i++)
    {
        ADD_BYTE_TO_PACKET(params_buf, buf[i]);
    }

    FINISH_BUILDING_PACKET(params_buf);
    nTry = 0;
    do
    {
        tcflush(diag_fd, TCIOFLUSH);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        if(transmit_packet_no_leading_flag(diag_fd, &params_buf) <= 0)
        {
            cprintf("transmit packet failed, retry.\n");
            sleep(1);
            continue;
        }
        nLen = rcv_ack_packet_no_head(diag_fd, rcv_buf, sizeof(rcv_buf));
        if(nLen < 14 || rcv_buf[0] != 0X4B || rcv_buf[10] != 2 || rcv_buf[11] != 0)
        {
            cprintf("write high failed %d %02hhx\n", nLen, rcv_buf[0]);
            sleep(1);
            continue;
        }
        else
        {
            return 0;
        }
    }while(nTry++ < 5);

    return -1;
}
__attribute((visibility("default")))int write_nv_item(int diag_fd, unsigned char* buf, int nv_data_size)
{
    pkt_buffer_type params_buf;
    int j = 0;
    int nTry;
    int nLen;
    unsigned char rcv_buf[MAX_PACKET_LEN];

    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x27);
    for(j = 0;j < nv_data_size;j++)
    {
        ADD_BYTE_TO_PACKET(params_buf, buf[j]);
    }
    ADD_BYTE_TO_PACKET(params_buf, 0x00);
    ADD_BYTE_TO_PACKET(params_buf, 0x00);

    FINISH_BUILDING_PACKET(params_buf);

//    nTry = 0;
//    do
//    {
//        tcflush(diag_fd, TCIOFLUSH);
//        memset(rcv_buf, 0, sizeof(rcv_buf));
//        transmit_packet_no_leading_flag(diag_fd, &params_buf);
//        nLen = rcv_ack_packet_no_head(diag_fd, rcv_buf, sizeof(rcv_buf));
//        if(nLen < 120 || rcv_buf[0] != 0X27 || rcv_buf[nLen - 3] != 0x00 || rcv_buf[nLen - 4] != 0x00)
//        {
//            cprintf("write nv %d failed %02hhx %02hhx\n", nLen, rcv_buf[nLen - 3], rcv_buf[nLen - 4]);
//            sleep(1);
//            continue;
//        }
//        else
//        {
//            return 0;
//        }
//    }while(nTry++ < 5);
//    return -1

//to test by caogang
#if 1
    nTry = 0;
    do
    {
        tcflush(diag_fd, TCIOFLUSH);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        transmit_packet_no_leading_flag(diag_fd, &params_buf);
        nLen = rcv_ack_packet_Backup_Restore(diag_fd, rcv_buf, sizeof(rcv_buf), 0x26);
        if (rcv_buf[0] != 0x27)
        {
            cprintf("write nv %d failed %02hhx %02hhx\n", nLen, rcv_buf[nLen - 3], rcv_buf[nLen - 4]);
            usleep(500*1000);
            nTry ++;
        }

        if (nTry == 99)
        {
            return -1;
        }
        
        if (nTry > 2)
        {
            usleep(500*1000);
        }
    }while(rcv_buf[0] != 0x27 && nTry < 500);

    int iRtn = rec_NV_state(1, 0, rcv_buf, nLen);
    if (Request_OK == iRtn)
    {
        return 0;
    }
    return -1;
#endif
}
int nop_cmd(int fd_diagnose)  
{
    int i = 0;
    int ret;
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, CMD_NOP);
    FINISH_BUILDING_PACKET(params_buf);

    unsigned char rcv_buf[MAX_PACKET_LEN]={0};
    for(i = 0;i < 3;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret == 3 && rcv_buf[0] == 0x02)
        {
            return 0;
        }
        else
        {
            cprintf("ret == %d", ret);
            sleep(1);
            continue;
        }
    }
    return -1;
}

int write_32bit_cmd(int fd_diagnose,unsigned int write_addr, 
                        unsigned char *file_buf, int write_len)
{
    int NumRxBytes = 0;
    int index = 0;
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, CMD_WRITE_32BIT);
    ADD_DWORD_TO_PACKET(params_buf, write_addr);
    ADD_WORD_TO_PACKET(params_buf, write_len);
    unsigned char RxBuffer[32]={0};
    for(index = 0; index < write_len; index++)
    {
        ADD_BYTE_TO_PACKET(params_buf, file_buf[index]);
    }
    FINISH_BUILDING_PACKET(params_buf);
    tcflush(fd_diagnose, TCIOFLUSH);
    transmit_packet(fd_diagnose, &params_buf);
    NumRxBytes = rcv_ack_packet_with_head(fd_diagnose, RxBuffer, sizeof(RxBuffer));
    cprintf_hex(RxBuffer, NumRxBytes);
     
    if(NumRxBytes == 3 && RxBuffer[0] == 0x02)
    {
        return 0;
    }
    return -1;
}
int FlashSendRamProgram(int fd_diagnose, FILE* fileToBeChecked, int length, unsigned int addr, int* readed)
{
    unsigned int   currentAddress = 0;
    unsigned int   count, numBytesRead = 0, dataSize;
    int need_read;

    dataSize = length; 
    unsigned char TxBuffer[HEX_BUFFER_LEN];

    currentAddress = addr;
    while(dataSize > 0)
    {
        need_read = MIN(sizeof(TxBuffer), dataSize);
        numBytesRead = fread(TxBuffer, 1, need_read, fileToBeChecked);
        if(numBytesRead != need_read)
        {
            cprintf("read hex file failed %d\n", numBytesRead);
            return -1;
        }
        if(readed)
        {
            *readed += numBytesRead;
        }
        count = 0;
        while(count < MAX_RETRY_TIMES)
        {
            if(!write_32bit_cmd(fd_diagnose, currentAddress, TxBuffer, numBytesRead))
            {
                cprintf("\nsuccess to write Addr %X\n", currentAddress);
                break;
            }
            else
            {
                cprintf("retry to write Addr %X\n", currentAddress);
                count++;
            }
        }
        if(count == MAX_RETRY_TIMES)
        {
            cprintf("fail to write Addr %X\n",currentAddress);
            return -1;
        }
        currentAddress += numBytesRead;
        dataSize -= numBytesRead;
    }

    return 0;
}

int go_cmd(int fd_diagnose, unsigned int go_addr)
{
    int i = 0;
    int ret;
    unsigned char rcv_buf[MAX_PACKET_LEN]={0};
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, CMD_GO);
    ADD_DWORD_TO_PACKET(params_buf, go_addr);
    FINISH_BUILDING_PACKET(params_buf);

    for (i = 0;i < 10;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf,0,sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret == 3 && rcv_buf[0] == 0x02)
        {
            cprintf("send go command success.\n");
            return 0;
        }
        else
        {
            sleep(1);
            cprintf("send go command failed.\n");
            continue; 
        }
    }
    return -1;
}
__attribute((visibility("default")))int HexDownload(int fd_diagnose, FILE* fileToBeChecked, int length, int ehex, int* readed)
{
    int ret;
   	
    ret = nop_cmd(fd_diagnose);
    if(ret != 0)
    {
        cprintf("send nop cmd failed.ret=%d\n", ret);
        return -1;
    }
    else
    {
        cprintf("send nop cmd success.\n");
    }
    ret = FlashSendRamProgram(fd_diagnose, fileToBeChecked, length, ehex?EDLOAD_BASE:DLOAD_BASE, readed);
    if(ret < 0)
    {
        cprintf("call FlashSendRamProgram failed ret = %d", ret);
        return -1;
    }
    ret = go_cmd(fd_diagnose, ehex?EDLOAD_BASE:DLOAD_BASE);

    if(ret < 0)
    {
        cprintf("call go_cmd failed ret=%d\n", ret);
        return -1;
    }
    else
    {
        cprintf("call go_cmd successfully.\n");
    }
    
    return 0;
}

int dload_cmd(int fd_diagnose, unsigned char id, char* payload)
{
    int i;
    int ret;
    unsigned char rcv_buf[MAX_PACKET_LEN];
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x1B);
    ADD_BYTE_TO_PACKET(params_buf, id);
    if(payload)
    {
        for(i = 0;i < strlen(payload);i++)
        {
            ADD_BYTE_TO_PACKET(params_buf, payload[i]);
        }
        ADD_BYTE_TO_PACKET(params_buf, 0x00);
    }
    FINISH_BUILDING_PACKET(params_buf);

    for (i = 0;i < 10;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret == 4 && rcv_buf[0] == 0x1C && rcv_buf[1] == 0x00)
        {
            return 0;
        }
        else
        {
            sleep(1);
            continue;
        }
    }
    return -1;
}

int dload_stream_write_new(int fd_diagnose, unsigned int write_addr, unsigned char *file_buf, unsigned int write_len) 
{
    int i = 0;
    int ret;
    unsigned int addr;
    unsigned char rcv_buf[MAX_PACKET_LEN];
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x07);
    ADD_BYTE_TO_PACKET(params_buf, (byte)(write_addr&0xFF));
    ADD_BYTE_TO_PACKET(params_buf, (byte)((write_addr >> 8)&0xFF));
    ADD_BYTE_TO_PACKET(params_buf, (byte)((write_addr >> 16)&0xFF));
    ADD_BYTE_TO_PACKET(params_buf, (byte)((write_addr >> 24)&0xFF));
    
    for(i = 0;i < write_len;i++)
    {
        ADD_BYTE_TO_PACKET(params_buf, file_buf[i]);
    }
	
    FINISH_BUILDING_PACKET(params_buf);
    
    for (i = 0;i < 3;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret == 7 && rcv_buf[0] == 0x08)
        {
            memcpy(&addr, &rcv_buf[1], sizeof(addr));
//to test by caogang
            //addr = bswap_32(addr);
            if(addr == write_addr)
            {
                return 0;
            }
        }
    } 
    return 1; 
}
int dload_stream_download(int fd_diagnose, FILE* fileToBeChecked, int length, int* readed)
{
    unsigned int  currentAddress = 0;
    unsigned int  count, numBytesRead = 0, dataSize;
    int need_read;
    dataSize = length;
    unsigned char TxBuffer[FLASH_TX_LOAD_LEN]={0};
    while(dataSize > 0)
    {
        need_read = MIN(sizeof(TxBuffer), dataSize);
        numBytesRead = fread(TxBuffer, 1, need_read, fileToBeChecked);
        if(numBytesRead != need_read)
        {
            cprintf("read hex file failed %d\n", numBytesRead);
            return -1;
        }
        if(readed)
        {
            *readed += numBytesRead;
        }
        count = 0;
        while(count < MAX_RETRY_TIMES)
        {
            if(!dload_stream_write_new(fd_diagnose, currentAddress, TxBuffer, numBytesRead))
            {
                cprintf("\nsuccess to write Addr %X\n", currentAddress);
                break;
            }
            else
            {
                cprintf("retry to write Addr %X\n", currentAddress);
                count++;
            }
        }
        if(count == MAX_RETRY_TIMES)
        {
            cprintf("fail to write Addr %X\n",currentAddress);
            return -1;
        }
        currentAddress += numBytesRead;
        dataSize -= numBytesRead;
    }

    return 0;
}

int dload_close_packet_cmd(int fd_diagnose)
{
    int i;
    int ret;
    unsigned char rcv_buf[MAX_PACKET_LEN];
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x15);
    FINISH_BUILDING_PACKET(params_buf);
 
    for (i = 0;i < 10;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret == 3 && rcv_buf[0] == 0x16)
        {
            return 0;
        }
        else
        {
            sleep(1);
            continue;
        }
    }
    return -1;
}

struct partition_info_t
{
    char* name;
    char* payload;
    unsigned char id;
};
struct partition_info_t ptn_info[] = 
{
    {"mibib", "0:SBL1", 0x0E},
    {"sbl2", "0:SBL2", 0x0E},
    {"rpm", "0:RPM", 0x0E},
    {"dsp1", "0:DSP1", 0x0E},
    {"dsp2", "0:DSP2", 0x0E},
    {"dsp3", "0:DSP3", 0x0E},
    {"aboot", "0:APPSBL", 0x0E},
    {NULL, NULL, 0x00}
};
__attribute((visibility("default")))int dload_image(int fd_diagnose, FILE* fileToBeChecked, int length, char* ptn, int* readed)
{
    int status;
    struct partition_info_t* pinfo = ptn_info;
    while(pinfo->name)
    {
        if(strcmp(pinfo->name, ptn) == 0)
        {
            break;
        }
        pinfo++;
    }
    if(pinfo->name)
    {
        status = dload_cmd(fd_diagnose, pinfo->id, pinfo->payload);
        if(status != 0)
        {
            cprintf("Fail to call dload_cmd for %s\n", pinfo->name);
            return -1;
        }
        status = dload_stream_download(fd_diagnose, fileToBeChecked, length, readed);
        if(status != 0)
        {
            cprintf("Fail to call dload for %s\n", pinfo->name);
            return -1;
        }
        else
        {
            cprintf("call dload %s successfully.\n", pinfo->name);
        }
        status = dload_close_packet_cmd(fd_diagnose);
        if(status != 0)
        {
            cprintf("Fail to close packet for %s\n", pinfo->name);
            return -1;
        }
        else
        {
            cprintf("call close packet successfully.\n");
        }
    }
    else
    {
        cprintf("ptn %s not found\n", ptn);
        return -1;
    }
    return 0;
}
int dload_hello_cmd(int fd_diagnose)
{
    int i;
    int ret;
    unsigned char rcv_buf[MAX_PACKET_LEN];
    pkt_buffer_type params_buf;
    static char hellopacket[32] = {'Q', 'C', 'O', 'M', ' ', 'f','a','s','t',' ','d','o','w','n','l','o','a','d',' ','p','r','o','t','o','c','o','l',' ','h','o','s','t'}; 
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x01);
    for(i = 0;i < 32;i++)
    {
        ADD_BYTE_TO_PACKET(params_buf, hellopacket[i]);
    }
    ADD_BYTE_TO_PACKET(params_buf, 0x03);
    ADD_BYTE_TO_PACKET(params_buf, 0x02);
    ADD_BYTE_TO_PACKET(params_buf, 0x01);

    FINISH_BUILDING_PACKET(params_buf);

    for(i = 0;i < 10;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret >= 44 && rcv_buf[0] == 0x02)
        {
            return 0;
        }
        else
        {
            sleep(1);
            continue;
        }
    }
    return -1;
}
/********************************************************************
 *
 *         Name:  dload_security_cmd
 *  Description:  swith the diagnosetic interface to download mode. 
 *        Input:  diagnose_interface: the serial port name 
 *       Output:  null
 *       Return:  0/-1;
 *        Notes:  
 ********************************************************************/
int dload_security_cmd(int fd_diagnose) 
{
    int i;
    int ret;
    unsigned char rcv_buf[MAX_PACKET_LEN];
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf); 
    ADD_BYTE_TO_PACKET(params_buf, 0x17); 
    ADD_BYTE_TO_PACKET(params_buf, 0x01);  
    FINISH_BUILDING_PACKET(params_buf);  

    for (i = 0;i < 10;i++) 
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret == 3 && rcv_buf[0] == 0x18)
        {
            return 0;
        }
        else
        {
            sleep(1);
            continue;
        }
    }
    return -1;
}
int dload_partition_table_cmd(int fd_diagnose, FILE* fileToBeChecked, int length, int* readed) 
{
    int i = 0;
    int ret;
    pkt_buffer_type params_buf;
    unsigned char buf[512]={0};
    
    if(length > 512 || length <= 0)
    {
        cprintf("BIN file length error\n");
        return -1;
    }
	ret = fread(buf, 1, length, fileToBeChecked);
    if(ret != length)
    {
       cprintf("read partition failed %d\n", ret);
       return -1;
    }
    if(readed)
    {
        *readed += ret;
    }
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x19);
    ADD_BYTE_TO_PACKET(params_buf, 0x00);
    for(i = 0; i < length; i++)
    {
        ADD_BYTE_TO_PACKET(params_buf, buf[i]);
    }

    FINISH_BUILDING_PACKET(params_buf);

    for(i = 0;i < 10;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        ret = rcv_ack_packet_with_head(fd_diagnose, buf, sizeof(buf));
        if(ret == 4 && buf[0] == 0x1A)
        {
            return 0;
        }
        else
        {
            sleep(1);
            continue;
        }
    }
    return -1;
}
__attribute((visibility("default")))int dload_partition_table_download(int fd_diagnose, FILE* fileToBeChecked, int length, int* readed)
{
    int status = dload_hello_cmd(fd_diagnose);
    if(status != 0)
    {
        cprintf("download hello cmd failed, ret=%d\n",status);
        return -1;
    }
    else
    {
        cprintf("download hello cmd successful.\n");
    }
    
    status = dload_security_cmd(fd_diagnose);
    if(status != 0)
    {
        cprintf("dload_security_cmd failed, ret=%d\n",status);
        return status;
    }
    else
    {
        cprintf("dload_security_cmd successful.\n");
    }
    status = dload_partition_table_cmd(fd_diagnose, fileToBeChecked, length, readed);
    if(status != 0)
    {
        cprintf("Fail to call dload_partition_table_cmd.ret=%d\n", status);
        return status;
    }
    else
    {
        cprintf("call dload_partition_table_cmd successfully.\n");
    }  
    return 0;
}
__attribute((visibility("default")))int dload_switch_cmd(char* diagnose_interface)
{
    int NumRxBytes = 0;
    pkt_buffer_type params_buf;

    int fd_diagnose = mu_opencom(diagnose_interface);
    if(fd_diagnose < 0)
    {
        return -1;
    }
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, CMD_DLOAD_SWITCH);
    FINISH_BUILDING_PACKET(params_buf);
    unsigned char RxBuffer[32]={0};

    transmit_packet_no_leading_flag(fd_diagnose, &params_buf);
    memset(RxBuffer, 0, sizeof(RxBuffer));
    RxBuffer[0] = (unsigned char)(~CMD_ACK);
    NumRxBytes = ReadComPort(fd_diagnose, RxBuffer, 4);
    cprintf_hex(RxBuffer, NumRxBytes);
    if((NumRxBytes != 4) || (RxBuffer[0] != CMD_DLOAD_SWITCH) || (RxBuffer[3] != ASYNC_HDLC_FLAG))
    {
        close(fd_diagnose);
        return -1;
    }
    else
    {
        close(fd_diagnose);
        return 0;
    }
}
__attribute((visibility("default")))int send_offlin_cmd(char* diagnose_interface)
{
    int status = 0;
    unsigned char data[] = {0x29,0x01,0x00,0x31,0x40,0x7e};
    unsigned char  rcv_buff[32] = {0};
    int com_port = mu_opencom(diagnose_interface);
    if(com_port < 0)
    {
        return -1;
    }
	
    status = WriteToComPort(com_port, data, sizeof(data));
    if(status != sizeof(data))
    {
        cprintf("write to comm port failed.\n");
        close(com_port);
        return -1;
    }
	
    status = ReadComPort(com_port, rcv_buff, sizeof(data));
    cprintf_hex(rcv_buff, status);
    if(status!=sizeof(data)||rcv_buff[0]!=data[0]||rcv_buff[1]!=data[1])
    {
        cprintf("switch to offline failed.\n");
        close(com_port);
        return -1;
    }
    else
    {
        cprintf("send offline command success.\n");
        close(com_port);
        return 0;
    }	
}
__attribute((visibility("default")))int reset_cmd(int fd_diagnose)
{
    int i = 0;
    int ret;
    unsigned char rcv_buf[MAX_PACKET_LEN]={0};
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x0B);
    FINISH_BUILDING_PACKET(params_buf);

    for (i = 0;i < 10;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf,0,sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret == 3 && rcv_buf[0] == 0x0C)
        {
            cprintf("send reset command success.\n");
            return 0;
        }
        else
        {
            sleep(1);
            cprintf("send reset command failed.\n");
            continue; 
        }
    }
    return -1;
}

__attribute((visibility("default")))int check_dload_mode(char* diagnose_interface)
{
    int i;
    int ret;
    unsigned char rcv_buf[MAX_PACKET_LEN];
    pkt_buffer_type params_buf;
    int fd_diagnose = mu_opencom(diagnose_interface);
    if(fd_diagnose < 0)
    {
        return -1;
    }
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x0C);
    FINISH_BUILDING_PACKET(params_buf);

    for (i = 0;i < 2;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet_no_leading_flag(fd_diagnose, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        ret = rcv_ack_packet_no_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret > 2 && rcv_buf[0] == 0x0C)
        {
            cprintf("in normal mode\n");
            close(fd_diagnose);
            return 0;
        }
        else
        {
            sleep(1);
            continue;
        }
    }

    ret = nop_cmd(fd_diagnose);
    if(ret != 0)
    {
        cprintf("unkown mode\n");
        close(fd_diagnose);
        return -1;
    }

    cprintf("in dload mode.\n");
    close(fd_diagnose);
    return 1;
}

__attribute((visibility("default")))struct mem_info_t* get_mem_info(int fd_diagnose)
{
    int i;
    int ret;
    unsigned short data_len;
    unsigned char save;
    unsigned int base;
    unsigned int len;
    char* desp;
    char* fname;
    struct mem_info_t* head = NULL;
    struct mem_info_t* info = NULL;
    struct mem_info_t* info1 = NULL;
    unsigned char rcv_buf[MAX_PACKET_LEN];
    unsigned char* phead;
    pkt_buffer_type params_buf;
    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x10);
    FINISH_BUILDING_PACKET(params_buf);

    for (i = 0;i < 2;i++)
    {
        tcflush(fd_diagnose, TCIOFLUSH);
        transmit_packet(fd_diagnose, &params_buf);
        memset(rcv_buf, 0, sizeof(rcv_buf));
        ret = rcv_ack_packet_with_head(fd_diagnose, rcv_buf, sizeof(rcv_buf));
        if(ret > 3 && rcv_buf[0] == 0x11)
        {
            memcpy(&data_len, &rcv_buf[1], sizeof(data_len));
            if(data_len != ret-5)
            {
                cprintf("%d len error %d %d\n", __LINE__, data_len, ret);
                goto END;
            }
            phead = &rcv_buf[3];
            while(data_len > 0)
            {
                cprintf("%d data_len %d\n", __LINE__, data_len);
                if(data_len < 12)
                {
                    cprintf("%d len error %d\n", __LINE__, data_len);
                    goto END;
                }
                save = *phead;
                phead++;
                data_len--;

                memcpy(&base, phead, sizeof(base));
                phead += sizeof(base);
                data_len -= sizeof(base);

                memcpy(&len, phead, sizeof(len));
                phead += sizeof(len);
                data_len -= sizeof(len);
                cprintf("%d save %2hhd base %08X len %08X\n", __LINE__, save, base, len);
                desp = (char*)phead;
                while(*phead)
                {
                    phead++;
                    data_len--;
                    if(data_len == 0)
                    {
                        cprintf("%d len error\n", __LINE__);
                        goto END;
                    }
                }
                phead++;
                data_len--;
                cprintf("%d desp %s\n", __LINE__, desp);

                fname = (char*)phead;
                while(*phead)
                {
                    phead++;
                    data_len--;
                    if(data_len == 0)
                    {
                        cprintf("%d len error\n", __LINE__);
                        goto END;
                    }
                }
                phead++;
                data_len--;
                cprintf("%d fname %s\n", __LINE__, fname);

                info1 = (struct mem_info_t*)malloc(sizeof(struct mem_info_t));
                if(info1 == NULL)
                {
                    cprintf("%d mallocn error\n", __LINE__);
                    goto END;
                }
                info1->save = save;
                info1->base = base;
                info1->len = len;
                strncpy(info1->name, fname, sizeof(info1->name));
                info1->name[sizeof(info1->name)-1] = 0;
                info1->next = NULL;
                if(info)
                {
                    info->next = info1;
                    info = info1;
                }
                else
                {
                    head = info1;
                    info = info1;
                }

            }
            break;
        }
        else
        {
            sleep(1);
            continue;
        }
    }

    return head;
END:
    info1 = info;
    while(info1)
    {
        info = info1->next;
        free(info1);
        info1 = info;
    }
    return NULL;
}

int get_mem_block(int fd_diagnose, unsigned char* buf, unsigned int offset, unsigned int len)
{
    int NumRxBytes = 0;
    pkt_buffer_type params_buf;
    unsigned int roffset;
    unsigned int rlen;

    START_BUILDING_PACKET(params_buf);
    ADD_BYTE_TO_PACKET(params_buf, 0x14);
    ADD_BYTE_TO_PACKET(params_buf, 0x12);
    ADD_BYTE_TO_PACKET(params_buf, 0x56);
    ADD_BYTE_TO_PACKET(params_buf, 0x34);
    ADD_DWORD_TO_PACKET(params_buf, offset);
    ADD_DWORD_TO_PACKET(params_buf, len);
    FINISH_BUILDING_PACKET(params_buf);
    unsigned char RxBuffer[MAX_PACKET_LEN]={0};

    transmit_packet(fd_diagnose, &params_buf);
    memset(RxBuffer, 0, sizeof(RxBuffer));
    RxBuffer[0] = (unsigned char)(~CMD_ACK);
    NumRxBytes = ReadComPortWait(fd_diagnose, RxBuffer, 12+len);
    if((NumRxBytes != 12+len) || (RxBuffer[0] != 0x15))
    {
        cprintf("%d len error 0x%02hhX %d %d\n", __LINE__, RxBuffer[0], NumRxBytes, len);
        return -1;
    }
    memcpy(&roffset, &RxBuffer[4], sizeof(roffset));
    memcpy(&rlen, &RxBuffer[8], sizeof(rlen));
    if(roffset != offset || rlen != len)
    {
        cprintf("%d len error %d %d %d %d\n", __LINE__, roffset, offset, rlen, len);
        return -1;
    }

    memcpy(buf, &RxBuffer[12], rlen);
    return 0;
}

__attribute((visibility("default")))int get_mem(int fd_diagnose, struct mem_info_t* info)
{
    int fd;
    int ret = -1;
    unsigned int offset;
    unsigned int len;
    unsigned int toread;
    unsigned char buf[1024];
    char file_name[64] = "/tmp/";
    if(info == NULL)
    {
        cprintf("%d info null\n", __LINE__);
        return -1;
    }
    strcat(file_name, info->name);
    strcpy(info->path, file_name);
    fd = open(file_name, O_CREAT | O_TRUNC | O_WRONLY);
    if(fd < 0)
    {
        cprintf("%d open '%s' failed %d\n", __LINE__, file_name, errno);
        return -1;
    }
    offset = info->base;
    len = info->len;
    while(len > 0)
    {
        toread = MIN(len, sizeof(buf));
        if(get_mem_block(fd_diagnose, buf, offset, toread) < 0)
        {
            cprintf("%d get_mem_block failed\n", __LINE__);
            goto END;
        }
        write(fd, buf, toread);
        len -= toread;
        offset += toread;
    }
    ret = 0;
END:
    close(fd);
    return ret;
}

__attribute((visibility("default")))int get_mem_gz(int fd_diagnose, struct mem_info_t* info)
{
    gzFile out;
    int ret = -1;
    unsigned int offset;
    unsigned int len;
    unsigned int toread;
    unsigned char buf[4000];
    char file_name[64] = "/tmp/";
    if(info == NULL)
    {
        cprintf("%d info null\n", __LINE__);
        return -1;
    }
    strcat(info->name, ".gz");
    strcat(file_name, info->name);
    strcpy(info->path, file_name);
    out = gzopen(file_name, "wb6");
    if (out == NULL) {
        cprintf("%d open '%s' failed\n", __LINE__, file_name);
        return -1;
    }
    offset = info->base;
    len = info->len;
    while(len > 0)
    {
        toread = MIN(len, sizeof(buf));
        if(get_mem_block(fd_diagnose, buf, offset, toread) < 0)
        {
            cprintf("%d get_mem_block failed\n", __LINE__);
            goto END;
        }
        if (gzwrite(out, buf, (unsigned)toread) != toread)
        {
            cprintf("%d gzwrite failed\n", __LINE__);
            goto END;
        }
        len -= toread;
        offset += toread;
    }
    ret = 0;
END:
    if (gzclose(out) != Z_OK)
    {
        cprintf("%d gzclose failed\n", __LINE__);
    }
    return ret;
}

__attribute((visibility("default")))int dump_mem(int fd_diagnose)
{
    int ret = -1;
    struct mem_info_t* info = NULL;
    struct mem_info_t* index = NULL;
    if((info = get_mem_info(fd_diagnose)) == NULL)
    {
        cprintf("%d get_mem_info failed\n", __LINE__);
        return -1;
    }
    index = info;
    do
    {
        cprintf("name:%s\n", index->name);
        cprintf("save:%02hhx\n", index->save);
        cprintf("base:%08X\n", index->base);
        cprintf("len:%08X\n", index->len);
        if(get_mem_gz(fd_diagnose, index) < 0)
        {
            cprintf("%d get_mem_gz failed\n", __LINE__);
            goto END;
        }
    }while((index = index->next));
    ret = 0;
END:
    free(info);
    return 0;
}

//<!-- add NODECOM MDM9x07 FEATURE by caogang@20160908
#ifdef _NODECOM_MDM9x07_FEATURE
#include "boot_sahara.h"
#define SAHARA_MAX_PACKET_SIZE_IN_BYTES 0x400
#define SAHARA_PACKET_LOG_LENGTH 0x64
#define SAHARA_MAX_MEMORY_DATA_SIZE_IN_BYTES 0x1000
#define SAHARA_RAM_ZI_SIZE 0x20000
#define SECTOR_SIZE_IN_BYTES 512

unsigned char sahara_packet_buffer[SAHARA_MAX_PACKET_SIZE_IN_BYTES];
unsigned char sahara_packet_rcv_buffer[SAHARA_MAX_PACKET_SIZE_IN_BYTES];
unsigned int g_u32_memory_table_addr = 0;
unsigned int g_u32_memory_table_length = 0;
static dload_debug_type g_dload_debug_info[NUM_REGIONS];
unsigned char sahara_dump_path[SAHARA_PACKET_LOG_LENGTH];

int sahara_transmit_packet
(
  int fd_diagnose,
  const unsigned char* packet_buffer,
  const unsigned int length
)
{
    int NumTxBytes = 0;
    //cprintf("\nsend:");
    NumTxBytes = WriteToComPort (fd_diagnose, (unsigned char *)packet_buffer, length);
    //cprintf_hex(packet_buffer, NumTxBytes);
    return NumTxBytes;
}

int sahara_rcv_packet
(
    int fd_diagnose,
    unsigned char *packet_buffer,
    size_t length
)
{
    int NumRxBytes = 0;
    memset(sahara_packet_rcv_buffer,0,sizeof(sahara_packet_rcv_buffer));
    //cprintf("\nrcv:");
    NumRxBytes = ReadComPort (fd_diagnose, packet_buffer, length);
    //cprintf_hex(packet_buffer, NumRxBytes);
    return NumRxBytes;
}

__attribute((visibility("default")))int boot_sahara_handle_no_cmd_id(int fd_diagnose)
{
    int ret;
    char buf[16];
    memset(buf,0,sizeof(buf));

    tcflush(fd_diagnose, TCIOFLUSH);
    ret = sahara_transmit_packet(fd_diagnose, (unsigned char *)buf, sizeof(buf));

    cprintf("%d ret=%d\n", __LINE__, ret);

    return 0;
}

__attribute((visibility("default")))int boot_sahara_handle_hello(int fd_diagnose)
{
    int i;
    int ret;
    struct sahara_packet_hello* packet_hello = NULL;
    packet_hello = (struct sahara_packet_hello*)sahara_packet_rcv_buffer;

    for (i = 0;i < 2;i++)
    {
        memset(sahara_packet_rcv_buffer, 0, sizeof(sahara_packet_rcv_buffer));
        ret = sahara_rcv_packet(fd_diagnose, sahara_packet_rcv_buffer, sizeof(struct sahara_packet_hello));
        if (ret == sizeof(struct sahara_packet_hello) && SAHARA_HELLO_ID == packet_hello->command)
        {
            cprintf("%d ret=%d, packet_hello->command=%04X, packet_hello->mode=%04X\n", \
__LINE__, ret, packet_hello->command, packet_hello->mode);
            return packet_hello->mode;
        }
    }

    return 0;
}

__attribute((visibility("default")))int boot_sahara_handle_hello_resp(int fd_diagnose)
{
    int ret;
    struct sahara_packet_hello_resp* packet_hello_resp =
    (struct sahara_packet_hello_resp*)sahara_packet_buffer;

    // Setup HELLO packet
    packet_hello_resp->command = SAHARA_HELLO_RESP_ID;
    packet_hello_resp->length = sizeof(struct sahara_packet_hello_resp);
    packet_hello_resp->version = SAHARA_VERSION_MAJOR;
    packet_hello_resp->version_supported = SAHARA_VERSION_MAJOR_SUPPORTED;
    packet_hello_resp->status = SAHARA_STATUS_SUCCESS;
    packet_hello_resp->mode = SAHARA_MODE_MEMORY_DEBUG;
    packet_hello_resp->reserved0 = 0;
    packet_hello_resp->reserved1 = 0;
    packet_hello_resp->reserved2 = 0;
    packet_hello_resp->reserved3 = 0;
    packet_hello_resp->reserved4 = 0;
    packet_hello_resp->reserved5 = 0;

    tcflush(fd_diagnose, TCIOFLUSH);
    ret = sahara_transmit_packet(fd_diagnose, (unsigned char *)packet_hello_resp, packet_hello_resp->length);

    cprintf("%d ret=%d, sahara_packet_hello_resp size=%d, length=%d\n", __LINE__, ret, sizeof(struct sahara_packet_hello_resp), packet_hello_resp->length);

    return 0;
}

__attribute((visibility("default")))int boot_sahara_handle_memory_debug(int fd_diagnose)
{
    int i;
    int ret;
    struct sahara_packet_memory_debug* packet_memory_debug = NULL;
    packet_memory_debug = (struct sahara_packet_memory_debug*)sahara_packet_rcv_buffer;

    for (i = 0;i < 2;i++)
    {
        memset(sahara_packet_rcv_buffer, 0, sizeof(sahara_packet_rcv_buffer));
        ret = sahara_rcv_packet(fd_diagnose, sahara_packet_rcv_buffer, sizeof(struct sahara_packet_memory_debug));
        if (ret == sizeof(struct sahara_packet_memory_debug) && SAHARA_MEMORY_DEBUG_ID == packet_memory_debug->command)
        {
            cprintf("%d ret=%d, packet_memory_debug->command=%04X, packet_memory_debug->memory_table_addr=%04X, packet_memory_debug->memory_table_length=%04X\n", __LINE__, ret, packet_memory_debug->command, packet_memory_debug->memory_table_addr, packet_memory_debug->memory_table_length);
            g_u32_memory_table_addr = packet_memory_debug->memory_table_addr;
            g_u32_memory_table_length = packet_memory_debug->memory_table_length;
            return 1;
        }
    }
    return 0;
}

__attribute((visibility("default")))int boot_sahara_handle_memory_read_packet(int fd_diagnose)
{
    int ret;
    struct sahara_packet_memory_read* packet_memory_read =
    (struct sahara_packet_memory_read*)sahara_packet_buffer;

    // Setup memory read packet
    packet_memory_read->command = SAHARA_MEMORY_READ_ID;
    packet_memory_read->length = sizeof(struct sahara_packet_memory_read);
    packet_memory_read->memory_addr = g_u32_memory_table_addr;
    packet_memory_read->memory_length = g_u32_memory_table_length;

    tcflush(fd_diagnose, TCIOFLUSH);
    ret = sahara_transmit_packet(fd_diagnose, (unsigned char *)packet_memory_read, packet_memory_read->length);

    cprintf("%d ret=%d, boot_sahara_handle_memory_read_packet size=%d, length=%d\n", __LINE__, ret, sizeof(struct sahara_packet_memory_read), packet_memory_read->length);

    return 0;
}

__attribute((visibility("default")))int boot_sahara_handle_memory_read_packet_resp(int fd_diagnose)
{
    int i;
    int ret;
    memset(g_dload_debug_info, 0, sizeof(g_dload_debug_info));

    for (i = 0;i < 2;i++)
    {
        memset(sahara_packet_rcv_buffer, 0, sizeof(sahara_packet_rcv_buffer));
        ret = sahara_rcv_packet(fd_diagnose, sahara_packet_rcv_buffer, sizeof(g_dload_debug_info));
        if (ret > 0)
        {
            memcpy(g_dload_debug_info, sahara_packet_rcv_buffer, ret);
            cprintf("\ndload_debug_info:");
            cprintf_hex(g_dload_debug_info, ret);
            return 1;
        }
    }

    return 0;
}

__attribute((visibility("default")))int sahara_get_mem_gz(int fd_diagnose, dload_debug_type* info)
{
    gzFile out;
    int ret = -1;
    unsigned int len;
    unsigned int toread;
    unsigned char buf[4096];
    char file_name[64];
    if(info == NULL)
    {
        cprintf("%d info null\n", __LINE__);
        return -1;
    }
    memset(file_name, 0, sizeof(file_name));
    sprintf(file_name, "%s%s.gz", sahara_dump_path, info->filename);

    out = gzopen(file_name, "wb6");
    if (out == NULL) {
        cprintf("%d open '%s' failed\n", __LINE__, file_name);
        return -1;
    }
    
    len = info->length;

    while(len > 0)
    {
        toread = MIN(len, sizeof(buf));
        toread = sahara_rcv_packet(fd_diagnose, buf, toread);
        if(toread < 0)
        {
            cprintf("%d get_mem_block failed\n", __LINE__);
            goto END;
        }
        if (gzwrite(out, buf, (unsigned)toread) != toread)
        {
            cprintf("%d gzwrite failed\n", __LINE__);
            goto END;
        }
        len -= toread;
        cprintf("%d total:%d, remaining:%d, at one time to read:%d\n", __LINE__, info->length, len, toread);
    }
    ret = 0;
END:
    if (gzclose(out) != Z_OK)
    {
        cprintf("%d gzclose failed\n", __LINE__);
    }
    return ret;
}

__attribute((visibility("default")))int sahara_get_ddr_mem_gz(int fd_diagnose, char* filename, int length, int append)
{
    gzFile out;
    int ret = -1;
    unsigned int len;
    unsigned int toread;
    unsigned char buf[4096];
    char file_name[64];

    memset(file_name, 0, sizeof(file_name));
    sprintf(file_name, "%s%s.gz", sahara_dump_path, filename);

    if (0 == append)
    {
        out = gzopen(file_name, "wb6");
    }
    else
    {
        out = gzopen(file_name, "ab6");
    }
    if (out == NULL) {
        cprintf("%d open '%s' failed\n", __LINE__, file_name);
        return -1;
    }
    
    len = length;

    while(len > 0)
    {
        toread = MIN(len, sizeof(buf));
        toread = sahara_rcv_packet(fd_diagnose, buf, toread);
        if(toread < 0)
        {
            cprintf("%d get_mem_block failed\n", __LINE__);
            goto END;
        }
        if (gzwrite(out, buf, (unsigned)toread) != toread)
        {
            cprintf("%d gzwrite failed\n", __LINE__);
            goto END;
        }
        len -= toread;
        //cprintf("%d total:%d, remaining:%d, at one time to read:%d\n", __LINE__, length, len, toread);
    }
    ret = 0;
END:
    if (gzclose(out) != Z_OK)
    {
        cprintf("%d gzclose failed\n", __LINE__);
    }
    return ret;
}

__attribute((visibility("default")))int boot_sahara_handle_dump_mem(int fd_diagnose)
{
    int i;
    for (i = 0;i < NUM_REGIONS;i++)
    {
        dload_debug_type index = g_dload_debug_info[i];
        if (0x0 != index.save_pref)
        {
            int ret;

            cprintf("index:%04X\n", i);
            cprintf("pref:%04X\n", index.save_pref);
            cprintf("mem_base:%04X\n", index.mem_base);
            cprintf("length:%04X\n", index.length);
            cprintf("desc:%s\n", index.desc);
            cprintf("filename:%s\n", index.filename);

            if (NULL != strstr(index.desc, "DDR") || NULL != strstr(index.filename, "DDR"))
            {
                unsigned int ddr_cs0_memory_len = index.length;
                unsigned int offset = 0;
                unsigned int toread = 320*1024; //Max one time to read size 320KB

                while(ddr_cs0_memory_len > 0)
                {
                    struct sahara_packet_memory_read* packet_memory_read = (struct sahara_packet_memory_read*)sahara_packet_buffer;

                    toread = MIN(ddr_cs0_memory_len, toread);

                    packet_memory_read->command = SAHARA_MEMORY_READ_ID;
                    packet_memory_read->length = sizeof(struct sahara_packet_memory_read);
                    packet_memory_read->memory_addr = index.mem_base + offset;
                    packet_memory_read->memory_length = toread;

                    tcflush(fd_diagnose, TCIOFLUSH);

                    ret = sahara_transmit_packet(fd_diagnose, (unsigned char *)packet_memory_read, packet_memory_read->length);
                    cprintf("%d ret=%d, boot_sahara_handle_memory_read_packet size=%d, length=%d\n", __LINE__, ret, sizeof(struct sahara_packet_memory_read), packet_memory_read->length);

                    if(sahara_get_ddr_mem_gz(fd_diagnose, index.filename, toread, offset) < 0)
                    {
                        cprintf("%d sahara_get_mem_gz failed\n", __LINE__);
                        return -1;
                    }
                    offset += toread;
                    ddr_cs0_memory_len -= toread;
                    cprintf("%d DDR CS0 Memory total:%d, remaining:%d, at one time to read:%d\n", __LINE__, index.length, ddr_cs0_memory_len, toread);
                }
            }
            else
            {
                struct sahara_packet_memory_read* packet_memory_read = (struct sahara_packet_memory_read*)sahara_packet_buffer;
                packet_memory_read->command = SAHARA_MEMORY_READ_ID;
                packet_memory_read->length = sizeof(struct sahara_packet_memory_read);
                packet_memory_read->memory_addr = index.mem_base;
                packet_memory_read->memory_length = index.length;

                tcflush(fd_diagnose, TCIOFLUSH);
                ret = sahara_transmit_packet(fd_diagnose, (unsigned char *)packet_memory_read, packet_memory_read->length);

                cprintf("%d ret=%d, boot_sahara_handle_memory_read_packet size=%d, length=%d\n", __LINE__, ret, sizeof(struct sahara_packet_memory_read), packet_memory_read->length);

                if(sahara_get_mem_gz(fd_diagnose, &index) < 0)
                {
                    cprintf("%d sahara_get_mem_gz failed\n", __LINE__);
                    return -1;
                }
            }
        }
    }

    return 0;
}

__attribute((visibility("default")))int boot_sahara_handle_cmd_switch_mode(int fd_diagnose, int mode)
{
    int ret;
    struct sahara_packet_cmd_switch_mode* packet_cmd_switch_mode_req =
    (struct sahara_packet_cmd_switch_mode*)sahara_packet_buffer;

    // Setup cmd switch mode packet
    packet_cmd_switch_mode_req->command = SAHARA_CMD_SWITCH_MODE_ID;
    packet_cmd_switch_mode_req->length = sizeof(struct sahara_packet_cmd_switch_mode);
    packet_cmd_switch_mode_req->mode = mode;

    tcflush(fd_diagnose, TCIOFLUSH);
    ret = sahara_transmit_packet(fd_diagnose, (unsigned char *)packet_cmd_switch_mode_req, packet_cmd_switch_mode_req->length);

    cprintf("%d ret=%d, packet_cmd_switch_mode_req size=%d, length=%d\n", __LINE__, ret, sizeof(struct sahara_packet_cmd_switch_mode), packet_cmd_switch_mode_req->length);

    return 0;
}

__attribute((visibility("default")))int set_sahara_dump_path(char *file_path)
{
    int ret;
    memset(sahara_dump_path, 0, sizeof(sahara_dump_path));
    if (NULL == file_path)
    {
        sprintf(sahara_dump_path, "%s", "/tmp/");
    }
    else
    {
        sprintf(sahara_dump_path, "%s", file_path);
    }

    cprintf("%d sahara_dump_path=%s\n", __LINE__, sahara_dump_path);

    return 0;
}
#endif //#ifdef _NODECOM_MDM9x07_FEATURE
//end -->
